var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
// ═══════════════════════════════════════════════════
//  UTILS
// ═══════════════════════════════════════════════════
function fmtTime(d) {
    return d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}
// Enter handler — movido para a seção de scanner de hardware acima
// ── Init ──
updateSteps();
// ServiceWorker não necessário — Firebase SDK gerencia offline
/** Botão manual para enviar fila (aba STATUS) */
function enviarFilaManual() {
    return __awaiter(this, void 0, void 0, function () {
        var pendentes, qtd, restantes;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!navigator.onLine) {
                        toast('📶 Sem internet — contagens salvas localmente no aparelho', 'w');
                        return [2 /*return*/];
                    }
                    return [4 /*yield*/, idbGetPendentes()];
                case 1:
                    pendentes = _a.sent();
                    if (!pendentes.length) {
                        toast('✅ Nenhuma contagem pendente', 's');
                        return [2 /*return*/];
                    }
                    qtd = pendentes.length;
                    FILA_ENVIO = pendentes;
                    toast("\u2B06\uFE0F Enviando ".concat(qtd, " contagem(ns)\u2026"), 'w');
                    return [4 /*yield*/, enviarFilaPendente()];
                case 2:
                    _a.sent();
                    updateStats();
                    atualizarFilaStatus();
                    return [4 /*yield*/, idbGetPendentes()];
                case 3:
                    restantes = (_a.sent()).length;
                    if (restantes === 0)
                        toast("\u2705 ".concat(qtd, " contagem(ns) enviadas com sucesso!"), 's');
                    else
                        toast("\u26A0\uFE0F ".concat(restantes, " contagem(ns) ainda pendentes"), 'w');
                    return [2 /*return*/];
            }
        });
    });
}
/** Atualiza o indicador de fila na aba STATUS */
function atualizarFilaStatus() {
    return __awaiter(this, void 0, void 0, function () {
        var el, n, pendentes, e_1, net;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    el = document.getElementById('st-fila');
                    if (!el) return [3 /*break*/, 5];
                    n = FILA_ENVIO.length;
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, idbGetPendentes()];
                case 2:
                    pendentes = _a.sent();
                    n = pendentes.length;
                    FILA_ENVIO = pendentes;
                    filaSave(FILA_ENVIO);
                    return [3 /*break*/, 4];
                case 3:
                    e_1 = _a.sent();
                    return [3 /*break*/, 4];
                case 4:
                    el.textContent = n > 0 ? n + ' pendente(s)' : '✓ Tudo enviado';
                    el.style.color = n > 0 ? 'var(--warn)' : 'var(--success)';
                    _a.label = 5;
                case 5:
                    net = document.getElementById('net-status');
                    if (net)
                        net.textContent = navigator.onLine ? '🔥 Firebase' : '📵 Offline';
                    // Manter pill sempre atualizado
                    atualizarBarraStatus();
                    return [2 /*return*/];
            }
        });
    });
}
// Atualiza indicador a cada 5s
setInterval(atualizarFilaStatus, 5000);


// Sincronização unificada e silenciosa (ES5): nunca recarrega a página.
(function () {
    var syncPromise = null;
    window.sincronizarTudoEmSegundoPlano = function (origem) {
        if (!navigator.onLine)
            return Promise.resolve({ offline: true });
        if (syncPromise)
            return syncPromise;
        syncPromise = Promise.resolve().then(function () {
            if (typeof idbGetPendentes !== 'function' || typeof enviarFilaPendente !== 'function')
                return null;
            return idbGetPendentes().then(function (pendentes) {
                FILA_ENVIO = Array.isArray(pendentes) ? pendentes : [];
                filaSave(FILA_ENVIO);
                return FILA_ENVIO.length ? enviarFilaPendente() : null;
            });
        }).catch(function (e) {
            console.warn('[SYNC] Contagens permanecem pendentes:', e);
        }).then(function () {
            if (typeof window.sincronizarFilaAuditoria === 'function')
                return window.sincronizarFilaAuditoria();
            return null;
        }).catch(function (e) {
            console.warn('[SYNC] Auditorias permanecem pendentes:', e);
        }).then(function () {
            try { atualizarBarraStatus(); } catch (e) { }
            try { return atualizarFilaStatus(); } catch (e) { return null; }
        }).then(function () { return { origem: origem || 'automatico' }; });
        syncPromise.then(function () { syncPromise = null; }, function () { syncPromise = null; });
        return syncPromise;
    };
    enviarFilaManual = function () {
        if (!navigator.onLine) {
            toast('📶 Sem internet — os registros continuam salvos no aparelho', 'w');
            return Promise.resolve();
        }
        toast('⬆️ Sincronizando contagens e auditorias em segundo plano…', 'w');
        return window.sincronizarTudoEmSegundoPlano('manual').then(function () {
            try { updateStats(); } catch (e) { }
            return atualizarFilaStatus();
        });
    };
    window.addEventListener('online', function () {
        setTimeout(function () { window.sincronizarTudoEmSegundoPlano('online').catch(function () { }); }, 250);
    });
})();
