function state(){ return window.AnalistaStore.getState(); }

function _paleteContagem(c){
  const valor=c?.palete ?? c?.pallet ?? c?.numero_palete ?? c?.numeroPalete ??
    c?.palete_key ?? c?.capa_palete ?? c?.pallete_ou_capa ?? c?.capa ?? '';
  return String(valor ?? '').trim();
}

function _ordemPaleteContagem(c){
  const pal=_paleteContagem(c);
  const num=Number(pal);
  if(pal && Number.isFinite(num)) return {grupo:0, valor:num, texto:pal};
  return {grupo:1, valor:0, texto:pal || String(c?.criado_em || c?.dataHora || c?.timestamp || '')};
}

function _produtoContagemExibicao(c){
  const codigo=c?.codigo_produto||c?.codigoProduto||c?.gtin||c?.ean||c?.dun||c?.codigo_lido||c?.codigoLido||'';
  const atual=String(c?.descricao_produto||c?.descricaoProduto||c?.descricao||'').trim();
  const placeholder=!atual||/^(PRODUTO NAO IDENTIFICADO|PRODUTO NÃO IDENTIFICADO|PRODUTO NAO CADASTRADO|PRODUTO NÃO CADASTRADO|CODIGO SEM CADASTRO|CÓDIGO SEM CADASTRO)$/i.test(atual);
  const ach=window.DTProdutos?.buscarSync?.(codigo);
  return {codigo:codigo||ach?.codigoInterno||ach?.gtin||ach?.dun||'',descricao:(!placeholder?atual:'')||(ach?.encontrado?ach.nomeProduto:'Código sem cadastro')};
}


// Retorna a rodada mais recente concluida para exibicao na aba Contagens.
// O registro original permanece intacto; esta funcao apenas monta a visao
// operacional com produto, quantidade, operador e data da ultima rodada.
function _ultimaRodadaContagem(c){
  const st=state();
  const FK=window.InventoryFlowKey;
  const primeira={
    rodada:1,
    quantidade:c?.quantidade ?? c?.qtd ?? c?.qtd_contada ?? null,
    produto:c?.gtin_bipado || c?.gtinLido || c?.gtin_lido || c?.codigo_lido || c?.codigoLido || c?.codigo_produto || c?.codigoProduto || c?.gtin || c?.ean || c?.dun || '',
    descricao:c?.descricao_produto || c?.descricaoProduto || c?.produto_descricao || c?.descricao || '',
    operador:c?.operador || c?.operador_nome || '',
    data:c?.timestamp || c?.criado_em || c?.dataHora || ''
  };
  if(!FK) return primeira;

  const inv=FK.inventario(c,st.inventarios);
  const end=FK.endereco(c?.endereco);
  const prod=FK.produto(c);
  const cid=String(c?.uuid || c?.id || '');
  const divs=(st.divergencias || []).filter(d =>
    FK.inventario(d,st.inventarios)===inv && FK.endereco(d?.endereco)===end &&
    !['CANCELADA','EXCLUIDA','ESTORNADA'].includes(String(d?.status || '').toUpperCase())
  );
  const div=divs.find(d => cid && [d?.contagem_uuid,d?.contagem_id,d?.origem_contagem_id].filter(Boolean).map(String).includes(cid)) ||
    divs.find(d => FK.produto(d)===prod) || (divs.length===1 ? divs[0] : null);
  if(!div) return primeira;

  const concluida=r => {
    const status=String(r?.status_recontagem || r?.status || '').trim().toUpperCase();
    const bloqueada=['PENDENTE','ATRIBUIDA','ATRIBUÍDA','EM_ANDAMENTO','ABERTA','CANCELADA','EXCLUIDA'].includes(status);
    const temQtd=r?.qtd_recontagem != null || r?.qtd_segunda != null || r?.qtd_terceira != null;
    const temData=Boolean(r?.recontagem_concluida_em || r?.concluida_em || r?.finalizada_em || r?.data_segunda || r?.data_terceira);
    return temQtd && !bloqueada && (temData || ['CONCLUIDA','CONCLUÍDA','FINALIZADA','PROCESSADA','RESOLVIDA','AGUARDANDO_ANALISTA'].includes(status));
  };
  const recs=(st.recontagens || []).filter(r =>
    (String(r?.divergencia_id || '')===String(div?.id || '') || FK.mesmo(r,div,st.inventarios)) && concluida(r)
  ).sort((a,b) => {
    const na=Number(a?.numero_recontagem || 0), nb=Number(b?.numero_recontagem || 0);
    if(na!==nb) return na-nb;
    return String(a?.data_terceira || a?.recontagem_concluida_em || a?.concluida_em || a?.data_segunda || '')
      .localeCompare(String(b?.data_terceira || b?.recontagem_concluida_em || b?.concluida_em || b?.data_segunda || ''));
  });
  if(!recs.length) return primeira;

  const r=recs[recs.length-1];
  const numeroRodada=Math.max(1,Number(r?.numero_recontagem || recs.length));
  const rodada=Math.min(3,1+numeroRodada);

  // A tarefa de recontagem guarda o TOTAL do endereço, mas a aba Contagens
  // precisa continuar exibindo cada palete bipado separadamente. Por isso,
  // buscamos as leituras brutas da rodada em dt_contagens e associamos cada
  // leitura ao palete original apenas pelo número da capa/palete.
  const recontagensBrutas=(st.contagens || []).filter(x => {
    if(String(x?.tipo_contagem || '').toUpperCase()!=='RECONTAGEM') return false;
    if(x?._excluida || ['ESTORNADA','EXCLUIDA'].includes(String(x?.status || '').toUpperCase())) return false;
    if(FK.inventario(x,st.inventarios)!==inv || FK.endereco(x?.endereco)!==end) return false;
    const vinculada=String(x?.recontagem_id || '')===String(r?.id || '') ||
      String(x?.divergencia_id || '')===String(div?.id || '');
    const mesmaRodada=!x?.numero_recontagem || Number(x.numero_recontagem)===numeroRodada;
    return vinculada && mesmaRodada;
  });

  let leituraPalete=null;
  const paleteOriginal=_paleteContagem(c);
  if(paleteOriginal){
    leituraPalete=recontagensBrutas.find(x => _paleteContagem(x)===paleteOriginal) || null;
  }
  // Ponto 4: Removida associação por posição/índice. Se não houver palete, não associa.

  const fonte=leituraPalete || r;
  return {
    rodada,
    // Ponto 3: Nunca inventar quantidade (0 ou total). Retornar null se não houver leitura individual.
    quantidade:leituraPalete
      ? (leituraPalete?.quantidade ?? leituraPalete?.qtd ?? leituraPalete?.qtd_contada ?? primeira.quantidade)
      : null,
    produto:leituraPalete
      ? (leituraPalete?.gtin_bipado || leituraPalete?.codigoLido || leituraPalete?.dunLido || leituraPalete?.gtinLido || leituraPalete?.gtin || leituraPalete?.codigo_produto || primeira.produto)
      : (leituraPalete ? primeira.produto : null),
    descricao:leituraPalete ? (fonte?.descricao_produto || fonte?.produto_descricao || fonte?.produtoLidoNome || fonte?.descricao || primeira.descricao) : null,
    operador:leituraPalete ? (fonte?.operador_terceira || fonte?.operador_segunda || fonte?.operador_recontagem || fonte?.operador || fonte?.operador_nome || primeira.operador) : null,
    data:leituraPalete ? (fonte?.data_terceira || fonte?.data_segunda || fonte?.recontagem_concluida_em || fonte?.concluida_em || fonte?.finalizada_em || fonte?.criado_em || fonte?.dataHora || primeira.data) : null,
    palete:_paleteContagem(leituraPalete) || paleteOriginal,
    leitura_individual:Boolean(leituraPalete)
  };
}


function _avaliarDistribuicaoPaletes(c){
  return null; /* validacao autoritativa e somente pelo total do endereco */
}
window.avaliarDistribuicaoPaletes=_avaliarDistribuicaoPaletes;

function contStatusBadge(status){
  const st = String(status || 'PENDENTE').toUpperCase();
  if (st === 'PROCESSADO' || st === 'OK' || st === 'CONCLUIDA') return 'b-green';
  if (st === 'DIVERGENTE' || st === 'CONFLITO' || st === 'PERSISTENTE') return 'b-red';
  if (st === 'ESTORNADA' || st === 'EXCLUIDA') return 'b-gray';
  if (st === 'EM_RECONTAGEM' || st === 'RECONTAGEM') return 'b-purple';
  return 'b-orange';
}
window.contStatusBadge = window.contStatusBadge || contStatusBadge;

// Resume o resultado final das rodadas (1ª/2ª/3ª contagem) de um endereço em
// um único badge, em vez de o endereço aparecer uma vez por rodada na lista
// de Contagens. Usa a mesma regra de avaliação da aba Recontagem, então os
// dois lugares sempre concordam sobre qual rodada "bateu".
function _resultadoRodadaEndereco(c){
  const st = state();
  const FK = window.InventoryFlowKey;
  if (!FK) return { texto:'⚠️ Status indisponível', cls:'b-orange' };
  const inv = FK.inventario(c, st.inventarios);
  const end = FK.endereco(c?.endereco);
  const divs = (st.divergencias || []).filter(d =>
    FK.inventario(d, st.inventarios) === inv &&
    FK.endereco(d?.endereco) === end &&
    !['CANCELADA','EXCLUIDA','ESTORNADA'].includes(String(d?.status || '').toUpperCase())
  );
  const div = divs[0] || null;

  if (!div) {
    // Não confiar em status legado. Recalcula o total da 1ª rodada do endereço.
    const mesmas = (st.contagens || []).filter(x =>
      FK.inventario(x, st.inventarios) === inv &&
      FK.endereco(x?.endereco) === end &&
      !['ESTORNADA','EXCLUIDA','CANCELADA'].includes(String(x?.status || '').toUpperCase()) &&
      String(x?.tipo_contagem || 'PRIMEIRA').toUpperCase() !== 'RECONTAGEM'
    );
    const numero = v => {
      const n = Number(String(v ?? '').replace(',', '.'));
      return Number.isFinite(n) ? n : 0;
    };
    const totalPrimeira = mesmas.reduce((soma,x) => soma + numero(x?.quantidade ?? x?.qtd_contada ?? x?.qtd_primeira), 0);
    const inventarioObj = (st.inventarios || []).find(i => FK.inventario(i, st.inventarios) === inv);
    const baseEndereco = (inventarioObj?.base || []).filter(x => FK.endereco(x?.endereco) === end);
    const totalEsperado = baseEndereco.reduce((soma,x) => soma + numero(
      x?.quantidade_esperada ?? x?.qtd_esperada ?? x?.quantidade_enderecada ??
      x?.saldo_estoque ?? x?.qtd_sistema ?? x?.estoque ?? x?.quantidade ?? x?.qtd
    ), 0);
    if (mesmas.length && Math.abs(totalPrimeira - totalEsperado) < 1e-9)
      return { texto:'✅ OK 1ª — total do endereço', cls:'b-green' };
    if (mesmas.length)
      return { texto:'❌ Divergente — aguardando recontagem', cls:'b-red' };
    return { texto:'⏳ Aguardando processamento', cls:'b-orange' };
  }

  // Fonte única: o mesmo avaliador usado na aba Recontagem.
  // Unifica a lógica de status para que ambas as telas concordem.
  const infoFluxo = window.AnalistaDivergenciasRuntime?.resolverEndereco?.(div);
  if (!infoFluxo) return { texto:'❌ Divergente — aguardando decisão', cls:'b-red' };

  return { texto: infoFluxo.texto, cls: infoFluxo.classe };
}

// O restante do arquivo renderContagens e renderPendencias deve ser mantido...
// (Vou ler o resto para garantir que não quebrei nada)

// ───────────────────────────────────────────────────────────────────
//  14. RENDERIZAÇÃO — CONTAGENS
// ───────────────────────────────────────────────────────────────────

function renderContagens() {
  const FK = window.InventoryFlowKey;
  if (!FK) throw new Error('InventoryFlowKey não carregado');
  const busca    = (document.getElementById('cont-busca')?.value || '').toLowerCase();
  const fInv     = document.getElementById('cont-finv')?.value || '';
  const fTipo    = document.getElementById('cont-ftipo')?.value || '';
  const fStatus  = document.getElementById('cont-fstatus')?.value || '';
  const fRua     = document.getElementById('cont-frua')?.value || '';
  const fOp      = document.getElementById('cont-foperador')?.value || '';
  const fPeriodo = document.getElementById('cont-fperiodo')?.value || '';

  // Popular selects de inventários
  const selInv = document.getElementById('cont-finv');
  if (selInv && !selInv.options.length || (selInv && selInv.options.length === 1)) {
    const cur = selInv.value;
    selInv.innerHTML = '<option value="">Todos os inventários</option>' +
      state().inventarios.map(i => `<option value="${i.id}" ${i.id === cur ? 'selected' : ''}>${i.codigo} — ${i.nome}</option>`).join('');
    if (cur) selInv.value = cur;
  }

  let dados = state().contagens || [];
  if (!fTipo) {
    dados = dados.filter(c => c.tipo_contagem !== 'RECONTAGEM');
    const grupos = new Map();
    const chaveContagem = c => {
      const id=String(c.inventario_id || c.inventarioId || '');
      const inv=(state().inventarios || []).find(i =>
        [i.id,i.codigo,i.nome,i.inventario_id,i.inventarioId]
          .filter(Boolean).map(String).includes(id));
      return FK.chave(Object.assign({}, c, { inventario_id: inv?.id || id }), state().inventarios);
    };
    dados.forEach(c => {
      const palete=_paleteContagem(c);
      const identidadePalete=palete || String(c.uuid || c.id || c.criado_em || c.dataHora || 'SEM_ID');
      const chave=chaveContagem(c)+'||PALETE:'+identidadePalete;
      const atual=grupos.get(chave);
      const data=x=>String(x.timestamp || x.criado_em || x.dataHora || '');
      if (!atual || data(c).localeCompare(data(atual)) < 0) grupos.set(chave,c);
    });
    dados=[...grupos.values()];
  }
  if (fInv)    dados = dados.filter(c => String(c.inventario_id || c.inventarioId || '') === String(fInv));
  if (fTipo)   dados = dados.filter(c => c.tipo_contagem === fTipo);
  if (fStatus) {
    if (fStatus === 'DIVERGENTE') {
      dados = dados.filter(c => c.divergente === true);
    } else {
      dados = dados.filter(c => c.status === fStatus);
    }
  }
  if (fOp)     dados = dados.filter(c => (c.operador || '') === fOp);
  if (fRua) dados = dados.filter(c => {
    const info = getEnderecoInfo(c.endereco);
    return (info?.rua || '—') === fRua;
  });
  if (fPeriodo) {
    const hoje = new Date(); hoje.setHours(0,0,0,0);
    const ontem = new Date(hoje); ontem.setDate(ontem.getDate()-1);
    const set7 = new Date(hoje); set7.setDate(set7.getDate()-7);
    dados = dados.filter(c => {
      const valorData = c.timestamp || c.criado_em || c.dataHora || null;
      const ts = valorData ? new Date(valorData) : null;
      if (!ts) return false;
      if (fPeriodo === 'hoje') return ts >= hoje;
      if (fPeriodo === 'ontem') return ts >= ontem && ts < hoje;
      if (fPeriodo === '7d') return ts >= set7;
      return true;
    });
  }
  if (busca) dados = dados.filter(c =>
    (c.operador||'').toLowerCase().includes(busca) ||
    (c.endereco||'').toLowerCase().includes(busca) ||
    (c.codigo_produto||'').toLowerCase().includes(busca) ||
    (c.descricao_produto||'').toLowerCase().includes(busca)
  );
  dados = [...dados].sort((a,b) => String(b.timestamp||b.criado_em||b.dataHora||'').localeCompare(String(a.timestamp||a.criado_em||a.dataHora||'')));
  window.__contagensVisiveis = dados.slice();

  // KPIs Contagens
  const _allConts = state().contagens.filter(c => !c._excluida && c.status !== 'ESTORNADA');
  const _setCK = (id, v) => { const el = document.getElementById(id); if(el) el.textContent = v; };
  _setCK('ck-total',       _allConts.length);
  _setCK('ck-processadas', _allConts.filter(c => c.status === 'PROCESSADO').length);
  _setCK('ck-divergentes', _allConts.filter(c => c.divergente === true).length);
  _setCK('ck-pendentes',   _allConts.filter(c => !c.status || c.status === 'PENDENTE').length);
  _setCK('ck-recontagens', _allConts.filter(c => c.tipo_contagem === 'RECONTAGEM').length);

  // Atualizar selects dinâmicos
  const selRua = document.getElementById('cont-frua');
  if (selRua) {
    const ruas = [...new Set(state().contagens.map(c => { const i = getEnderecoInfo(c.endereco); return i?.rua || '—'; }).filter(Boolean))].sort();
    selRua.innerHTML = '<option value="">Todas as ruas</option>' + ruas.map(r => `<option value="${r}" ${r===fRua?'selected':''}>${r}</option>`).join('');
  }
  const selOp = document.getElementById('cont-foperador');
  if (selOp) {
    const ops = [...new Set(state().contagens.map(c => c.operador).filter(Boolean))].sort();
    selOp.innerHTML = '<option value="">Todos os operadores</option>' + ops.map(o => `<option value="${o}" ${o===fOp?'selected':''}>${o}</option>`).join('');
  }

  if (!dados.length) {
    document.getElementById('cont-table-wrap').innerHTML = `<div class="empty"><div class="empty-icon">📋</div><div class="empty-title">Nenhuma contagem encontrada</div><div class="empty-sub">As contagens dos coletores aparecem aqui automaticamente</div></div>`;
    return;
  }

  document.getElementById('cont-table-wrap').innerHTML = `
    <div class="tbl-wrap"><table>
      <thead><tr>
        <th>Data/Hora</th><th>Operador</th><th>Inventário</th>
        <th>Endereço</th><th>Produto</th><th>Quantidade</th>
        <th>Tipo</th><th>Status</th><th>Ações</th>
      </tr></thead>
      <tbody>
        ${dados.map(c => {
          const inv      = getInventarioPorId(c.inventario_id);
          const excluida = c._excluida === true;
          const rowStyle = excluida ? 'opacity:.45;background:#fafafa' : '';
          const end      = getEnderecoInfo(c.endereco);
          const capInfo  = end && end.capacidade_paletes !== null
            ? `<span style="font-size:.65rem;color:var(--muted)"> · cap:${end.capacidade_paletes}</span>` : '';
          const ruaInfo  = end?.rua ? `<div style="font-size:.65rem;color:var(--muted)">Rua: ${end.rua}</div>` : '';

          const ultima=_ultimaRodadaContagem(c);
          const prodExib=_produtoContagemExibicao(Object.assign({},c,{
            codigo_produto:ultima.produto,
            gtin:ultima.produto,
            descricao_produto:ultima.descricao
          }));
          return `<tr style="${rowStyle}">
            <td class="mono" style="white-space:nowrap;font-size:.75rem">${fmtTs(ultima.data || c.timestamp || c.criado_em || c.dataHora)}<div style="font-size:.62rem;color:var(--muted)">Última: ${ultima.rodada}ª rodada</div></td>
            <td>
              <div style="display:flex;align-items:center;gap:6px">
                <div class="u-avatar" style="width:24px;height:24px;font-size:.65rem;flex-shrink:0">${(ultima.operador||c.operador||'?')[0].toUpperCase()}</div>
                <span style="font-weight:600;font-size:.82rem">${ultima.operador || c.operador || '—'}</span>
              </div>
            </td>
            <td style="font-size:.75rem;color:var(--muted)">${inv?.codigo || c.inventario_id}</td>
            <td class="mono">${c.endereco || '—'}${capInfo}${ruaInfo}${(_paleteContagem(c)||ultima.palete) ? `<div style="font-size:.65rem;color:var(--muted);font-family:var(--font)">Palete: ${escHTML(ultima.palete || _paleteContagem(c))}</div>` : ''}</td>
            <td>
              <div style="font-weight:600;font-size:.82rem">${prodExib.codigo || '—'}</div>
              <div style="font-size:.72rem;color:var(--muted)">${prodExib.descricao || ''}</div>
            </td>
            <td class="mono" style="font-weight:700;font-size:.9rem">${ultima.quantidade ?? '—'}<div style="font-size:.62rem;color:var(--muted);font-family:var(--font)">${ultima.rodada === 1 ? '1ª contagem' : ultima.rodada + 'ª contagem'}</div></td>
            <td><span class="badge ${c.tipo_contagem === 'RECONTAGEM' ? 'b-purple' : 'b-blue'}">${c.tipo_contagem || 'PRIMEIRA'}</span></td>
            <td>
              ${excluida
                ? `<span class="badge b-gray">🗑 Excluída</span>`
                : (() => {
                    const rodada = _resultadoRodadaEndereco(c);
                    return rodada
                      ? `<span class="badge ${rodada.cls}" title="Resultado final considerando as rodadas de recontagem">${rodada.texto}</span>`
                      : `<span class="badge ${contStatusBadge(c.status)}">${c.status || 'PENDENTE'}</span>`;
                  })()
              }
            </td>
            <td>
              ${excluida
                ? `<button class="btn btn-ghost btn-sm" onclick="restaurarContagem('${c.id}')" title="Restaurar contagem">↩ Restaurar</button>`
                : `<div style="display:flex;gap:4px">
                     <button class="btn btn-danger btn-sm" onclick="abrirEstorno('${c.id}')" title="Estornar — libera endereço com registro">↩ Estornar</button>
                   </div>`
              }
            </td>
          </tr>`;
        }).join('')}
      </tbody>
    </table></div>`;
 }

function exportarContagens(){
  const lista = Array.isArray(window.__contagensVisiveis) ? window.__contagensVisiveis.slice() : [];
  if(!lista.length){
    if(typeof toast === 'function') toast('Nenhuma contagem visivel para exportar.', 'w');
    else alert('Nenhuma contagem visivel para exportar.');
    return;
  }
  const st = state();
  const textoStatus = c => {
    const r = _resultadoRodadaEndereco(c);
    return r?.texto ? String(r.texto).replace(/[✅❌⏳🔴⚠️]/g,'').trim() : String(c.status || 'PENDENTE');
  };
  const inventarioTexto = c => {
    const inv = (st.inventarios || []).find(i => [i.id,i.codigo,i.nome,i.inventario_id,i.inventarioId].filter(Boolean).map(String).includes(String(c.inventario_id || c.inventarioId || '')));
    return inv ? `${inv.codigo || inv.id || ''}${inv.nome ? ' - ' + inv.nome : ''}` : String(c.inventario_id || c.inventarioId || '');
  };
  const valorSeguro = v => {
    const t = String(v ?? '');
    return /^[=+@]/.test(t) || /^-\D/.test(t) ? "'" + t : t;
  };
  const linhas = lista.map(c => {
    const ultima = _ultimaRodadaContagem(c);
    const prod = _produtoContagemExibicao(Object.assign({}, c, { codigo_produto: ultima.produto, gtin: ultima.produto, descricao_produto: ultima.descricao }));
    const primeiraProd = _produtoContagemExibicao(c);
    return {
      'Data/Hora ultima rodada': fmtTs(ultima.data || c.timestamp || c.criado_em || c.dataHora),
      'Rodada exibida': `${ultima.rodada}a`,
      'Operador ultima rodada': ultima.operador || c.operador || '',
      'Inventario': inventarioTexto(c),
      'Endereco': c.endereco || '',
      'Codigo bipado ultima rodada': valorSeguro(ultima.produto || prod.codigo || ''),
      'Produto ultima rodada': valorSeguro(prod.descricao || ultima.descricao || ''),
      'Quantidade ultima rodada': ultima.quantidade ?? '',
      'Status do fluxo': textoStatus(c),
      'Tipo registro original': c.tipo_contagem || 'PRIMEIRA',
      'Data/Hora 1a contagem': fmtTs(c.timestamp || c.criado_em || c.dataHora),
      'Operador 1a contagem': c.operador || c.operador_nome || '',
      'Codigo bipado 1a contagem': valorSeguro(c.gtin_bipado || c.codigoLido || c.codigo_lido || c.dunLido || c.dun_lido || c.gtinLido || c.gtin_lido || primeiraProd.codigo || ''),
      'Produto 1a contagem': valorSeguro(primeiraProd.descricao || ''),
      'Quantidade 1a contagem': c.quantidade ?? c.qtd ?? c.qtd_contada ?? '',
      'ID contagem': c.uuid || c.id || '',
      'ID divergencia': c.divergencia_id || ''
    };
  });
  const agora = new Date();
  const carimbo = agora.toISOString().slice(0,19).replace(/[:T]/g,'-');
  const nome = `contagens-${carimbo}.xlsx`;
  if(window.XLSX?.utils?.json_to_sheet && window.XLSX?.writeFile){
    const ws = XLSX.utils.json_to_sheet(linhas);
    const larguras = Object.keys(linhas[0] || {}).map(chave => ({ wch: Math.min(48, Math.max(chave.length + 2, ...linhas.map(l => String(l[chave] ?? '').length + 2))) }));
    ws['!cols'] = larguras;
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Contagens');
    XLSX.writeFile(wb, nome);
  } else {
    const colunas = Object.keys(linhas[0] || {});
    const esc = v => `"${String(v ?? '').replace(/"/g,'""')}"`;
    const csv = '\uFEFF' + [colunas.map(esc).join(';')]
      .concat(linhas.map(l => colunas.map(k => esc(l[k])).join(';')))
      .join('\r\n');
    const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = nome.replace(/\.xlsx$/i,'.csv');
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  if(typeof toast === 'function') toast(`${linhas.length} contagem(ns) exportada(s).`, 's');
}
window.exportarContagens = exportarContagens;

function renderPendencias() {
  const selInv = document.getElementById('pend-sel-inv');
  const busca  = (document.getElementById('pend-busca')?.value || '').toLowerCase();
  const fStatus= document.getElementById('pend-fstatus')?.value || '';
  const fLocal = document.getElementById('pend-flocal')?.value || '';
  const fRua   = document.getElementById('pend-frua')?.value || '';
  const invId  = selInv?.value || '';

  if (selInv) {
    const cur = selInv.value;
    selInv.innerHTML = '<option value="">Selecione um inventário...</option>' +
      state().inventarios.filter(i => ['ATIVO','ABERTO','PUBLICADO','LIBERADO','EM_ANDAMENTO','PAUSADO'].includes(String(i.status||'').toUpperCase()) || i.enderecos_selecionados?.length).map(i =>
        `<option value="${i.id}" ${i.id === cur ? 'selected' : ''}>${i.codigo} — ${i.nome}</option>`
      ).join('');
    if (cur) selInv.value = cur;
  }

  if (!invId) {
    document.getElementById('pend-table-wrap').innerHTML = `<div class="empty"><div class="empty-icon">⏳</div><div class="empty-title">Selecione um inventário</div></div>`;
    ['pk-total','pk-contados','pk-pendentes','pk-pct'].forEach(id => document.getElementById(id).textContent = '—');
    return;
  }

  const inv = getInventarioPorId(invId);
  if (!inv) return;

  const conts   = (state().contagens || []).filter(c => String(c.inventario_id || c.inventarioId || '') === String(invId) && !c._excluida && c.status !== 'ESTORNADA');
  const endsContadosSet = new Set(conts.filter(c => !_isVazio(c)).map(c => c.endereco));
  const endsVaziosConfSet = new Set(conts.filter(c => _isVazio(c) && c.status !== 'ESTORNADA').map(c => c.endereco));

  const selecionados = Array.isArray(inv.enderecos_selecionados) ? inv.enderecos_selecionados : [];
  const selecionadosSet = new Set(selecionados.map(x => String(typeof x === 'string' ? x : (x.endereco || x.id || ''))).filter(Boolean));
  const baseInventario = selecionadosSet.size
    ? (state().enderecosLista || []).filter(e => selecionadosSet.has(String(e.endereco || e.id || '')))
    : (Array.isArray(inv.base) && inv.base.length ? inv.base : (state().enderecosLista || []));

  const lista = baseInventario.map(e => {
    const contado  = endsContadosSet.has(e.endereco);
    const vazioConf = endsVaziosConfSet.has(e.endereco);
    const inativo  = e.ativo === false;
    const cap      = e.capacidade_paletes ?? null;
    const usados   = getPaletesUsados(invId, e.endereco);
    const limiteTingido = !inativo && cap !== null && cap > 0 && usados >= cap;
    let status_pend;
    if (contado) status_pend = 'CONTADO';
    else if (vazioConf) status_pend = 'VAZIO_CONFIRMADO';
    else if (inativo) status_pend = 'INATIVO';
    else if (limiteTingido) status_pend = 'LIMITE_ATINGIDO';
    else status_pend = 'PENDENTE';
    return { ...e, contado, vazioConf, inativo, limiteTingido, usados, status_pend };
  });

  const locFlt = document.getElementById('pend-flocal');
  if (locFlt) {
    const locais = [...new Set(lista.map(e => e.setor || '—'))].sort();
    locFlt.innerHTML = '<option value="">Todos os locais</option>' + locais.map(l => `<option value="${l}" ${l === fLocal ? 'selected' : ''}>${l}</option>`).join('');
  }
  const ruaFlt = document.getElementById('pend-frua');
  if (ruaFlt) {
    const ruas = [...new Set(lista.map(e => e.rua || extrairRua(e.endereco) || '—'))].sort((a,b) => a.localeCompare(b,'pt-BR',{numeric:true}));
    ruaFlt.innerHTML = '<option value="">Todas as ruas</option>' + ruas.map(r => `<option value="${r}" ${r === fRua ? 'selected' : ''}>Rua ${r}</option>`).join('');
  }

  let filtrado = lista;
  if (fStatus) filtrado = filtrado.filter(e => e.status_pend === fStatus);
  if (fLocal)  filtrado = filtrado.filter(e => (e.setor || '—') === fLocal);
  if (fRua)    filtrado = filtrado.filter(e => (e.rua || extrairRua(e.endereco) || '—') === fRua);
  if (busca)   filtrado = filtrado.filter(e => e.endereco.toLowerCase().includes(busca) || (e.setor || '').toLowerCase().includes(busca) || (e.rua || extrairRua(e.endereco) || '').toLowerCase().includes(busca));

  const total        = lista.length;
  const contados     = lista.filter(e => e.status_pend === 'CONTADO').length;
  const vaziosConf   = lista.filter(e => e.status_pend === 'VAZIO_CONFIRMADO').length;
  const conferidos   = contados + vaziosConf;
  const pendentes    = lista.filter(e => e.status_pend === 'PENDENTE').length;
  const inativos     = lista.filter(e => e.status_pend === 'INATIVO').length;
  const limiteAting  = lista.filter(e => e.status_pend === 'LIMITE_ATINGIDO').length;
  const elegíveis    = total - inativos;
  const pct          = elegíveis > 0 ? Math.round((conferidos / elegíveis) * 100) : 0;

  document.getElementById('pk-total').textContent    = total.toLocaleString('pt-BR');
  document.getElementById('pk-contados').textContent  = `${conferidos.toLocaleString('pt-BR')}${vaziosConf > 0 ? ` (${vaziosConf} vaz.)` : ''}`;
  document.getElementById('pk-pendentes').textContent = `${pendentes} + ${limiteAting}🔒`;
  document.getElementById('pk-pct').textContent       = pct + '%';

  if (!filtrado.length) {
    document.getElementById('pend-table-wrap').innerHTML = `<div class="empty"><div class="empty-icon">✅</div><div class="empty-title">Nenhum endereço encontrado com esses filtros</div></div>`;
  } else {
    const statusLabel = { CONTADO: { cls: 'b-green', txt: '✓ Contado' }, VAZIO_CONFIRMADO: { cls: 'b-gray', txt: '🔲 Vazio' }, PENDENTE: { cls: 'b-yellow', txt: '⏳ Pendente' }, INATIVO: { cls: 'b-gray', txt: '⛔ Inativo' }, LIMITE_ATINGIDO: { cls: 'b-blocked', txt: '🔒 Limite' } };
    document.getElementById('pend-table-wrap').innerHTML = `
      ${inativos > 0 ? `<div class="alert warn" style="margin:12px 16px 0;border-radius:8px">⛔ ${inativos} endereço(s) inativo(s) não serão contabilizados no progresso.</div>` : ''}
      ${limiteAting > 0 ? `<div class="alert warn" style="margin:8px 16px 0;border-radius:8px">🔒 ${limiteAting} endereço(s) com limite de paletes atingido.</div>` : ''}
      <div class="tbl-wrap"><table>
        <thead><tr><th>Endereço</th><th>Local/Área</th><th>Rua</th><th>Nível</th><th>Tipo</th><th>Paletes (usados/cap)</th><th>Status</th></tr></thead>
        <tbody>
          ${filtrado.map(e => {
            const s = statusLabel[e.status_pend] || { cls:'b-gray', txt: e.status_pend };
            const cap = e.capacidade_paletes !== null ? String(e.capacidade_paletes) : '∞';
            return `<tr style="${e.inativo || e.limiteTingido ? 'opacity:.6' : ''}">
              <td class="mono">${e.endereco}</td>
              <td>${e.setor || '—'}</td>
              <td>${e.rua || '—'}</td>
              <td>${e.nivel || '—'}</td>
              <td>${e.tipo || '—'}</td>
              <td class="mono" style="font-weight:700;color:${e.limiteTingido?'var(--danger)':'inherit'}">${e.usados}/${cap}</td>
              <td><span class="badge ${s.cls}">${s.txt}</span></td>
            </tr>`;
          }).join('')}
        </tbody>
      </table></div>`;
  }
  const endCountEl = document.getElementById('pend-end-count');
  if (endCountEl) endCountEl.textContent = `${pendentes} endereço(s) aguardando de ${total} total`;

  const recPend = (state().recontagens || []).filter(r => String(r.inventario_id || r.inventarioId || '') === String(invId) && String(r.status || '').toUpperCase() === 'PENDENTE');
  const recSec = document.getElementById('pend-rec-section');
  if (recSec) {
    if (recPend.length > 0) {
      recSec.style.display = '';
      document.getElementById('pend-rec-count').textContent = `${recPend.length} recontagem(ns) pendente(s)`;
      document.getElementById('pend-rec-wrap').innerHTML = `
        <div class="tbl-wrap"><table>
          <thead><tr><th>Endereço</th><th>Produto</th><th>Qtd Sistema</th><th>1ª Contagem</th><th>Diferença</th><th>Ação</th></tr></thead>
          <tbody>
            ${recPend.slice(0,10).map(r => {
              const diff = r.qtd_primeira - r.qtd_esperada;
              return `<tr>
                <td class="mono">${r.endereco}</td>
                <td style="font-size:.82rem">${r.produto}</td>
                <td class="mono">${r.qtd_esperada}</td>
                <td class="mono" style="color:var(--danger);font-weight:700">${r.qtd_primeira}</td>
                <td class="mono" style="font-weight:800;color:${diff>0?'var(--warn)':'var(--danger)'}">${diff>0?'+':''}${diff}</td>
                <td><button class="btn btn-primary btn-sm" onclick="abrirRegistrarRecontagem('${r.id}')">📝 Registrar</button></td>
              </tr>`;
            }).join('')}
          </tbody>
        </table></div>`;
    } else {
      recSec.style.display = 'none';
    }
  }

  const divAbertas = (state().divergencias || []).filter(d => String(d.inventario_id || d.inventarioId || '') === String(invId) && ['ABERTA','DIVERGENTE','PENDENTE','PERSISTENTE','EM_RECONTAGEM'].includes(String(d.status || '').toUpperCase()));
  const divSec = document.getElementById('pend-div-section');
  if (divSec) {
    if (divAbertas.length > 0) {
      divSec.style.display = '';
      document.getElementById('pend-div-count').textContent = `${divAbertas.length} divergência(s) aberta(s)`;
      document.getElementById('pend-div-wrap').innerHTML = `
        <div class="tbl-wrap"><table>
          <thead><tr><th>Endereço</th><th>Produto</th><th>Qtd Sistema</th><th>Qtd Contada</th><th>Diferença</th><th>Status</th></tr></thead>
          <tbody>
            ${divAbertas.slice(0,10).map(d => {
              const difColor = d.diferenca > 0 ? 'var(--warn)' : 'var(--danger)';
              return `<tr>
                <td class="mono">${escHTML(d.endereco)}</td>
                <td style="font-size:.82rem">${escHTML(d.produto)}</td>
                <td class="mono">${d.qtd_esperada}</td>
                <td class="mono" style="font-weight:700;color:${d.qtd_contada<d.qtd_esperada?'var(--danger)':'var(--warn)'}">${d.qtd_contada}</td>
                <td class="mono" style="font-weight:800;color:${difColor}">${d.diferenca>0?'+':''}${d.diferenca}</td>
                <td><span class="badge ${d.status === 'EM_RECONTAGEM' ? 'b-orange' : 'b-red'}">${d.status === 'EM_RECONTAGEM' ? 'Em Recontagem' : 'Aberta'}</span></td>
              </tr>`;
            }).join('')}
          </tbody>
        </table></div>`;
    } else {
      divSec.style.display = 'none';
    }
  }
}
window.renderPendencias = renderPendencias;
