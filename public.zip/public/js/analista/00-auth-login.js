// ══════════════════════════════════════════════════════════════════════
//  00-AUTH-LOGIN.JS (VERSÃO AJUSTADA E ESTÁVEL)
// ══════════════════════════════════════════════════════════════════════

function state(){ return window.AnalistaStore.getState(); }

// ── FIREBASE ─────────────────────────────────────────────────────────
// Inicializacao tolerante a cache antigo e carregamento lento. O modulo nao
// deixa de exportar doLoginAnalista caso o Firebase ainda nao esteja pronto.
var FS_AN = null;
var AUTH_AN = null;
var _authListenerRegistrado = false;

function _prepararFirebaseAnalista() {
  try {
    if (typeof window.getDTFirebaseApp !== 'function' ||
        typeof window.getDTFirestore !== 'function' ||
        typeof window.getDTAuth !== 'function') return false;
    window.getDTFirebaseApp();
    FS_AN = window.getDTFirestore();
    AUTH_AN = window.getDTAuth();
    window.FS_AN = FS_AN;
    window.AUTH_AN = AUTH_AN;
    return !!AUTH_AN;
  } catch (err) {
    console.error('[Login Analista] Falha ao preparar Firebase:', err);
    return false;
  }
}

_prepararFirebaseAnalista();

window._currentAnalistaUser = null;
var _loginSolicitadoPeloUsuario = false;
var DT_LOGIN_MEM_KEY = 'dt_analista_login_lembrado_v1';

function _normalizarEmailAnalista(valor) {
  // Mantém exatamente o e-mail cadastrado no Firebase Authentication.
  // Apenas remove espaços e converte para minúsculas.
  return String(valor || '').trim().toLowerCase().replace(/\s+/g, '');
}

function _carregarLoginLembrado() {
  try {
    const salvo = JSON.parse(localStorage.getItem(DT_LOGIN_MEM_KEY) || 'null');
    if (!salvo || !salvo.email) return;
    const email = document.getElementById('an-email');
    const lembrar = document.getElementById('an-remember');
    if (email) email.value = salvo.email;
    if (lembrar) lembrar.checked = true;
  } catch (err) {
    console.warn('[Login Analista] Não foi possível recuperar o e-mail lembrado:', err);
  }
}

function _salvarOuLimparLogin(email) {
  const lembrar = document.getElementById('an-remember')?.checked === true;
  try {
    if (lembrar) localStorage.setItem(DT_LOGIN_MEM_KEY, JSON.stringify({ email }));
    else localStorage.removeItem(DT_LOGIN_MEM_KEY);
  } catch (err) {
    console.warn('[Login Analista] Não foi possível atualizar a preferência de login:', err);
  }
}

// ── LOGIN ────────────────────────────────────────────────────────────

async function doLoginAnalista(event) {
  try {
    if (event && typeof event.preventDefault === 'function') event.preventDefault();
    const btn = document.getElementById('btn-login-analista');
    const textoOriginal = btn ? btn.textContent : 'ENTRAR';
    if (btn) {
      btn.disabled = true;
      btn.textContent = 'ENTRANDO...';
      btn.setAttribute('aria-busy', 'true');
    }

    _clearLoginErro();
    const email = _normalizarEmailAnalista(document.getElementById('an-email')?.value || '');
    const senha = document.getElementById('an-pass')?.value || '';
    if (!email) throw new Error('Informe o e-mail.');
    if (!senha) throw new Error('Informe a senha.');
    if (!_prepararFirebaseAnalista()) throw new Error('Firebase não iniciou. Atualize a página e tente novamente.');
    _registrarListenerAuthAnalista();

    _salvarOuLimparLogin(email);
    _loginSolicitadoPeloUsuario = true;
    await AUTH_AN.setPersistence(firebase.auth.Auth.Persistence.NONE);
    await AUTH_AN.signInWithEmailAndPassword(email, senha);

    // O onAuthStateChanged conclui a abertura do painel. Mantém feedback visível
    // enquanto o ambiente da loja é preparado.
    if (btn) btn.textContent = 'PREPARANDO...';
  } catch (err) {
    _loginSolicitadoPeloUsuario = false;
    const msg = err && err.code ? _traduzirErroLoginAnalista(err) : (err?.message || 'Não foi possível realizar o login.');
    _setLoginErro(msg);
    console.error('[Login Analista]', err);
    const btn = document.getElementById('btn-login-analista');
    if (btn) {
      btn.disabled = false;
      btn.textContent = 'ENTRAR';
      btn.removeAttribute('aria-busy');
    }
  }
}

async function enviarRecuperacaoSenhaAnalista(event) {
  event?.preventDefault?.();
  _clearLoginErro();
  if (!_prepararFirebaseAnalista()) return _setLoginErro('Não foi possível iniciar o Firebase. Atualize a página.');
  let email = _normalizarEmailAnalista(document.getElementById('an-email')?.value || '');
  if (!email) return _setLoginErro('Informe o e-mail do Analista para receber o link de redefinição.');
  if (!email.includes('@')) email += '@daterrinhaalimentos.com.br';
  try {
    await AUTH_AN.sendPasswordResetEmail(email);
    _setLoginErro('Se este e-mail estiver cadastrado, o link para criar uma nova senha será enviado.');
  } catch (err) {
    if (err?.code === 'auth/invalid-email') return _setLoginErro('Informe um e-mail válido.');
    if (err?.code === 'auth/too-many-requests') return _setLoginErro('Muitas tentativas. Aguarde alguns minutos e tente novamente.');
    if (err?.code === 'auth/network-request-failed') return _setLoginErro('Não foi possível conectar. Verifique a internet e tente novamente.');
    _setLoginErro('Se este e-mail estiver cadastrado, o link para criar uma nova senha será enviado.');
  }
}

function doLogoutAnalista() {
  if (!_prepararFirebaseAnalista()) { _mostrarLogin(); return; }
  _loginSolicitadoPeloUsuario = false;
  AUTH_AN.signOut().then(() => {
    window._currentAnalistaUser = null;
    _mostrarLogin();
  });
}

function togglePassAnalista() {
  const f = document.getElementById('an-pass');
  if (f) f.type = f.type === 'password' ? 'text' : 'password';
}

function _traduzirErroLoginAnalista(err) {
  const code = err?.code || '';
  const mensagens = {
    'auth/invalid-credential': 'E-mail ou senha incorretos. Digite exatamente o mesmo e-mail cadastrado no Firebase Authentication.',
    'auth/invalid-email': 'O e-mail informado é inválido.',
    'auth/user-disabled': 'Este usuário está desativado no Firebase.',
    'auth/too-many-requests': 'Muitas tentativas. Aguarde alguns minutos e tente novamente.',
    'auth/network-request-failed': 'Não foi possível conectar ao Firebase. Verifique a internet.'
  };
  return mensagens[code] || err?.message || 'Não foi possível realizar o login.';
}

function _setLoginErro(msg) {
  const el = document.getElementById('login-error-msg');
  if (el) {
    el.textContent = msg;
    el.classList.add('show');
  }
}

function _clearLoginErro() {
  const el = document.getElementById('login-error-msg');
  if (el) {
    el.textContent = '';
    el.classList.remove('show');
  }
}

// ── LOGIN OK ─────────────────────────────────────────────────────────

async function _onAnalistaLogado(user) {
  window._currentAnalistaUser = user;

  if (window.AnalistaStore) {
    window.AnalistaStore.dispatch(window.AnalistaActions.setCurrentUser(user));
  }

  const nome = user.displayName || user.email.split('@')[0];

  const elNome   = document.getElementById('user-name-display');
  const elAvatar = document.getElementById('avatar-initials');

  if (elNome)   elNome.textContent   = nome;
  if (elAvatar) elAvatar.textContent = nome.slice(0,2).toUpperCase();

  try {
    const raw = window.getDTRawFirestore();
    const acc = await raw.collection('usuarios_acessos').doc(user.uid).get();
    let acesso = acc.exists ? { uid:user.uid, ...acc.data() } : null;

    if (!acesso || acesso.ativo === false) {
      throw new Error('Este login não possui acesso ativo. Solicite o provisionamento ao administrador.');
    }
    window.DT_USUARIO_ACESSO_ATUAL = acesso;

    // Quando o administrador definiu os canais, o painel só aceita usuários
    // com acesso explícito ao Analista. Cadastros antigos continuam compatíveis.
    if (acesso?.canais_acesso && acesso.canais_acesso.analista !== true) {
      throw new Error('Este login possui acesso somente ao Coletor.');
    }

    const permitidas = await window.DTLoja.garantirLojaInicial();
    if (!permitidas.length) throw new Error('Este login não possui acesso a nenhuma loja. Solicite a liberação ao administrador.');
    const atual = window.getDTLojaAtiva();
    if (atual && !permitidas.some(l=>l.id===atual)) window.setDTLojaAtiva('');
    await window.DTLoja.selecionarInterativamente('Selecione a loja do inventário');

    // Corrige uma única vez filiais que receberam dados da raiz por engano nas
    // versões anteriores. A Loja Matriz nunca é limpa por esta rotina.
    if (typeof window.corrigirIsolamentoLojaAtual === 'function') {
      const correcao = await window.corrigirIsolamentoLojaAtual();
      if (correcao && correcao.corrigido) console.info('[Multiloja] Isolamento corrigido:', correcao.total);
    }

    // A migração dos dados legados não deve bloquear o login nem iniciar
    // múltiplas filas de escrita. Ela é disparada depois que o painel abre,
    // com trava única, checkpoints e lotes pequenos.
  }
  catch(e){ _setLoginErro('Não foi possível preparar o ambiente da loja: '+e.message); await AUTH_AN.signOut(); return; }
  _mostrarApp();
  if (typeof window.aplicarPermissoesAnalista === 'function') {
    window.aplicarPermissoesAnalista();
  }
  atualizarIndicadorLojaAtual();

  // 🔥 CHAMADA SEGURA DO INIT
  if (window.AnalistaBootstrap?.initApp) {
    window.AnalistaBootstrap.initApp();
  } else if (window.initApp) {
    window.initApp();
  } else {
    console.error('[Auth] initApp não disponível');
  }

  logSistema('SISTEMA', 'Login realizado', { email: user.email });

  if (typeof window.sincronizarDadosLegadosAutomaticamente === 'function') {
    setTimeout(function(){
      window.sincronizarDadosLegadosAutomaticamente().then(function(migracao){
        if (migracao && migracao.executado) {
          console.info('[Multiloja] Migração legada concluída:', migracao.total);
          try { showToast('Dados antigos carregados na loja atual.', 'success'); } catch(_){ console.warn("[Erro tratado]", _); }
        }
      }).catch(function(error){
        console.error('[Multiloja] Falha na migração controlada:', error);
        try { showToast('Não foi possível concluir a migração dos dados antigos. Tente novamente pela Gestão de Lojas.', 'error'); } catch(_){ console.warn("[Erro tratado]", _); }
      });
    }, 1200);
  }
}

// ── UI ───────────────────────────────────────────────────────────────

function _mostrarApp() {
  document.getElementById('screen-login')?.style.setProperty('display','none');
  document.getElementById('app-main')?.style.setProperty('display','flex');
}

function _mostrarLogin() {
  document.getElementById('app-main')?.style.setProperty('display','none');
  document.getElementById('screen-login')?.style.setProperty('display','flex');
}

// ── SESSION ──────────────────────────────────────────────────────────
// Nunca reaproveita sessão anterior. Só abre o painel depois que o usuário
// clicar em Entrar ou pressionar Enter com e-mail e senha preenchidos.
function _registrarListenerAuthAnalista() {
  if (_authListenerRegistrado || !_prepararFirebaseAnalista()) return false;
  _authListenerRegistrado = true;
  AUTH_AN.onAuthStateChanged(async user => {
    if (user) {
      if (!_loginSolicitadoPeloUsuario) {
        await AUTH_AN.signOut();
        _mostrarLogin();
        return;
      }
      _loginSolicitadoPeloUsuario = false;
      await _onAnalistaLogado(user);
      return;
    }
    _mostrarLogin();
  });
  return true;
}

async function _iniciarAuthAnalista() {
  _loginSolicitadoPeloUsuario = false;
  _mostrarLogin();
  _carregarLoginLembrado();
  if (!_registrarListenerAuthAnalista()) {
    let tentativas = 0;
    const timer = setInterval(() => {
      tentativas += 1;
      if (_registrarListenerAuthAnalista() || tentativas >= 20) clearInterval(timer);
    }, 250);
  }
}

_iniciarAuthAnalista();

// ── UTIL ─────────────────────────────────────────────────────────────

// ── TOAST (feedback visual real, usa a <div id="toast"> já existente no HTML) ──
let _toastTimer;
function showToast(msg, type) {
  const el = document.getElementById('toast');
  if (!el) { window.dbg('[Toast]', msg); return; }
  el.className = 'toast' + (type ? ' ' + type : '');
  el.textContent = msg;
  void el.offsetWidth; // força reflow para reiniciar a animação
  el.classList.add('show');
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
}

// ── MODAL GENÉRICO (abre/fecha qualquer .modal-bg pelo id) ──
// Antes desta correção, openModal/closeModal eram CHAMADAS em ~20 lugares do
// app mas nunca haviam sido definidas — todo modal (login rápido de operador,
// simular coletor, importar endereços etc.) simplesmente não abria.
function openModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.add('open');
}
function closeModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.remove('open');
}

// ── CONFIRMAÇÃO CUSTOMIZADA (substitui o confirm() nativo) ──
function showConfirm(msg, onOk, opts) {
  opts = opts || {};
  const modalId = 'modal-confirm-generico';
  const modal = document.getElementById(modalId);
  if (!modal) { if (confirm(msg)) onOk(); return; } // fallback de segurança
  document.getElementById('mcg-icon').textContent  = opts.icon  || '⚠️';
  document.getElementById('mcg-title').textContent = opts.title || 'Confirmar';
  document.getElementById('mcg-msg').textContent   = msg;
  const btnOk = document.getElementById('mcg-ok');
  btnOk.textContent = opts.okLabel || 'Confirmar';
  btnOk.className   = 'btn ' + (opts.okClass || 'btn-danger');
  btnOk.style.background = opts.okColor || '';
  btnOk.onclick = () => { closeModal(modalId); onOk(); };
  openModal(modalId);
}

// ── LOG DE AUDITORIA (grava no Firestore; nunca lança erro) ──
// Antes desta correção, logAuditoria() era chamada dentro de aprovarColetor()
// e bloquearColetor() mas não existia — a função estourava um erro DEPOIS do
// Firestore já ter sido atualizado com sucesso, e esse erro caía no catch()
// da própria função, fazendo aparecer "Erro ao aprovar" mesmo quando a
// aprovação tinha funcionado.
async function logAuditoria(tipo, descricao, dados) {
  try {
    if (window.FS_AN) {
      const user = window.AUTH_AN?.currentUser || window._currentAnalistaUser;
      if(!user?.uid) throw new Error('Usuário autenticado ainda não está disponível para registrar o log.');
      return await window.FS_AN.collection('dt_logs_analista').add({
        tipo:       tipo || 'SISTEMA',
        descricao:  descricao || '',
        dados:      dados !== undefined ? dados : null,
        usuario:    user ? (user.displayName || user.email) : null,
        usuario_uid:user ? user.uid : null,
        criado_em:  new Date().toISOString(),
      });
    }
  } catch (e) { console.error('[logAuditoria]', e); return null; }
  window.dbg('[LOG]', tipo, descricao, dados);
}
function logSistema(tipo, desc, dados) { return logAuditoria(tipo, desc, dados); }

function atualizarBadgesNav(){
  try {
    const st = window.AnalistaStore?.getState?.() || {};
    const conts = window.AnalistaDivergenciasRuntime?.fotografiaFisicaAtual?.() || (st.contagens || []).filter(c => !c._excluida && c.status !== 'ESTORNADA');
    const divs  = (st.divergencias || []).filter(d => !['RESOLVIDA','CANCELADA'].includes(String(d.status||'').toUpperCase()));
    const recs  = (st.recontagens || []).filter(r => !['CONCLUIDA','CANCELADA','RESOLVIDA'].includes(String(r.status||'').toUpperCase()));
    const invs  = st.inventarios || [];
    const ativos = new Set(['ATIVO','ABERTO','PUBLICADO','LIBERADO','EM_ANDAMENTO','PAUSADO']);
    const invAtivos = invs.filter(i => ativos.has(String(i.status||'').toUpperCase()));
    let pend = 0;
    invAtivos.forEach(inv => {
      const ids = Array.isArray(inv.enderecos_selecionados) ? inv.enderecos_selecionados : [];
      if (!ids.length) return;
      const feitos = new Set(conts.filter(c => String(c.inventario_id||c.inventarioId||'')===String(inv.id)).map(c => String(c.endereco||'')));
      pend += ids.filter(e => !feitos.has(String(typeof e==='string'?e:(e.endereco||e.id||'')))).length;
    });
    const set=(id,v)=>{const el=document.getElementById(id);if(el)el.textContent=String(v)};
    set('nb-contagens', conts.length);
    set('nb-pendencias', pend);
    set('nb-divergencias', divs.length);
    set('nb-recontagens', recs.length);
  } catch(e) { console.warn('[Badges inventário]', e.message); }
}

function updateStaticTexts(){}

// ── EXPORT GLOBAL (🔥 ESSENCIAL PRA NÃO DAR ERRO) ─────────────────────

window.doLoginAnalista = doLoginAnalista;
window.doLogoutAnalista = doLogoutAnalista;
window.enviarRecuperacaoSenhaAnalista = enviarRecuperacaoSenhaAnalista;
window.togglePassAnalista = togglePassAnalista;

window.updateStaticTexts = updateStaticTexts;
window.atualizarBadgesNav = atualizarBadgesNav;

window.showToast = showToast;
window.showConfirm = showConfirm;
window.logSistema = logSistema;
window.logAuditoria = logAuditoria;
window.openModal = openModal;
window.closeModal = closeModal;

// Ligação direta do botão, sem depender de onclick inline ou da ordem do cache.
function _vincularLoginAnalista() {
  const btn = document.getElementById('btn-login-analista');
  const senha = document.getElementById('an-pass');
  if (btn && btn.dataset.loginBound !== '1') {
    btn.dataset.loginBound = '1';
    btn.type = 'button';
    btn.addEventListener('click', function(event){ window.doLoginAnalista(event); });
  }
  if (senha && senha.dataset.loginBound !== '1') {
    senha.dataset.loginBound = '1';
    senha.addEventListener('keydown', function(event){
      if (event.key === 'Enter') window.doLoginAnalista(event);
    });
  }
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', _vincularLoginAnalista, { once:true });
else _vincularLoginAnalista();

async function atualizarIndicadorLojaAtual(){
  try{
    const lojas=await window.DTLoja.listar(false), id=window.getDTLojaAtiva();
    const loja=lojas.find(function(x){ return x.id===id; });
    const el=document.getElementById('dt-loja-atual-label');
    if(el) el.textContent=(loja && loja.nome)||id||'Sem loja';
    return lojas;
  }catch(_){ return []; }
}

function fecharMenuLojasAnalista(){
  const menu=document.getElementById('dt-loja-switcher-menu');
  const btn=document.getElementById('dt-loja-switcher-btn');
  if(menu) menu.style.display='none';
  if(btn) btn.setAttribute('aria-expanded','false');
}

async function aplicarTrocaLojaAnalista(novaLojaId){
  const anterior=window.getDTLojaAtiva();
  const nova=String(novaLojaId||'').trim();
  fecharMenuLojasAnalista();
  if(!nova || nova===anterior) return false;

  try{
    if(window.AnalistaFirebaseService && window.AnalistaFirebaseService.stop){
      window.AnalistaFirebaseService.stop();
    }
    if(typeof window.encerrarListenerAuditoriaPorTrocaLoja==='function'){
      window.encerrarListenerAuditoriaPorTrocaLoja();
    }

    window.setDTLojaAtiva(nova);
    await atualizarIndicadorLojaAtual();

    // Recarrega somente o estado e os listeners da loja, sem recarregar a página
    // e sem tocar na sessão autenticada do Firebase.
    if(window.AnalistaBootstrap && window.AnalistaBootstrap.loadAll){
      window.AnalistaBootstrap.loadAll();
    }
    if(window.AnalistaFirebaseService && window.AnalistaFirebaseService.refreshFromCache){
      window.AnalistaFirebaseService.refreshFromCache();
    }
    if(window.AnalistaBootstrap && window.AnalistaBootstrap.renderAll){
      window.AnalistaBootstrap.renderAll();
    }
    if(window.AnalistaFirebaseService && window.AnalistaFirebaseService.start){
      await window.AnalistaFirebaseService.start();
    }
    if(typeof window.recarregarAuditoriaAposTrocaLoja==='function'){
      await window.recarregarAuditoriaAposTrocaLoja();
    }
    if(window.AnalistaNavigation && window.AnalistaNavigation.renderCurrentPage){
      window.AnalistaNavigation.renderCurrentPage();
    }
    if(typeof window.atualizarBadgesNav==='function') window.atualizarBadgesNav();
    if(typeof window.showToast==='function') window.showToast('Loja alterada com sucesso.','success');
    return true;
  }catch(e){
    console.error('[Lojas] Falha ao trocar ambiente:',e);
    if(typeof window.showToast==='function') window.showToast('Não foi possível trocar de loja: '+e.message,'error');
    return false;
  }
}

async function montarMenuLojasAnalista(){
  const menu=document.getElementById('dt-loja-switcher-menu');
  if(!menu) return [];
  const lojas=await window.DTLoja.listar(true);
  const atual=window.getDTLojaAtiva();
  if(!lojas.length){
    menu.innerHTML='<div style="padding:10px;font-size:.78rem;color:var(--muted)">Nenhuma loja disponível.</div>';
    return lojas;
  }
  menu.innerHTML=lojas.map(function(loja){
    const ativa=loja.id===atual;
    return '<button type="button" data-trocar-loja="'+String(loja.id).replace(/"/g,'&quot;')+'" style="width:100%;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 11px;border:0;border-radius:8px;background:'+(ativa?'rgba(30,111,78,.12)':'transparent')+';color:var(--text,#17202a);cursor:pointer;text-align:left;font-family:inherit">'+
      '<span><strong style="display:block;font-size:.82rem">'+String(loja.nome||loja.id).replace(/[&<>]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c];})+'</strong>'+
      '<span style="font-size:.67rem;color:var(--muted)">'+String(loja.codigo||loja.id).replace(/[&<>]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c];})+'</span></span>'+
      (ativa?'<span style="font-size:.72rem;color:var(--accent,#1e6f4e);font-weight:800">ATUAL</span>':'')+
      '</button>';
  }).join('');
  return lojas;
}

async function trocarLojaInventario(event){
  if(event){ event.preventDefault(); event.stopPropagation(); }
  const menu=document.getElementById('dt-loja-switcher-menu');
  const btn=document.getElementById('dt-loja-switcher-btn');
  if(!menu) return;
  const abrindo=menu.style.display==='none' || !menu.style.display;
  if(!abrindo){ fecharMenuLojasAnalista(); return; }
  await montarMenuLojasAnalista();
  menu.style.display='block';
  if(btn) btn.setAttribute('aria-expanded','true');
}

if(!window.__dtLojaSwitcherBound){
  window.__dtLojaSwitcherBound=true;
  document.addEventListener('click',function(event){
    const alvo=event.target && event.target.closest ? event.target.closest('[data-trocar-loja]') : null;
    if(alvo){
      event.preventDefault();
      event.stopPropagation();
      aplicarTrocaLojaAnalista(alvo.getAttribute('data-trocar-loja'));
      return;
    }
    const wrap=document.getElementById('dt-loja-switcher');
    if(wrap && !wrap.contains(event.target)) fecharMenuLojasAnalista();
  });
  document.addEventListener('keydown',function(event){ if(event.key==='Escape') fecharMenuLojasAnalista(); });
}

window.aplicarTrocaLojaAnalista=aplicarTrocaLojaAnalista;
window.trocarLojaInventario=trocarLojaInventario;
