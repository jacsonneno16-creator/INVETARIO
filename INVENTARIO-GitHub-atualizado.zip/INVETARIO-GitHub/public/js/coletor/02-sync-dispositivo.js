// ═══════════════════════════════════════════════════
//  SYNC AUTOMÁTICO A CADA 10 MIN EM BACKGROUND
//  Envia fila pendente sem travar o operador
// ═══════════════════════════════════════════════════
let _syncInterval = null;

// ═══════════════════════════════════════════════════
//  IDENTIFICAÇÃO DO DISPOSITIVO (coletor)
//  Estrutura no Firestore: dt_coletores/{device_id}
//  {
//    device_id, apelido, numero,
//    criado_em, ultimo_ping, status,
//    sessao: { operador, email, inventario_id,
//              inventario_nome, login_em } | null
//  }
// ═══════════════════════════════════════════════════

const ST = firebase.firestore.FieldValue.serverTimestamp;
const FV_DELETE = firebase.firestore.FieldValue.delete;

/** Gera fingerprint estável do aparelho (canvas + screen + userAgent).
 *  Mesmo que o localStorage seja limpo, o mesmo aparelho gera o mesmo ID. */
/**
 * IDENTIFICAÇÃO DO APARELHO
 * Regra: 1 aparelho físico = 1 device_id = 1 registro no Firestore.
 *
 * Estratégia de persistência (em ordem de prioridade):
 *   1. localStorage 'dt_device_id'  → fonte principal (sempre lido primeiro)
 *   2. sessionStorage               → fallback se LS bloqueado
 *   3. fingerprint determinístico   → gerado UMA vez se nenhum storage tiver ID
 *
 * O fingerprint combina dados estáveis do hardware/browser para minimizar
 * colisões entre aparelhos diferentes e maximizar estabilidade no mesmo aparelho.
 * Troca de usuário / logout / limpeza de cache NÃO devem mudar o device_id.
 */

const _LS_KEY = 'dt_device_id';
const _SS_KEY = 'dt_device_id_ss';

function _djb2(str) {
  let h = 5381;
  for (let i = 0; i < str.length; i++) h = Math.imul(h, 33) ^ str.charCodeAt(i);
  return (h >>> 0).toString(36);
}

function _gerarFingerprint() {
  const parts = [];
  // 1. User-Agent (estável no mesmo browser/versão)
  parts.push(navigator.userAgent);
  // 2. Resolução + color depth
  parts.push(screen.width + 'x' + screen.height + ':' + screen.colorDepth);
  // 3. Fuso horário
  try { parts.push(Intl.DateTimeFormat().resolvedOptions().timeZone); } catch(e){ console.warn("[Erro tratado]", e); }
  // 4. Idioma
  parts.push(navigator.language || '');
  // 5. Número de núcleos lógicos (hardware)
  parts.push(String(navigator.hardwareConcurrency || 0));
  // 6. Canvas fingerprint (rendering engine)
  try {
    const cv = document.createElement('canvas');
    const cx = cv.getContext('2d');
    cx.textBaseline = 'alphabetic';
    cx.font = '16px Arial';
    cx.fillStyle = '#f00';
    cx.fillText('DT_inv', 2, 14);
    cx.fillStyle = 'rgba(0,255,0,0.5)';
    cx.fillRect(2, 0, 30, 5);
    parts.push(cv.toDataURL().slice(-32));
  } catch(e) { parts.push('nocanvas'); }
  // 7. Plugins (browsers desktop)
  try { parts.push(String(navigator.plugins?.length || 0)); } catch(e){ console.warn("[Erro tratado]", e); }

  return 'dt_' + _djb2(parts.join('|'));
}

/**
 * Retorna o device_id deste aparelho. ÚNICA função que deve ser chamada.
 * Gera e persiste o ID na primeira vez; nas seguintes, apenas lê do storage.
 */
function obterDeviceId() {
  // 1. Tentar localStorage (persistente entre sessões)
  try {
    let did = localStorage.getItem(_LS_KEY);
    if (did && did.startsWith('dt_')) {
      // Espelhar no sessionStorage como backup
      try { sessionStorage.setItem(_SS_KEY, did); } catch(e){ console.warn("[Erro tratado]", e); }
      return did;
    }
  } catch(e){ console.warn("[Erro tratado]", e); }

  // 2. Tentar sessionStorage (caso LS bloqueado)
  try {
    let did = sessionStorage.getItem(_SS_KEY);
    if (did && did.startsWith('dt_')) {
      try { localStorage.setItem(_LS_KEY, did); } catch(e){ console.warn("[Erro tratado]", e); }
      return did;
    }
  } catch(e){ console.warn("[Erro tratado]", e); }

  // 3. Gerar fingerprint e persistir
  const did = _gerarFingerprint();
  try { localStorage.setItem(_LS_KEY, did); } catch(e){ console.warn("[Erro tratado]", e); }
  try { sessionStorage.setItem(_SS_KEY, did); } catch(e){ console.warn("[Erro tratado]", e); }
  dbg('[DeviceID] Novo ID gerado e salvo:', did);
  return did;
}

/** Obtém o IP público do aparelho via API gratuita */
async function obterIPPublico() {
  try {
    const r = await fetch('https://api.ipify.org?format=json');
    const j = await r.json();
    return j.ip || null;
  } catch { return null; }
}

let _heartbeatInterval = null;

/**
 * Registra ou atualiza o aparelho no Firestore após login Firebase bem-sucedido.
 *
 * FLUXO:
 *   Aparelho novo  → cria doc com aprovado='pendente' → retorna 'pendente'
 *   Aprovado       → atualiza operador_atual + ultimo_ping → retorna 'aprovado'
 *   Bloqueado      → não altera nada → retorna 'bloqueado'
 *   Pendente       → não altera nada → retorna 'pendente'
 *
 * GARANTIA: usa o deviceId como chave do documento (doc(deviceId)).
 * Nunca cria mais de um documento para o mesmo aparelho.
 */
async function registrarColetorNoFirestore(operadorInfo) {
  const deviceId = obterDeviceId();
  const ref      = FS.collection(FCOL.coletores).doc(deviceId);

  // O registro não pode depender de serviço externo de IP.
  const ip = null;

  try {
    let snap = await ref.get();

    // O cadastro oficial do aparelho fica na coleção global dt_coletores.
    // Registros antigos/incompletos são normalizados pelas regras sem permitir
    // que o próprio coletor se aprove ou remova um bloqueio administrativo.
    const dadosAtuais = snap.exists ? (snap.data() || {}) : {};
    const foiRevogado = snap.exists &&
      (dadosAtuais.aprovado === 'revogado' || dadosAtuais.excluido === true);

    // ── APARELHO NOVO ────────────────────────────────────────────────────
    if (!snap.exists || foiRevogado) {
      // Número provisório estável, sem consultar toda a coleção.
      const numero = deviceId.slice(-4).toUpperCase();

      await ref.set({
        uid:                 operadorInfo.uid || null,
        device_id:           deviceId,
        nome_coletor:        'Coletor ' + numero,
        numero:              numero,
        operador_atual:      operadorInfo.name,
        operador_email:      operadorInfo.email || null,
        operador_uid:        operadorInfo.uid || null,
        status:              'pendente',
        aprovado:            'pendente',
        data_registro:       ST(),
        ultimo_ping:         ST(),
        sessao:              null,
        contagens_enviadas:  0,
        contagens_pendentes: 0,
        versao_app:          (typeof APP_VERSION !== 'undefined' ? APP_VERSION : '2.0.0'),
        excluido:            false,
        revogado_em:         null
      }, { merge: true });

      // A revogação cumpriu seu papel: bloqueou a restauração automática da
      // aprovação antiga. O aparelho reaparece agora como pendente e precisa
      // ser aprovado novamente pelo analista.
      // IP é enriquecimento opcional e assíncrono; nunca bloqueia o login.
      obterIPPublico().then(v => v && ref.set({ip:v},{merge:true})).catch((erro) => {
        console.warn('[Coletor] Não foi possível registrar o IP do aparelho pendente', erro);
      });
      dbg('[Coletor] Novo aparelho registrado como Coletor', numero, '— pendente — ID:', deviceId);
      return 'pendente';
    }

    // ── APARELHO JÁ EXISTE ───────────────────────────────────────────────
    const dados = snap.data();

    if (dados.aprovado === 'bloqueado') {
      console.warn('[Coletor] Aparelho bloqueado — acesso negado.');
      return 'bloqueado';
    }

    if (dados.aprovado !== 'aprovado') {
      // Atualiza operador_atual e ping mesmo estando pendente (analista vê quem tentou)
      await ref.set({ uid: operadorInfo.uid || null, operador_atual: operadorInfo.name, operador_email: operadorInfo.email || null, operador_uid: operadorInfo.uid || null, ultimo_ping: ST() }, {merge:true});
      dbg('[Coletor] Aparelho pendente — acesso aguardando aprovacao.');
      return 'pendente';
    }

    // APROVADO: atualizar operador e sessão (nunca cria novo doc)
    // Se o turno já foi encerrado neste aparelho (e o analista ainda não
    // reabriu), a trava precisa sobreviver a um novo login — senão o
    // operador conseguiria voltar a contar só saindo e entrando de novo.
    APP.turnoEncerrado = dados.turno_encerrado === true;
    await ref.set({
      uid:              operadorInfo.uid || null,
      operador_uid:     operadorInfo.uid || null,
      operador_atual:   operadorInfo.name,
      ultimo_ping:      ST(),
      status:           'online',
      sessao: {
        operador:        operadorInfo.name,
        email:           operadorInfo.email,
        inventario_id:   APP.inventario?.id    || null,
        inventario_nome: APP.inventario?.nome  || null,
        login_em:        ST(),
      },
    }, { merge: true });
    obterIPPublico().then(v => v && ref.set({ip:v},{merge:true})).catch((erro) => {
      console.warn('[Coletor] Não foi possível atualizar o IP do aparelho aprovado', erro);
    });
    dbg('[Coletor] Sessao atualizada —', operadorInfo.name, '— aprovado — ID:', deviceId);
    return 'aprovado';

  } catch (e) {
    console.warn('[Coletor] registrarColetorNoFirestore falhou:', { code: e.code || null, message: e.message, deviceId: deviceId, uid: operadorInfo && operadorInfo.uid });
    // Em caso de erro de rede, permitir acesso se já tinha sessão local
    return 'erro';
  }
}


let _aprovacaoListener = null;
function iniciarListenerAprovacaoColetor(operadorInfo) {
  if (_aprovacaoListener) { try { _aprovacaoListener(); } catch(_){ console.warn("[Erro tratado]", _); } }
  const ref = FS.collection(FCOL.coletores).doc(obterDeviceId());
  _aprovacaoListener = ref.onSnapshot(async snap => {
    if (!snap.exists) return;
    const d = snap.data() || {};
    if (d.aprovado === 'bloqueado') {
      if (typeof _mostrarTelaBloqueado === 'function') _mostrarTelaBloqueado();
      return;
    }
    if (d.aprovado !== 'aprovado') return;
    try {
      await ref.set({uid:operadorInfo.uid, status:'online', operador_atual:operadorInfo.name, operador_email:operadorInfo.email, operador_uid:operadorInfo.uid, ultimo_ping:ST()}, {merge:true});
      if (_aprovacaoListener) { _aprovacaoListener(); _aprovacaoListener=null; }

      // Ao recuperar a conexão durante uma operação já iniciada, não recarrega a
      // página. O reload apagava o contexto da auditoria e passava a impressão de
      // que era necessário começar de novo. Só recarrega quando o coletor ainda
      // está efetivamente parado na tela de aprovação.
      // A aprovação ou a volta da conexão nunca deve recarregar a página.
      // Mantém inventário, endereço, produto e auditoria atuais e sincroniza tudo em segundo plano.
      if (typeof window.sincronizarTudoEmSegundoPlano === 'function') {
        window.sincronizarTudoEmSegundoPlano('aprovacao').catch(function(error){ console.warn("[Falha assíncrona]", error); });
      } else {
        if (typeof window.sincronizarFilaAuditoria === 'function') window.sincronizarFilaAuditoria().catch(function(error){ console.warn("[Falha assíncrona]", error); });
        if (typeof enviarFilaPendente === 'function') enviarFilaPendente().catch(function(error){ console.warn("[Falha assíncrona]", error); });
      }
      atualizarBarraStatus();
    } catch(e) { console.error('[Aprovação] Falha ao liberar coletor:', e); }
  }, err => console.error('[Aprovação] Listener:', err));
}
window.iniciarListenerAprovacaoColetor = iniciarListenerAprovacaoColetor;

/**
 * Atualiza apenas o inventário dentro da sessão.
 * Chamado quando o operador seleciona/baixa um inventário.
 */
async function atualizarInventarioColetor() {
  if (!APP.operador) return;
  const deviceId = obterDeviceId();
  try {
    await FS.collection(FCOL.coletores).doc(deviceId).update({
      'sessao.inventario_id':   APP.inventario?.id    || null,
      'sessao.inventario_nome': APP.inventario?.nome  || null,
      ultimo_ping:              ST(),
    });
    dbg('[Coletor] Inventário atualizado:',
                APP.inventario?.nome || '—');
  } catch (e) {
    console.warn('[Coletor] atualizarInventario falhou:', e.message);
  }
}

/**
 * Heartbeat a cada 120s — mantém status online visível no analista (intervalo aumentado para reduzir leituras Firebase).
 * Atualiza também contagens_pendentes para o analista ver a fila.
 */
async function enviarHeartbeat() {
  if (!APP.operador) return;
  const deviceId = obterDeviceId();
  try {
    await FS.collection(FCOL.coletores).doc(deviceId).update({
      ultimo_ping:         ST(),
      status:              'online',
      contagens_pendentes: FILA_ENVIO.length,
    });
  } catch (e) {
    // silencioso — não interrompe operação
  }
}

let _coletorListener = null;

/**
 * Listener em tempo real no documento deste coletor.
 * Detecta bloqueio/remoção feitos pelo analista e desconecta imediatamente.
 */
function iniciarListenerColetor() {
  if (_coletorListener) { _coletorListener(); _coletorListener = null; }
  const deviceId = obterDeviceId();
  try {
    _coletorListener = FS.collection(FCOL.coletores).doc(deviceId)
      .onSnapshot(snap => {
        if (!APP.operador) return; // já deslogado, ignorar
        if (!snap.exists) return;  // doc ainda não existe (primeiro cadastro)
        const dados = snap.data();
        if (!dados) return;

        if (dados.aprovado === 'bloqueado') {
          // Analista bloqueou — forçar logout e mostrar tela de bloqueio
          console.warn('[Coletor] Bloqueado pelo analista em tempo real.');
          AUTH.signOut().catch((erro) => console.error('[Coletor] Falha ao encerrar sessão de aparelho bloqueado', erro));
          APP.operador = null;
          if (_heartbeatInterval) { clearInterval(_heartbeatInterval); _heartbeatInterval = null; }
  if (typeof _coletorListener === 'function') { _coletorListener(); _coletorListener = null; }
          if (_coletorListener)   { _coletorListener(); _coletorListener = null; }
          goScreen('login');
          // Mostrar tela vermelha com hora do bloqueio
          const agora = new Date().toLocaleString('pt-BR', {day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});
          const box = document.getElementById('login-bloqueado-box');
          if (box) {
            // Atualizar mensagem com a hora
            const msg = box.querySelector('div[style*="font-size:.78rem"]');
            if (msg) msg.innerHTML = `Este aparelho foi bloqueado pelo analista.<br>Sessão encerrada às <b>${agora}</b>.<br>Entre em contato com o responsável.`;
            box.style.display = 'flex';
          }
        } else if (dados.aprovado === 'pendente') {
          // Analista removeu aprovação (edge case) — forçar logout e tela amarela
          console.warn('[Coletor] Aprovação revogada — retornando para tela de espera.');
          AUTH.signOut().catch((erro) => console.error('[Coletor] Falha ao encerrar sessão após revogação', erro));
          APP.operador = null;
          if (_heartbeatInterval) { clearInterval(_heartbeatInterval); _heartbeatInterval = null; }
          if (_coletorListener)   { _coletorListener(); _coletorListener = null; }
          goScreen('login');
          _mostrarTelaAguardandoAprovacao('');
        }
      }, err => {
        console.warn('[ListenerColetor] erro:', err.message);
      });
  } catch(e) {
    console.warn('[ListenerColetor] não iniciado:', e.message);
  }
}

/**
 * Logout: marca offline e limpa APENAS a sessão.
 * O documento do coletor permanece intacto.
 */
async function marcarColetorOffline() {
  const deviceId = obterDeviceId();
  try {
    const updateData = {
      status:      'offline',
      ultimo_ping: ST(),
    };
    // Se o turno foi encerrado, limpamos a sessão no Firebase para o analista ver
    if (APP.turnoEncerrado) {
      updateData.sessao = null;
    }
    await FS.collection(FCOL.coletores).doc(deviceId).update(updateData);
    dbg('[Coletor] Marcado offline.');
  } catch (e) {
    console.warn('[Coletor] marcarOffline falhou:', e.message);
  }
}

/**
 * Encerra o turno do operador: envia tudo, marca como encerrado e faz logout.
 * O analista só consegue fechar o inventário se todos os coletores encerrarem.
 */
async function encerrarTurnoColetor() {
  if (APP.turnoEncerrado) return;

  // ── 1. Verificar contagens pendentes no IDB ──────────────────────────────
  const pendentes = await idbGetPendentes();
  if (pendentes.length > 0) {
    if (!navigator.onLine) {
      toast('⚠️ Sem Conexão: Você possui contagens pendentes. Conecte-se para enviar antes de encerrar.', 'e');
      return;
    }
    toast('Enviando contagens pendentes antes de encerrar...', 'i');
    await enviarFilaPendente();
    const aindaPendentes = await idbGetPendentes();
    if (aindaPendentes.length > 0) {
      toast('Falha ao enviar algumas contagens. Tente novamente.', 'e');
      return;
    }
  }

  // ── 2. Verificar recontagens pendentes ───────────────────────────────────
  const _statusEncerradosRec = ['concluida','sem_divergencia','resolvida','aguardando_analista','cancelada'];
  const recsPendentes = (APP.recontagens || [])
    .filter(r => !_statusEncerradosRec.includes((r.status_recontagem || 'pendente').toLowerCase()));
  if (recsPendentes.length > 0) {
    toast('🚫 Você possui ' + recsPendentes.length + ' recontagem(ns) pendente(s). Finalize todas antes de encerrar o turno.', 'e');
    showView('recontagens', document.getElementById('tab-recontagens'));
    return;
  }

  // ── 3. Confirmação de encerramento ───────────────────────────────────────
  showConfirm('Deseja encerrar seu turno? Após encerrar, você não poderá realizar novas contagens neste inventário.', async () => {
    try {
      APP.turnoEncerrado = true;
      const deviceId = obterDeviceId();
      
      // Marcar no Firebase que este coletor encerrou o turno com sucesso
      await FS.collection(FCOL.coletores).doc(deviceId).update({
        status: 'offline',
        turno_encerrado: true,
        turno_encerrado_em: ST(),
        contagens_pendentes: 0,
        sessao: null
      });

      toast('✅ Turno encerrado com sucesso!', 's');
      setTimeout(() => {
        AUTH.signOut();
        APP.operador = null;
        APP.turnoEncerrado = false; // reset para próximo login
        goScreen('login');
      }, 2000);
    } catch (e) {
      APP.turnoEncerrado = false;
      toast('Erro ao encerrar turno: ' + e.message, 'e');
    }
  }, { title: 'Encerrar Turno', icon: '🔒', okLabel: 'Encerrar Agora', okColor: 'var(--danger)' });
}

var _onColetorOnline = null;
var _onColetorOffline = null;

function removerListenersConectividade() {
  if (_onColetorOnline) window.removeEventListener('online', _onColetorOnline);
  if (_onColetorOffline) window.removeEventListener('offline', _onColetorOffline);
  _onColetorOnline = null;
  _onColetorOffline = null;
}

function iniciarSyncBackground() {
  // ── Inicializar IDB e migrar dados legados ──────────────────
  idbInit().then(() => {
    // Após IDB pronto, tentar enviar imediatamente se online
    if (navigator.onLine && FILA_ENVIO.length > 0) {
      enviarFilaPendente().catch((err) => console.warn('[Sync] Envio inicial pendente:', err));
    }
    atualizarBarraStatus();
  });

  // Heartbeat a cada 5 minutos → analista detecta online/offline
  // [OTIMIZADO] Aumentado de 2 min → 5 min: -60% de escritas de heartbeat.
  // O _coletorListener (onSnapshot no doc do coletor) já cobre bloqueios em tempo real.
  if (_heartbeatInterval) clearInterval(_heartbeatInterval);
  _heartbeatInterval = setInterval(enviarHeartbeat, 300000); // 5 min — era 2 min
  enviarHeartbeat(); // imediato

  // Listener em tempo real — detecta bloqueio/remoção pelo analista instantaneamente
  iniciarListenerColetor();

  // Tenta imediatamente ao entrar online
  removerListenersConectividade();
  _onColetorOnline = async function () {
    atualizarBarraStatus();
    // Auditoria é independente de turno e de inventário encerrado. Ao voltar a
    // internet, envia a fila em segundo plano sem trocar tela nem pedir retorno.
    if (APP.modoAcesso !== 'auditoria') await verificarInventarioAtivo();
    const sincronizar = typeof window.sincronizarTudoEmSegundoPlano === 'function'
      ? window.sincronizarTudoEmSegundoPlano('online')
      : Promise.all([
          typeof enviarFilaPendente === 'function' ? enviarFilaPendente() : Promise.resolve(),
          typeof window.sincronizarFilaAuditoria === 'function' ? window.sincronizarFilaAuditoria() : Promise.resolve()
        ]);
    Promise.resolve(sincronizar).catch((err) => console.warn('[Sync] Falha ao enviar filas após reconexão:', err));
  };
  _onColetorOffline = function () {
    atualizarBarraStatus();
  };
  window.addEventListener('online', _onColetorOnline);
  window.addEventListener('offline', _onColetorOffline);

  // Loop a cada 30 segundos — sync robusto automático
  // [OTIMIZADO] Intervalo aumentado de 10s → 30s: reduz leituras em 3× sem impacto operacional.
  // verificarInventarioAtivo() só ocorre a cada 10 min (20 ciclos × 30s) para não gerar
  // leitura extra a cada envio de fila — o onSnapshot do inventário já cobre atualizações urgentes.
  let _syncCiclo = 0;
  _syncInterval = setInterval(async () => {
    if (navigator.onLine) {
      // Rebuild FILA_ENVIO do IDB antes de cada tentativa
      const pendentes = await idbGetPendentes();
      if (pendentes.length > 0) {
        FILA_ENVIO = pendentes;
        enviarFilaPendente().catch((err) => console.warn('[Sync] Falha no envio periódico:', err));
      }
      // Verifica inventário ativo só a cada ~10 min (20 ciclos × 30s)
      _syncCiclo++;
      if (_syncCiclo >= 20) {
        _syncCiclo = 0;
        verificarInventarioAtivo().catch((err) => console.warn('[Sync] Falha ao validar inventário:', err));
      }
    }
    atualizarBarraStatus(); // mantém UI atualizada
  }, 30 * 1000);  // 30s — era 10s

  // 🔍 Polling a cada 60s para detectar inventários excluídos/encerrados pelo analista
  iniciarListenerInventarios();
}

// ─── Polling de inventários (substitui listener em tempo real) ──────────────
// Troca o onSnapshot por verificação a cada 60s.
// Motivo: o listener dispara em TODOS os 30 aparelhos a cada mudança do analista
// → gera 30 leituras simultâneas por atualização.
// Com polling de 60s: máximo 1 leitura/min/aparelho, mesmo com muitas atualizações.
// Impacto operacional: operador leva até 60s para ver encerramento — aceitável
// porque o analista sempre avisa antes de encerrar (rádio/WhatsApp).
let _invListener    = null;  // mantida para compatibilidade com logout (linha _invListener())
let _invPollInterval = null; // intervalo do polling

function iniciarListenerInventarios() {
  // Cancela polling anterior se existir
  if (_invPollInterval) { clearInterval(_invPollInterval); _invPollInterval = null; }
  // _invListener vira no-op (logout continua chamando _invListener() sem erro)
  _invListener = () => { if (_invPollInterval) { clearInterval(_invPollInterval); _invPollInterval = null; } };

  // Função de poll — executa imediatamente e depois a cada 3 min
  async function _pollInventarios() {
    if (!navigator.onLine || !APP.operador) return;
    // Auditoria usa outro documento/coleção. Nunca validar o ID da auditoria
    // na coleção de inventários, pois isso fazia a tela voltar sozinha ao início.
    if (APP.modoAcesso === 'auditoria') return;
    // [OTIMIZADO] Se o operador está na tela de coleta (dentro de um inventário),
    // o _syncInterval já chama verificarInventarioAtivo() a cada 10 min.
    // Só faz poll completo quando está na tela de seleção de inventários.
    const screenInv = document.getElementById('screen-inventarios');
    const screenColeta = document.getElementById('screen-coleta') || document.getElementById('screen-app');
    const dentroInventario = APP.inventario && screenColeta && screenColeta.classList.contains('ativo');
    if (dentroInventario) return; // economiza leitura — syncInterval cobre esse caso
    try {
      const snap = await FS.collection(FCOL.inventarios)
        .where('status', '==', 'ATIVO')
        .get();
      const idsAtivos = snap.docs.map(d => d.id);
      const lista = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      APP.inventariosDisponiveis = lista;
      invCacheSave(lista);
      limparInventariosObsoletos(idsAtivos);
      // Se tela de inventários está visível, re-renderiza
      const screenInv = document.getElementById('screen-inventarios');
      if (screenInv && screenInv.classList.contains('ativo')) {
        renderListaInventarios(lista);
      }
      // Se operador está dentro de um inventário, verifica se ainda está ativo
      if (APP.modoAcesso !== 'auditoria' && APP.inventario && !idsAtivos.includes(APP.inventario.id)) {
        APP.inventario.status = 'FECHADO';
        APP.inventario._encerradoNoServidor = true;
        renderListaInventarios(lista);
      }
      dbg('[Poll] inventários:', lista.length, 'ativos');
    } catch(e) {
      console.warn('[Poll] Erro ao verificar inventários:', e.message);
    }
  }

  _pollInventarios(); // executa imediatamente ao entrar
  _invPollInterval = setInterval(_pollInventarios, 180 * 1000); // era 60s → 3 min
}

/** Verifica se o inventário atual ainda existe/está ativo no Firestore */
async function verificarInventarioAtivo() {
  if (!APP.inventario || !navigator.onLine) return;
  if (APP.modoAcesso === 'auditoria') return;
  try {
    const doc = await FS.collection(FCOL.inventarios).doc(APP.inventario.id).get();
    const status = doc.data()?.status;
    if (!doc.exists || status === 'FECHADO' || status === 'Fechado' || status === 'CANCELADO') {
      APP.inventario.status = 'FECHADO';
      APP.inventario._encerradoNoServidor = true;
      atualizarBarraStatus();
    }
  } catch(e) {
    console.warn('[verif] Não foi possível verificar inventário:', e.message);
  }
}

// Impede que enviarFilaPendente() rode mais de uma vez ao mesmo tempo.
// Ela é chamada de vários lugares independentes (heartbeat, intervalo de
// 30s, ao voltar online, logo após enfileirar algo, ao sair da tela...) sem
// nenhuma coordenação entre si. Com uma fila grande (ex.: um lote de
// milhares de pallets), um único envio pode legitimamente levar mais de 30s
// — e sem esta trava, o próximo tick do intervalo disparava OUTRA rodada de
// envio da mesma fila por cima da que já estava rodando, e a próxima, e a
// próxima, empilhando várias passagens concorrentes sobre o mesmo lote
// gigante até travar o aparelho (só resolvia limpando o armazenamento).
let _enviandoFilaEmAndamento = false;

/** Envia todas as contagens pendentes em background (não bloqueia UI) */
async function enviarFilaPendente() {
  if (_enviandoFilaEmAndamento) return;
  if (!navigator.onLine) return;

  // Busca pendentes direto do IDB (fonte de verdade)
  const pendentes = await idbGetPendentes();
  if (!pendentes.length) return;

  // ⚠️ Guarda de segurança: não enviar se inventário foi fechado/cancelado
  // (pode ter sido fechado enquanto o operador estava offline)
  const statusInv = (APP.inventario?.status || '').toUpperCase();
  if (APP.inventario && (statusInv === 'FECHADO' || statusInv === 'CANCELADO')) {
    console.warn('[fila] Inventário não está ATIVO (' + statusInv + ') — envio bloqueado.');
    toast('⚠️ Inventário encerrado. Contagens pendentes não enviadas.', 'e');
    return;
  }

  // Bloquear envio se o inventário estiver PAUSADO
  if (APP.inventario && statusInv === 'PAUSADO') {
    console.warn('[fila] Inventário PAUSADO — envio aguardando reativação.');
    toast('⏸ Inventário pausado. O envio será retomado quando for reativado.', 'w');
    return;
  }

  _enviandoFilaEmAndamento = true;
  try {

  atualizarBarraStatus();

  const enviados = [];
  const falhas   = [];
  let erroConexao = false;
  let processados = 0;

  for (const c of pendentes) {
    if (erroConexao) break;   // abandona lote se conexão caiu no meio

    // Devolve o controle pro navegador periodicamente — numa fila de
    // milhares de itens, isso mantém a tela respondendo a toques mesmo
    // durante um envio longo, em vez de tudo ficar em fila de microtasks.
    if (++processados % 20 === 0) await new Promise(r => setTimeout(r, 0));

    try {
      // Chave única no Firestore = uuid da contagem (garante idempotência)
      const docId = c.uuid || String(c.id);
      // Rota para a coleção correta: dt_contagens (padrão) ou dt_vazios (VAZIO normal)
      const colecaoDestino = c._destino || FCOL.contagens;
      await FS.collection(colecaoDestino).doc(docId).set({
        ...c,
        dataHora: c.dataHora
          ? (typeof c.dataHora === 'string' ? new Date(c.dataHora) : c.dataHora)
          : new Date(),
        enviado_em:  new Date(),
        status_sync: 'sincronizado',
      });

      // Uma recontagem concluída offline chega aqui junto com a contagem.
      // Atualizar a tarefa vinculada no mesmo ciclo de sincronização evita que
      // ela reapareça como PENDENTE no coletor. A divergência continua sendo
      // propriedade do Analista e não é alterada pelo coletor.
      if (String(c.tipo_contagem || '').toUpperCase() === 'RECONTAGEM' && c.recontagem_id) {
        try {
          await FS.collection('dt_recontagens').doc(String(c.recontagem_id)).set({
            status_recontagem: 'concluida',
            status: 'CONCLUIDA',
            numero_recontagem: Number(c.numero_recontagem || 1),
            recontagem_concluida_em: c.criado_em || new Date().toISOString(),
            operador_recontagem: c.operador_nome || c.operador || '',
            contagem_uuid: c.uuid || docId,
            atualizado_em: new Date().toISOString()
          }, { merge: true });
        } catch (statusErr) {
          // A contagem já foi preservada. O Analista ainda consegue consolidar
          // pelo recontagem_id/chave de fluxo; portanto não duplicamos o envio.
          console.warn('[fila] Contagem enviada, mas status da recontagem não foi atualizado:', statusErr.message);
        }
      }

      // Remove do IDB e marca localmente
      await idbDelete(c.uuid);
      try{ if(window.DTStatusLedger) DTStatusLedger.mark('inventario',c.inventario_id||c.inventarioId||APP.inventario?.id,c,'ENVIADO'); }catch(_e){}
      enviados.push(c.uuid || c.id);

    } catch(err) {
      console.warn('[Firebase] Erro ao enviar', c.uuid, err.message);
      falhas.push(c.uuid || c.id);

      // Incrementa tentativas no IDB
      await idbPut({
        ...c,
        tentativas:   (c.tentativas || 0) + 1,
        ultimo_erro:  err.message,
        status_sync:  'pendente',
      });

      if (err.code === 'unavailable' || err.code === 'failed-precondition' ||
          !navigator.onLine || err.message?.includes('network')) {
        erroConexao = true;
      }
    }
  }

  if (enviados.length > 0) {
    // Rebuild FILA_ENVIO do IDB (fonte de verdade)
    FILA_ENVIO = await idbGetPendentes();
    filaSave(FILA_ENVIO);    // espelho LS
    atualizarBarraStatus();
    updateStats();

    // Atualiza doc do coletor no Firestore
    try {
      const deviceId = obterDeviceId();
      FS.collection(FCOL.coletores).doc(deviceId).update({
        contagens_enviadas:  firebase.firestore.FieldValue.increment(enviados.length),
        contagens_pendentes: FILA_ENVIO.length,
        ultimo_ping:         firebase.firestore.FieldValue.serverTimestamp(),
      }).catch((erro) => {
        console.warn('[Sincronização] Contagens foram enviadas, mas o resumo do coletor não foi atualizado', erro);
      });
    } catch(e){ console.warn("[Erro tratado]", e); }

    if (FILA_ENVIO.length === 0) {
      const bar = document.getElementById('sync-bar');
      if (bar) {
        bar.style.display    = 'flex';
        bar.style.background = 'linear-gradient(90deg,#14532d,#166534)';
        const barText = document.getElementById('sync-bar-text');
        if (barText) barText.textContent = `✅ ${enviados.length} contagem(ns) enviadas ao Firebase!`;
        setTimeout(() => { if (bar && FILA_ENVIO.length === 0) bar.style.display = 'none'; }, 3000);
      }
    }
  }

  } finally {
    _enviandoFilaEmAndamento = false;
  }
}

/**
 * Adiciona contagem à fila IDB + espelho LS e tenta enviar se online.
 *
 * Passe {silencioso:true} ao enfileirar MUITOS itens em sequência (ex.: o
 * lançamento rápido em lote) — sem isso, cada chamada relia a fila inteira
 * do IndexedDB, regravava tudo no localStorage e disparava um envio pro
 * Firebase, tudo de novo a cada pallet. Num lote grande (centenas/milhares
 * de pallets), isso empilhava trabalho O(n²) e uma avalanche de chamadas
 * concorrentes que travava a aba inteira. Com {silencioso:true}, só o IDB é
 * gravado por item; quem chama em lote deve rodar finalizarEnfileiramento()
 * uma única vez no final.
 */
async function enfileirarContagem(contagem, opts) {
  const silencioso = !!(opts && opts.silencioso);
  // Garantir UUID único para deduplicação
  const uuid   = contagem.uuid || gerarUUID();
  const record = {
    ...contagem,
    uuid,
    status_sync: 'pendente',
    tentativas:  0,
    criado_em:   contagem.criado_em || contagem.dataHora || new Date().toISOString(),
  };

  // Verificar duplicata antes de salvar
  const existe = await idbExists(uuid);
  if (existe) {
    console.warn('[fila] Contagem já existe no IDB, ignorando duplicata:', uuid);
    return;
  }

  // 1️⃣ Salvar no IDB (fonte de verdade — sobrevive a reload e fechamento)
  await idbPut(record);

  if (silencioso) return;

  await finalizarEnfileiramento(uuid);
}

/** Atualiza o espelho local, a UI e dispara o envio — uma única vez. */
async function finalizarEnfileiramento(uuid) {
  // 2️⃣ Atualizar espelho localStorage (backup de emergência)
  FILA_ENVIO = await idbGetPendentes();
  filaSave(FILA_ENVIO);

  // 3️⃣ Atualizar UI imediatamente — operador não espera Firebase
  atualizarBarraStatus();

  // 4️⃣ Tentar enviar em background (sem bloquear o fluxo do operador)
  if (navigator.onLine) {
    enviarFilaPendente().catch((erro) => {
      console.error('[Sincronização] Falha no envio em segundo plano; item mantido na fila', { uuid, erro });
      atualizarBarraStatus();
    });
  }
}
