// AUDITORIA OPERACIONAL V22 — módulo isolado do Inventário
// Importação: Endereço + GTIN/EAN + Produto. Comparação pelos códigos cadastrados.
(function(){
  'use strict';

  // Evita inicialização duplicada caso o arquivo seja carregado mais de uma vez.
  if (window.__auditoriaOperacionalV22Inicializada) return;
  window.__auditoriaOperacionalV22Inicializada = true;

  const DB = () => window.FS_AN || (window.getDTFirestore && window.getDTFirestore());
  const STATUS = ['PENDENTE','OK','DIVERGENTE','ENDERECO_VAZIO'];
  let auditoriaAtual = '';
  let metaAtual = null;
  let itensAtuais = [];
  let itensBrutosAtuais = [];
  let assinaturaAnterior = '';
  let importacaoPendente = null;
  let criacaoToken = 0;
  let criacaoAberta = false;
  let criacaoPromise = null;
  let paginaAtual = 1;
  const ITENS_POR_PAGINA = 150;
  const origemAuditoria = new Map();

  function colecaoAuditorias(){ return DB().collection('dt_auditorias'); }
  function referenciaAuditoria(id){
    const origem=origemAuditoria.get(String(id));
    if(window.getDTRawFirestore){
      const raw=window.getDTRawFirestore();
      if(origem==='raiz') return raw.collection('dt_auditorias').doc(String(id));
      if(origem && origem.indexOf('loja:')===0) return raw.collection('lojas').doc(origem.slice(5)).collection('dt_auditorias').doc(String(id));
    }
    return colecaoAuditorias().doc(String(id));
  }

  function comTimeout(promise, ms, rotulo){
    let timer;
    return Promise.race([
      Promise.resolve(promise),
      new Promise(function(_,reject){
        timer=setTimeout(function(){
          const erro=new Error('Tempo excedido ao carregar '+(rotulo||'os dados')+'.');
          erro.code='auditoria/timeout';
          reject(erro);
        },ms);
      })
    ]).finally(function(){ clearTimeout(timer); });
  }

  function callable(nome){
    return firebase.app().functions('southamerica-east1').httpsCallable(nome);
  }

  function bloquearInterface(bloqueada, mensagem){
    const ids=['aud-op-auditoria','btn-aud-atualizar','btn-aud-atualizar-base','btn-aud-finalizar','btn-aud-excluir','btn-aud-exportar'];
    ids.forEach(function(id){const el=document.getElementById(id);if(el)el.disabled=!!bloqueada;});
    const tbody=document.getElementById('auditoria-op-tbody');
    if(bloqueada && tbody) tbody.innerHTML='<tr><td colspan="8" class="auditoria-loading" aria-live="polite">⏳ '+esc(mensagem||'Carregando auditoria…')+'</td></tr>';
  }

  let configuracaoNova = null;
  function ruaDoEndereco(v){
    try {
      if (window.DTEnderecos && typeof window.DTEnderecos.partes === 'function') {
        return txt(window.DTEnderecos.partes(v).rua);
      }
    } catch(e){ console.warn("[Erro tratado]", e); }
    const partes = txt(v).split('.').map(function(parte){ return parte.trim(); }).filter(Boolean);
    return partes.length >= 4 ? partes[3] : (partes[0] || '');
  }
  async function enderecosGerais(){
    try{
      const metaSnap=await DB().collection('dt_locais_meta').doc('versao').get();
      if(!metaSnap.exists) return [];
      const meta=metaSnap.data()||{};
      const versao=txt(meta.versao);
      if(!versao || Number(meta.total||0)===0) return [];
      const chunks=await DB().collection('dt_locais_chunks').where('versao','==',versao).get();
      const docs=(chunks.docs||[]).slice().sort((a,b)=>Number((a.data()||{}).parte||0)-Number((b.data()||{}).parte||0));
      const esperados=Number(meta.chunks||0);
      if(esperados && docs.length!==esperados) throw new Error('Base incompleta: '+docs.length+' de '+esperados+' chunks baixados.');
      let out=[];
      docs.forEach(d=>{ const x=d.data()||{}; const itens=x.dados||x.itens||x.enderecos||x.lista||[]; if(itens.length>1000) throw new Error('Chunk '+d.id+' excede 1.000 registros.'); out=out.concat(itens); });
      if(Number(meta.total||0)!==out.length) throw new Error('Base incompleta: metadado informa '+Number(meta.total||0)+' e foram baixados '+out.length+' endereços.');
      return out.map(x=>typeof x==='string'?{endereco:x}:x);
    }catch(e){
      console.error('[AUDITORIA] Falha ao baixar chunks de endereços:',e);
      throw e;
    }
  }
  async function abrirCriacaoAuditoria(){
    // Impede múltiplas aberturas simultâneas. Cliques repetidos eram responsáveis
    // por modais sobrepostos, campos piscando e carregamentos que voltavam sozinhos.
    const modalExistente=document.getElementById('modal-nova-aud-v39');
    if(modalExistente){
      modalExistente.classList.add('open');
      const campo=modalExistente.querySelector('#aud39-nome'); if(campo)campo.focus();
      return;
    }
    if(criacaoAberta && criacaoPromise) return criacaoPromise;
    criacaoAberta=true;
    const meuToken=++criacaoToken;
    document.getElementById('aud-v52-loading')?.remove();
    const carregando=document.createElement('div');
    carregando.id='aud-v52-loading'; carregando.className='modal-bg open';
    carregando.innerHTML='<div class="modal" style="max-width:420px;text-align:center;padding:28px"><div style="font-size:2rem">⏳</div><div class="modal-title" style="margin-top:10px">Preparando nova auditoria…</div><div class="sec-sub">Carregando produtos e endereços apenas uma vez.</div><div class="modal-actions" style="justify-content:center"><button type="button" class="btn btn-ghost" id="aud39-cancelar-loading">Cancelar</button></div></div>';
    document.body.appendChild(carregando);
    const cancelar=()=>{ if(meuToken===criacaoToken)++criacaoToken; criacaoAberta=false; carregando.remove(); };
    carregando.querySelector('#aud39-cancelar-loading').onclick=cancelar;
    criacaoPromise=(async function(){
    try{
      // Nunca deixa a criação presa esperando Firebase. Primeiro tenta usar o cache
      // já carregado e limita cada consulta a poucos segundos.
      if(window.DTProdutos && typeof window.DTProdutos.carregar==='function'){
        await comTimeout(window.DTProdutos.carregar(false), 8000, 'a base de produtos');
      }
      if(meuToken!==criacaoToken) return;
      const familias=(window.DTProdutos?.familias?.()||[]).filter(function(f){ return f && f.produtos && f.produtos.length; });
      const ends=await comTimeout(enderecosGerais(), 8000, 'a base de endereços');
      if(meuToken!==criacaoToken) return;
      const ruas=[...new Set(ends.map(e=>ruaDoEndereco(e.endereco||e.codigo||e.id)).filter(Boolean))].sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));
      carregando.remove();
      const cardsFamilia=familias.map(f=>`<button type="button" class="aud39-familia-card" data-familia-id="${esc(f.id)}" data-familia-nome="${esc(f.nome)}" style="width:100%;text-align:left;padding:10px 12px;border:1px solid var(--border);border-radius:9px;background:var(--card);cursor:pointer;margin-bottom:6px">${esc(f.nome)}</button>`).join('');
      const html=`<div id="modal-nova-aud-v39" class="modal-bg open"><div class="modal" style="max-width:760px"><div class="modal-hdr"><div><div class="modal-title">Criar nova auditoria</div><div class="sec-sub">Informe o nome, escolha o tipo e carregue a base antes de criar.</div></div><button class="modal-close" data-fechar-aud-v39>✕</button></div><div class="fg"><div class="fi full"><div class="fl">Nome da auditoria *</div><input id="aud39-nome" placeholder="Ex.: Auditoria Rua 14"></div><div class="fi full"><div class="fl">Como deseja auditar?</div><select id="aud39-tipo"><option value="rua">Por rua</option><option value="produto">Por produto</option></select></div><div class="fi full" id="aud39-box-rua"><div class="fl">Ruas</div><div style="display:flex;gap:8px;margin-bottom:8px"><button type="button" class="btn btn-ghost btn-sm" id="aud39-ruas-todas">Selecionar todas as ruas</button><button type="button" class="btn btn-ghost btn-sm" id="aud39-ruas-limpar">Limpar seleção</button></div><select id="aud39-ruas" multiple size="7">${ruas.map(r=>`<option value="${esc(r)}">Rua ${esc(r)}</option>`).join('')}</select><div class="sec-sub">Use Ctrl para selecionar mais de uma rua, ou clique em "Selecionar todas as ruas" para auditar a loja inteira.</div></div><div class="fi full" id="aud39-box-prod" style="display:none"><div class="fl">Família de produtos</div><input id="aud39-busca-prod" placeholder="Pesquisar família..." autocomplete="off"><input type="hidden" id="aud39-prod"><div id="aud39-familias-lista" style="max-height:250px;overflow:auto;margin-top:8px">${cardsFamilia||'<div class="empty-sub">Nenhuma família com produto UND encontrada.</div>'}</div><div id="aud39-familia-selecionada" class="sec-sub" style="margin-top:8px">Nenhuma família selecionada.</div></div><div class="fi full"><div class="fl">Base da auditoria *</div><div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><button type="button" class="btn btn-ghost" id="aud39-escolher-arquivo">⬆ Selecionar arquivo</button><span id="aud39-arquivo-nome" class="sec-sub">Nenhum arquivo selecionado</span><input id="aud39-arquivo" type="file" accept=".csv,.xlsx,.xls" style="display:none"></div><div id="aud39-arquivo-status" style="margin-top:10px"></div></div></div><div class="modal-actions"><button class="btn btn-ghost" data-fechar-aud-v39>Cancelar</button><button class="btn btn-primary" id="aud39-criar">Criar e importar auditoria</button></div></div></div>`;
      document.body.insertAdjacentHTML('beforeend',html);
      const modal=document.getElementById('modal-nova-aud-v39');
      let arquivoSelecionado=null;
      // Bloqueia handlers delegados da página atrás do modal.
      ['click','mousedown','pointerdown','change','input'].forEach(evt=>modal.addEventListener(evt,e=>e.stopPropagation()));
      const fechar=()=>{++criacaoToken;criacaoAberta=false;modal.remove();};
      modal.querySelectorAll('[data-fechar-aud-v39]').forEach(b=>b.onclick=fechar);
      const tipo=modal.querySelector('#aud39-tipo');
      tipo.onchange=()=>{modal.querySelector('#aud39-box-rua').style.display=tipo.value==='rua'?'':'none';modal.querySelector('#aud39-box-prod').style.display=tipo.value==='produto'?'':'none';};
      const busca=modal.querySelector('#aud39-busca-prod');
      busca.oninput=function(){const q=txt(this.value).toLowerCase();modal.querySelectorAll('.aud39-familia-card').forEach(o=>{o.style.display=!q||txt(o.dataset.familiaNome).toLowerCase().includes(q)?'block':'none';});};
      modal.querySelectorAll('.aud39-familia-card').forEach(card=>card.onclick=()=>{
        modal.querySelectorAll('.aud39-familia-card').forEach(x=>{x.style.outline='';x.setAttribute('aria-selected','false');});
        card.style.outline='2px solid var(--primary)';card.setAttribute('aria-selected','true');
        modal.querySelector('#aud39-prod').value=card.dataset.familiaId||'';
        modal.querySelector('#aud39-familia-selecionada').textContent='Selecionada: '+(card.dataset.familiaNome||'');
      });
      const selectRuas=modal.querySelector('#aud39-ruas');
      modal.querySelector('#aud39-ruas-todas').onclick=()=>{[...selectRuas.options].forEach(o=>o.selected=true);};
      modal.querySelector('#aud39-ruas-limpar').onclick=()=>{[...selectRuas.options].forEach(o=>o.selected=false);};
      const inputArquivo=modal.querySelector('#aud39-arquivo');
      modal.querySelector('#aud39-escolher-arquivo').onclick=()=>inputArquivo.click();
      inputArquivo.onchange=()=>{
        arquivoSelecionado=inputArquivo.files&&inputArquivo.files[0]||null;
        modal.querySelector('#aud39-arquivo-nome').textContent=arquivoSelecionado?arquivoSelecionado.name:'Nenhum arquivo selecionado';
        modal.querySelector('#aud39-arquivo-status').innerHTML=arquivoSelecionado?'<div class="alert info"><div>📄</div><div>Arquivo selecionado. A validação será feita ao criar a auditoria.</div></div>':'';
      };
      modal.querySelector('#aud39-criar').onclick=async()=>{
        const nome=txt(modal.querySelector('#aud39-nome').value); if(!nome)return toast('Informe o nome da auditoria.','w');
        if(!arquivoSelecionado)return toast('Selecione a base da auditoria.','w');
        const modo=tipo.value; let selecao=[];
        if(modo==='rua')selecao=[...modal.querySelector('#aud39-ruas').selectedOptions].map(o=>o.value);
        else {const v=modal.querySelector('#aud39-prod').value;if(v)selecao=[v];}
        if(!selecao.length)return toast(modo==='rua'?'Selecione ao menos uma rua.':'Selecione uma família de produtos.','w');
        const familia=modo==='produto'?familias.find(f=>f.id===selecao[0]):null;
        const cfg={tipoAuditoria:modo,ruas:modo==='rua'?selecao:[],familiaId:familia?.id||'',familiaNome:familia?.nome||''};
        const btn=modal.querySelector('#aud39-criar'); btn.disabled=true; btn.textContent='Criando...';
        try{
          const preparada=await prepararImportacao(arquivoSelecionado,cfg);
          if(!preparada.validos.length)throw new Error('Nenhuma linha válida foi encontrada para esta auditoria.');
          const id=`AUD-${Date.now()}`;
          await DB().collection('dt_auditorias').doc(id).set({nome,loja:loja(),...cfg,familiaCodigos:familia?familia.produtos.map(p=>p.codigoInterno):[],status:'RASCUNHO',totalItens:0,totalPendentes:0,totalOk:0,totalDivergentes:0,totalVazios:0,criadoEm:agora(),criadoPor:usuario()});
          auditoriaAtual=id; metaAtual={id,nome,...cfg,status:'RASCUNHO'}; importacaoPendente={file:arquivoSelecionado,...preparada};
          await gravarImportacao();
          fechar();
          await popularSelect(); const sel=document.getElementById('aud-op-auditoria');if(sel)sel.value=id;
          await selecionarAuditoria(id);
          toast(`Auditoria criada com ${preparada.validos.length} item(ns). Agora ela pode ser liberada para os coletores.`,'s');
        }catch(e){
          console.error('[AUDITORIA] criação:',e);
          const status=modal.querySelector('#aud39-arquivo-status');if(status)status.innerHTML=`<div class="alert error"><div>⚠️</div><div>${esc(e.message||'Falha ao criar auditoria.')}</div></div>`;
          btn.disabled=false; btn.textContent='Criar e importar auditoria';
        }
      };
      modal.querySelector('#aud39-nome')?.focus();
    } finally {
      document.getElementById('aud-v52-loading')?.remove();
      if(meuToken===criacaoToken){
        criacaoPromise=null;
        if(!document.getElementById('modal-nova-aud-v39')) criacaoAberta=false;
      }
    }
    })();
    return criacaoPromise;
  }


  const txt = v => String(v == null ? '' : v).trim();
  const esc = v => txt(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const semAcento = v => txt(v).normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  const cab = v => semAcento(v).toUpperCase().replace(/[^A-Z0-9]/g,'');
  const dun = v => txt(v).replace(/[^0-9A-Za-z]/g,'').toUpperCase();
  const endNorm = v => txt(v).toUpperCase().replace(/\s+/g,'').replace(/[^A-Z0-9.\-_/]/g,'');
  const agora = () => new Date().toISOString();
  const usuario = () => window._currentAnalistaUser?.email || localStorage.getItem('dt_analista_email') || 'analista';
  const loja = () => window.getDTLojaAtiva?.() || window.DTMultiStore?.getLojaAtual?.()?.id || window.getLojaAtual?.()?.id || localStorage.getItem('dt_loja_atual') || '';
  const docId = (auditoriaId, endereco, codigo='', sequencia='') => `${auditoriaId}__${endNorm(endereco).replace(/[^A-Z0-9]/g,'_')}__${dun(codigo)||'VAZIO'}__${txt(sequencia)||'0'}`;
  const fmt = v => {
    if (!v) return '—';
    const d = v?.toDate ? v.toDate() : new Date(v);
    return isNaN(d) ? txt(v) : d.toLocaleString('pt-BR');
  };
  const toast = (m,t='i') => typeof window.showToast === 'function' ? window.showToast(m,t) : alert(m);

  function produtoPlaceholder(v){
    const n=semAcento(txt(v)).toUpperCase();
    return !n || ['PRODUTO NAO IDENTIFICADO','PRODUTO NAO CADASTRADO','CODIGO SEM CADASTRO','NAO IDENTIFICADO','SEM CADASTRO'].includes(n);
  }

  function buscarProdutoPorCodigo(codigo){
    const cod=txt(codigo);
    if(!cod || !window.DTProdutos?.buscarSync) return null;
    const ach=window.DTProdutos.buscarSync(cod);
    return ach?.encontrado ? ach : null;
  }

  function normalizarItem(raw, id){
    const statusRaw = txt(raw.status || 'PENDENTE').toUpperCase();
    const compatStatus = statusRaw === 'VAZIO' ? 'ENDERECO_VAZIO' :
      ['CONFIRMADO_SEM_AJUSTE','APROVADO','CORRETO','CONFERIDO','FINALIZADO'].includes(statusRaw) ? 'OK' :
      ['CONFIRMADO_COM_AJUSTE','ERRO'].includes(statusRaw) ? 'DIVERGENTE' : statusRaw;
    const dunEsperado=txt(raw.dunEsperado || raw.dun_esperado || raw.dun || raw.codigoProduto || raw.codigo_produto || raw.gtin || raw.ean || raw.gtin_principal || raw.codigo_barras || raw.codigo_de_barras);
    const dunLido=raw.dunLido == null ? txt(raw.dun_lido || raw.produtoEncontrado || raw.produto_encontrado || raw.codigoLido || raw.codigo_lido || raw.gtinLido || raw.gtin_lido || raw.eanLido || raw.ean_lido) || null : txt(raw.dunLido) || null;
    const esperadoCadastro=buscarProdutoPorCodigo(dunEsperado);
    const lidoCadastro=buscarProdutoPorCodigo(dunLido);
    const produtoEsperadoRaw=txt(raw.produtoEsperado || raw.produto_esperado || raw.descricaoProdutoEsperado || raw.produto_nome || raw.descricao || raw.produto);
    const produtoLidoRaw=txt(raw.produtoLido || raw.produto_lido || raw.descricaoProdutoLido || raw.produtoLidoNome || raw.produto_lido_nome);
    return {
      id,
      auditoriaId: txt(raw.auditoriaId || raw.auditoria_id || auditoriaAtual),
      endereco: txt(raw.endereco || raw.local || raw.posicao),
      dunEsperado,
      produtoEsperado: produtoPlaceholder(produtoEsperadoRaw) ? (esperadoCadastro?.nomeProduto || produtoEsperadoRaw) : produtoEsperadoRaw,
      dunLido,
      produtoLido: produtoPlaceholder(produtoLidoRaw) ? (lidoCadastro?.nomeProduto || produtoLidoRaw || null) : produtoLidoRaw,
      produtoLidoId: lidoCadastro?.produtoId || txt(raw.produtoLidoId || raw.produto_lido_id) || null,
      status: STATUS.includes(compatStatus) ? compatStatus : 'PENDENTE',
      operadorId: txt(raw.operadorId || raw.operador_id || raw.usuario) || null,
      operadorNome: txt(raw.operadorNome || raw.operador_nome || raw.operador || raw.confirmado_por) || null,
      lidoEm: raw.lidoEm || raw.lido_em || raw.dataHora || raw.data_hora || null,
      loja: txt(raw.loja || loja()),
      disponivel_coletor: raw.disponivel_coletor !== false
    };
  }

  function resumo(lista=itensAtuais){
    const r = {total:lista.length, PENDENTE:0, OK:0, DIVERGENTE:0, ENDERECO_VAZIO:0};
    lista.forEach(i => r[i.status]++);
    r.auditados = r.OK + r.DIVERGENTE + r.ENDERECO_VAZIO;
    r.percentual = r.total ? Math.round((r.auditados / r.total) * 100) : 0;
    return r;
  }

  function assinatura(lista){
    return JSON.stringify(lista.map(i => [i.id,i.status,i.dunLido,i.produtoLido,i.operadorNome,i.lidoEm?.seconds || i.lidoEm || '']));
  }

  function ambienteAuditoriaPronto(){
    const db=DB();
    const lojaAtiva=loja();
    const identificacao=window.AUTH_AN?.currentUser || window._currentAnalistaUser || localStorage.getItem('dt_analista_email');
    return !!(db && typeof db.collection==='function' && lojaAtiva && identificacao);
  }

  async function aguardarAmbienteAuditoria(ms=6000){
    const inicio=Date.now();
    while(Date.now()-inicio<ms){
      if(ambienteAuditoriaPronto()) return true;
      await new Promise(resolve=>setTimeout(resolve,120));
    }
    return ambienteAuditoriaPronto();
  }

  async function listarMetas(){
    if(!await aguardarAmbienteAuditoria()) return [];
    const raw=window.getDTRawFirestore?.();
    const atual=txt(loja());
    origemAuditoria.clear();
    const docs=[];
    const falhas=[];
    const vistos=new Set();
    async function adicionarColecao(ref, origem){
      try{
        const snap=await ref.get();
        snap.docs.forEach(function(d){
          if(vistos.has(d.id)) return;
          const data=d.data()||{};
          vistos.add(d.id);
          origemAuditoria.set(d.id,origem);
          docs.push({id:d.id,...data,_origemAuditoria:origem});
        });
      }catch(e){ falhas.push({origem:origem,code:e.code||'unknown',message:e.message||String(e)}); }
    }
    // 1) Loja atualmente selecionada.
    await adicionarColecao(colecaoAuditorias(),'loja:'+atual);
    const falhaPrincipal=falhas.find(f=>f.origem==='loja:'+atual);
    if(falhaPrincipal){const erro=new Error('Falha ao consultar a loja atual: '+falhaPrincipal.message);erro.code=falhaPrincipal.code;throw erro;}
    if(raw){
      const acesso=window.DT_USUARIO_ACESSO_ATUAL||{};
      const acessoGlobal=acesso.acesso_todas_lojas===true || acesso.perfil==='administrador' || acesso.admin_mestre===true || acesso.administrador_mestre===true;
      // 2) Procura também em todas as lojas cadastradas. Isso recupera auditorias
      // criadas antes da padronização de IDs (ex.: matriz x loja_matriz).
      if(acessoGlobal) try{
        const lojasSnap=await raw.collection('lojas').get();
        await Promise.all(lojasSnap.docs.map(async function(ld){
          const lid=ld.id;
          if(lid===atual) return;
          await adicionarColecao(raw.collection('lojas').doc(lid).collection('dt_auditorias'),'loja:'+lid);
        }));
      }catch(e){ console.warn('[AUDITORIA] falha ao procurar nas lojas:',e); }
      // 3) Auditorias antigas salvas na raiz.
      if(acessoGlobal) await adicionarColecao(raw.collection('dt_auditorias'),'raiz');
    }
    if(falhas.length) toast('Algumas origens administrativas não puderam ser consultadas: '+falhas.map(f=>f.origem).join(', ')+'.','w');
    return docs.sort(function(a,b){
      const av=a.criadoEm?.toMillis?.()||a.criadoEm?.seconds*1000||Date.parse(a.criadoEm||a.criado_em||a.importado_em||0)||0;
      const bv=b.criadoEm?.toMillis?.()||b.criadoEm?.seconds*1000||Date.parse(b.criadoEm||b.criado_em||b.importado_em||0)||0;
      return bv-av;
    });
  }

  function resolverAuditoriaSelecionada(){
    const sel=document.getElementById('aud-op-auditoria');
    const valor=txt(sel?.value);
    if(valor){ auditoriaAtual=valor; return valor; }
    if (auditoriaAtual) return auditoriaAtual;
    const opcoes=sel?[...sel.options].filter(o=>o.value):[];
    if(opcoes.length===1){ sel.value=opcoes[0].value; auditoriaAtual=opcoes[0].value; return auditoriaAtual; }
    return '';
  }

  function atualizarAcoesAuditoria(){
    const tem=!!resolverAuditoriaSelecionada();
    const btn=document.getElementById('btn-aud-atualizar-base');
    const excluir=document.getElementById('btn-aud-excluir');
    if(btn) btn.style.display=tem?'':'none';
    if(excluir) excluir.style.display=tem?'':'none';
  }

  async function importarBaseSelecionada(){
    if(!auditoriaAtual) return toast('Crie ou selecione uma auditoria antes de atualizar a base.','w');
    const input=document.getElementById('auditoria-file');
    if(input) input.click();
  }

  async function popularSelect(){
    const sel = document.getElementById('aud-op-auditoria');
    if (!sel) return [];
    const atual = auditoriaAtual || sel.value;
    if(!ambienteAuditoriaPronto()){
      sel.disabled=false;
      sel.innerHTML='<option value="">Selecione uma auditoria...</option>';
      return [];
    }
    sel.disabled=true;
    try{
      const metas = await listarMetas();
      // O proxy multiloja já direciona a coleção correta. Não esconder auditorias
      // por comparação textual de loja, pois documentos antigos podem ter loja vazia
      // ou nome/código em formato diferente.
      const visiveis=metas;
      sel.innerHTML = '<option value="">Selecione uma auditoria...</option>' + visiveis.map(m => {
        const st=txt(m.status||'RASCUNHO').toUpperCase();
        return `<option value="${esc(m.id)}">${esc(m.nome || m.auditoria_nome || m.id)} — ${esc(st)}</option>`;
      }).join('');
      if (atual && [...sel.options].some(o=>o.value===atual)) sel.value = atual;
      else if(visiveis.length===1){ sel.value=visiveis[0].id; auditoriaAtual=visiveis[0].id; }
      atualizarAcoesAuditoria();
      return visiveis;
    }catch(e){
      console.error('[AUDITORIA] listar auditorias:',e);
      const semLogin=!window.AUTH_AN?.currentUser && !window._currentAnalistaUser;
      if(semLogin){
        sel.innerHTML='<option value="">Selecione uma auditoria...</option>';
      }else{
        sel.innerHTML='<option value="">Falha ao carregar auditorias — clique em Atualizar</option>';
        toast('Não foi possível carregar as auditorias da loja atual: '+(e.message||e),'e');
      }
      return [];
    }finally{ sel.disabled=false; }
  }

  function encerrarListener(){
    assinaturaAnterior = '';
  }

  async function selecionarAuditoria(id){
    encerrarListener();
    auditoriaAtual = txt(id);
    itensAtuais = [];
    itensBrutosAtuais = [];
    metaAtual = null;
    atualizarAcoesAuditoria();
    renderizar();
    if (!auditoriaAtual) return;
    const ref = referenciaAuditoria(auditoriaAtual);
    const metaSnap = await ref.get();
    metaAtual = metaSnap.exists ? {id:metaSnap.id,...metaSnap.data()} : null;
    if(!metaAtual){
      toast('A auditoria selecionada não existe mais. Atualizando a lista.','w');
      auditoriaAtual='';
      await popularSelect();
      renderizar();
      return;
    }
    atualizarAcoesAuditoria();
    try{
      const [esperadosSnap,resultadosSnap,espelhoSnap]=await Promise.all([
        ref.collection('enderecos').get(),
        ref.collection('resultados').get(),
        DB().collection('dt_auditoria_resultados').where('auditoriaId','==',auditoriaAtual).get().catch(function(){return {docs:[]};})
      ]);
      const resultados=new Map();
      (resultadosSnap.docs||[]).forEach(function(d){resultados.set(d.id,d.data()||{});});
      (espelhoSnap.docs||[]).forEach(function(d){const x=d.data()||{};if(x.itemId)resultados.set(String(x.itemId),x);});
      itensBrutosAtuais=esperadosSnap.docs.map(d=>({id:d.id,raw:{...d.data(),...(resultados.get(d.id)||{})}}));
      itensAtuais=itensBrutosAtuais.map(x=>normalizarItem(x.raw,x.id));
      assinaturaAnterior=assinatura(itensAtuais);
      renderizar();
    }catch(error){
      console.error('[AUDITORIA] leitura manual:',error);
      throw error;
    }
  }

  async function sincronizarResumoMeta(){
    if (!auditoriaAtual) return;
    const r = resumo();
    const statusAtual = txt(metaAtual?.status || 'RASCUNHO').toUpperCase();
    const status = statusAtual === 'FINALIZADA' ? 'FINALIZADA' : (r.auditados ? 'EM_ANDAMENTO' : statusAtual);
    await referenciaAuditoria(auditoriaAtual).set({
      totalItens:r.total,totalPendentes:r.PENDENTE,totalOk:r.OK,totalDivergentes:r.DIVERGENTE,totalVazios:r.ENDERECO_VAZIO,status,atualizadoEm:agora()
    },{merge:true});
    metaAtual = {...metaAtual,totalItens:r.total,totalPendentes:r.PENDENTE,totalOk:r.OK,totalDivergentes:r.DIVERGENTE,totalVazios:r.ENDERECO_VAZIO,status};
  }

  function filtros(){
    return {
      status:txt(document.getElementById('aud-op-status')?.value).toUpperCase(),
      busca:txt(document.getElementById('aud-op-busca')?.value).toLowerCase(),
      dunEsperado:txt(document.getElementById('aud-f-dun-esperado')?.value).toLowerCase(),
      dunLido:txt(document.getElementById('aud-f-dun-lido')?.value).toLowerCase(),
      operador:txt(document.getElementById('aud-f-operador')?.value).toLowerCase(),
      data:txt(document.getElementById('aud-f-data')?.value)
    };
  }

  function aplicarFiltros(lista){
    const f = filtros();
    return lista.filter(i => {
      if (f.status && i.status !== f.status) return false;
      if (f.dunEsperado && !i.dunEsperado.toLowerCase().includes(f.dunEsperado)) return false;
      if (f.dunLido && !txt(i.dunLido).toLowerCase().includes(f.dunLido)) return false;
      if (f.operador && !txt(i.operadorNome).toLowerCase().includes(f.operador)) return false;
      if (f.data && i.lidoEm) {
        const d = i.lidoEm?.toDate ? i.lidoEm.toDate() : new Date(i.lidoEm);
        if (!isNaN(d)) {
          const dataLocal=[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');
          if(dataLocal !== f.data) return false;
        }
      } else if (f.data && !i.lidoEm) return false;
      if (f.busca) {
        const hay = [i.endereco,i.dunEsperado,i.produtoEsperado,i.dunLido,i.produtoLido,i.operadorNome,i.status].join(' ').toLowerCase();
        if (!hay.includes(f.busca)) return false;
      }
      return true;
    });
  }

  function rotuloStatus(s){ return ({PENDENTE:'Pendente',OK:'OK',DIVERGENTE:'Divergente',ENDERECO_VAZIO:'Endereço vazio'})[s] || s; }
  function classeStatus(s){ return s==='OK'?'ok':s==='DIVERGENTE'?'err':s==='ENDERECO_VAZIO'?'warn':'pending'; }

  const COLUNAS_AUDITORIA = [
    {chave:'endereco', rotulo:'Endereço', classe:'mono', valor:i=>i.endereco || '—'},
    {chave:'dunEsperado', rotulo:'DUN esperado', classe:'mono', valor:i=>i.dunEsperado || '—'},
    {chave:'produtoEsperado', rotulo:'Produto esperado', classe:'auditoria-produto', valor:i=>i.produtoEsperado || '—'},
    {chave:'dunLido', rotulo:'DUN lido', classe:'mono', valor:i=>i.dunLido || '—'},
    {chave:'produtoLido', rotulo:'Produto lido', classe:'auditoria-produto', valor:i=>i.produtoLido || '—'},
    {chave:'status', rotulo:'Resultado', classe:'auditoria-resultado', valor:i=>rotuloStatus(i.status)},
    {chave:'operadorNome', rotulo:'Operador', classe:'auditoria-operador', valor:i=>i.operadorNome || '—'},
    {chave:'lidoEm', rotulo:'Data/Hora', classe:'auditoria-data', valor:i=>fmt(i.lidoEm)}
  ];

  function criarLinhaAuditoria(item){
    const tr=document.createElement('tr');
    tr.className='auditoria-linha';
    tr.dataset.itemId=txt(item.id);
    COLUNAS_AUDITORIA.forEach(function(coluna){
      const td=document.createElement('td');
      td.className=txt(coluna.classe);
      td.dataset.coluna=coluna.chave;
      td.setAttribute('aria-label',coluna.rotulo);
      if(coluna.chave==='status'){
        const badge=document.createElement('span');
        badge.className='badge '+classeStatus(item.status);
        badge.textContent=coluna.valor(item);
        td.appendChild(badge);
      }else{
        td.textContent=coluna.valor(item);
      }
      tr.appendChild(td);
    });
    return tr;
  }

  function mostrarMensagemTabela(tbody,mensagem){
    const tr=document.createElement('tr');
    const td=document.createElement('td');
    td.colSpan=COLUNAS_AUDITORIA.length;
    td.className='auditoria-tabela-mensagem';
    td.textContent=mensagem;
    tr.appendChild(td);
    tbody.replaceChildren(tr);
  }

  function renderizar(){
    const r = resumo();
    const set = (id,v) => { const e=document.getElementById(id); if(e)e.textContent=v; };
    set('audop-k-total',r.total); set('audop-k-auditados',r.auditados); set('audop-k-pend',r.PENDENTE);
    set('audop-k-ok',r.OK); set('audop-k-div',r.DIVERGENTE); set('audop-k-vaz',r.ENDERECO_VAZIO); set('audop-k-perc',`${r.percentual}%`);
    const tbody = document.getElementById('auditoria-op-tbody');
    if (!tbody) return;
    const lista = aplicarFiltros(itensAtuais);
    const paginas=Math.max(1,Math.ceil(lista.length/ITENS_POR_PAGINA));
    paginaAtual=Math.min(paginaAtual,paginas);
    const inicio=(paginaAtual-1)*ITENS_POR_PAGINA;
    const pagina=lista.slice(inicio,inicio+ITENS_POR_PAGINA);
    if(pagina.length){
      const fragmento=document.createDocumentFragment();
      pagina.forEach(function(item){ fragmento.appendChild(criarLinhaAuditoria(item)); });
      tbody.replaceChildren(fragmento);
    }else{
      mostrarMensagemTabela(tbody,'Nenhum item encontrado.');
    }
    const nav=document.getElementById('auditoria-paginacao');
    if(nav){
      nav.innerHTML=lista.length?`<button type="button" class="btn btn-ghost btn-sm" data-aud-pagina="${paginaAtual-1}" ${paginaAtual<=1?'disabled':''}>Anterior</button><span>Página ${paginaAtual} de ${paginas} · ${lista.length} registro(s)</span><button type="button" class="btn btn-ghost btn-sm" data-aud-pagina="${paginaAtual+1}" ${paginaAtual>=paginas?'disabled':''}>Próxima</button>`:'';
      nav.querySelectorAll('[data-aud-pagina]').forEach(function(btn){btn.onclick=function(){paginaAtual=Number(btn.dataset.audPagina)||1;renderizar();};});
    }
    const resumoFinal = document.getElementById('auditoria-resumo-finalizacao');
    if (resumoFinal) resumoFinal.textContent = `Total ${r.total} · OK ${r.OK} · Divergentes ${r.DIVERGENTE} · Vazios ${r.ENDERECO_VAZIO} · Pendentes ${r.PENDENTE}`;
  }

  function detectarColunas(headers){
    const lista=(headers||[]).map(function(original){
      return { original:original, normal: cab(original) };
    });
    function achar(exatos, contem){
      const ex=(exatos||[]).map(cab);
      for(const h of lista){ if(ex.indexOf(h.normal)>=0) return h.original; }
      for(const h of lista){
        for(const termo of (contem||[]).map(cab)){ if(termo && h.normal.indexOf(termo)>=0) return h.original; }
      }
      return null;
    }
    return {
      endereco: achar(
        ['ENDEREÇO','ENDERECO','LOCAL','POSIÇÃO','POSICAO','LOCALIZAÇÃO','LOCALIZACAO','ADDRESS'],
        ['ENDERECO','POSICAO','LOCALIZACAO']
      ),
      dun: achar(
        ['GTIN','EAN','GTIN/EAN','EAN/GTIN','GTIN EAN','EAN GTIN','GTIN PRINCIPAL','EAN PRINCIPAL','DUN','DUN14','EAN14','GTIN14','CÓDIGO DE BARRAS','CODIGO DE BARRAS','COD BARRAS','BARCODE','CÓDIGO DO PRODUTO','CODIGO DO PRODUTO'],
        ['GTINEAN','EANGTIN','GTIN','EAN','DUN','CODIGODEBARRAS','CODBARRAS','BARCODE']
      ),
      produto: achar(
        ['PRODUTO','DESCRIÇÃO','DESCRICAO','NOME DO PRODUTO','DESCRIÇÃO DO PRODUTO','DESCRICAO DO PRODUTO','ITEM'],
        ['PRODUTO','DESCRICAO','NOMEITEM']
      )
    };
  }

  async function lerArquivo(file){
    const buffer = await file.arrayBuffer();
    const wb = XLSX.read(new Uint8Array(buffer), {type:'array',raw:false});
    const ws = wb.Sheets[wb.SheetNames[0]];
    return XLSX.utils.sheet_to_json(ws,{defval:'',raw:false});
  }

  async function prepararImportacao(file,cfg){
    const rows = await lerArquivo(file);
    if (!rows.length) throw new Error('O arquivo não possui linhas de dados.');
    const col = detectarColunas(Object.keys(rows[0]));
    const ausentes = [!col.endereco&&'Endereço',!col.dun&&'GTIN/EAN/DUN',!col.produto&&'Produto'].filter(Boolean);
    if (ausentes.length) throw new Error(`Colunas obrigatórias ausentes: ${ausentes.join(', ')}. Cabeçalhos encontrados: ${Object.keys(rows[0]).join(' | ')}`);
    const erros=[]; const validos=[];
    rows.forEach((r,idx) => {
      const linha=idx+2, endereco=txt(r[col.endereco]), dunEsperado=txt(r[col.dun]), produtoEsperado=txt(r[col.produto]);
      const motivos=[];
      if(!endereco) motivos.push('endereço vazio');
      if(!dunEsperado) motivos.push('GTIN/EAN vazio');
      if(!produtoEsperado) motivos.push('nome do produto vazio');
      if(motivos.length) erros.push({linha,endereco:endereco||'—',dunEsperado,produtoEsperado,motivo:motivos.join('; ')});
      else validos.push({endereco,dunEsperado,produtoEsperado,_linha:linha,_seq:idx});
    });
    let selecionados=validos;
    cfg=cfg||metaAtual||configuracaoNova||{};
    if(cfg.tipoAuditoria==='produto' && cfg.familiaId){
      const fam=(window.DTProdutos?.familias?.()||[]).find(f=>f.id===cfg.familiaId);
      const codigos=new Set((fam?.produtos||[]).flatMap(p=>[dun(p.codigoInterno),dun(p.dun),dun(p.gtin)]).filter(Boolean));
      selecionados=validos.filter(r=>codigos.has(dun(r.dunEsperado)) || txt(r.produtoEsperado).toLowerCase().includes(txt(cfg.familiaNome).toLowerCase()));
    }
    if(cfg.tipoAuditoria==='rua' && (cfg.ruas||[]).length){
      const ruasSet=new Set(cfg.ruas.map(txt)); selecionados=validos.filter(r=>ruasSet.has(ruaDoEndereco(r.endereco)));
      const existentes=new Set(selecionados.map(r=>endNorm(r.endereco)));
      const gerais=await enderecosGerais();
      gerais.forEach(e=>{const endereco=txt(e.endereco||e.codigo||e.id);if(endereco&&ruasSet.has(ruaDoEndereco(endereco))&&!existentes.has(endNorm(endereco)))selecionados.push({endereco,dunEsperado:'',produtoEsperado:'ENDEREÇO PREVISTO VAZIO',previstoVazio:true});});
    }
    const chaves=new Map();
    selecionados=selecionados.filter(function(row){
      const chave=endNorm(row.endereco)+'|'+dun(row.dunEsperado);
      if(chaves.has(chave)){
        erros.push({linha:row._linha||'—',endereco:row.endereco,dunEsperado:row.dunEsperado,produtoEsperado:row.produtoEsperado,motivo:'Duplicidade lógica com a linha '+chaves.get(chave)});
        return false;
      }
      chaves.set(chave,row._linha||'—');
      return true;
    });
    if(!selecionados.length) erros.push({linha:'—',endereco:'—',dunEsperado:'',produtoEsperado:'',motivo:'Nenhum item da base corresponde ao tipo selecionado para esta auditoria'});
    return {validos:selecionados,erros};
  }

  async function processarArquivo(file){
    if (!file) return;
    if(!auditoriaAtual) return toast('Crie ou selecione uma auditoria antes de atualizar a base.','w');
    try {
      const preparada=await prepararImportacao(file,metaAtual||{});
      if(!preparada.validos.length) throw new Error('Nenhuma linha válida foi encontrada.');
      importacaoPendente={file,...preparada};
      await gravarImportacao();
      toast(`Base atualizada com ${preparada.validos.length} item(ns).`,'s');
    } catch(e){ console.error(e); toast(e.message || 'Erro ao ler arquivo.','e'); }
  }

  async function gravarImportacao(){
    if(!importacaoPendente || !importacaoPendente.validos.length) return;
    if(!auditoriaAtual) throw new Error('Nenhuma auditoria selecionada.');
    const ref=referenciaAuditoria(auditoriaAtual);
    const itensRef=ref.collection('enderecos');
    const cegosRef=ref.collection('itens_coletor');
    const versaoBase='base_'+Date.now().toString(36);
    const [oldEsperados,oldCegos]=await Promise.all([itensRef.get(),cegosRef.get()]);
    const lista=importacaoPendente.validos;
    for(let i=0;i<lista.length;i+=350){
      const b=DB().batch();
      lista.slice(i,i+350).forEach(row=>{
        const id=docId(auditoriaAtual,row.endereco,row.dunEsperado,versaoBase+'_'+String(row._seq==null?'':row._seq));
        b.set(itensRef.doc(id),{
          auditoriaId:auditoriaAtual,endereco:row.endereco,dunEsperado:row.dunEsperado,produtoEsperado:row.produtoEsperado,
          previstoVazio:row.previstoVazio===true,status:'PENDENTE',loja:loja(),versaoBase:versaoBase
        });
        b.set(cegosRef.doc(id),{auditoriaId:auditoriaAtual,itemId:id,endereco:row.endereco,status:'PENDENTE',disponivel_coletor:false,loja:loja(),ordem:Number(row._seq||0),versaoBase:versaoBase,atualizadoEm:agora()});
      });
      await b.commit();
    }
    await ref.set({status:'RASCUNHO',liberada_coletor:false,versaoBase:versaoBase,totalItens:lista.length,totalPendentes:lista.length,totalOk:0,totalDivergentes:0,totalVazios:0,arquivo:importacaoPendente.file.name,importadoEm:agora(),importadoPor:usuario()},{merge:true});
    await DB().collection('dt_auditorias_coletor').doc(auditoriaAtual).delete().catch(function(e){if(e.code!=='not-found')throw e;});
    const antigos=[...oldEsperados.docs,...oldCegos.docs].filter(d=>txt((d.data()||{}).versaoBase)!==versaoBase);
    for(let i=0;i<antigos.length;i+=350){const b=DB().batch();antigos.slice(i,i+350).forEach(d=>b.delete(d.ref));await b.commit();}
    importacaoPendente=null;
    const status=document.getElementById('auditoria-import-status'); if(status) status.innerHTML='';
    const preview=document.getElementById('auditoria-import-preview'); if(preview){preview.innerHTML='';preview.style.display='none';}
    const actions=document.getElementById('auditoria-import-actions'); if(actions)actions.style.display='none';
  }

  async function criarNova(){ try{return await abrirCriacaoAuditoria();}catch(e){const l=document.getElementById('aud-v52-loading');if(l)l.remove();console.error('[AUDITORIA] abrir criação:',e);toast('Não foi possível abrir a criação da auditoria: '+(e.message||e),'e');} }

  async function confirmarImportacao(){
    try{ await gravarImportacao(); toast('Base importada com sucesso.','s'); }
    catch(e){ console.error(e); toast(e.message||'Falha ao importar a base.','e'); }
  }

  async function liberar(){
    const id=resolverAuditoriaSelecionada();
    if(!id) return toast('Selecione uma auditoria na lista acima.','w');
    if(id!==auditoriaAtual || !metaAtual) await selecionarAuditoria(id);
    if(!itensAtuais.length) return toast('Importe uma base válida antes de liberar.','w');
    const ref=referenciaAuditoria(auditoriaAtual);
    const snap=await ref.collection('itens_coletor').get();
    for(let i=0;i<snap.docs.length;i+=350){const b=DB().batch();snap.docs.slice(i,i+350).forEach(d=>b.set(d.ref,{disponivel_coletor:true,status:'PENDENTE',atualizadoEm:agora()},{merge:true}));await b.commit();}
    await ref.set({status:'LIBERADA',liberada_coletor:true,liberadaEm:agora(),liberadaPor:usuario()},{merge:true});
    await DB().collection('dt_auditorias_coletor').doc(auditoriaAtual).set({id:auditoriaAtual,auditoria_nome:metaAtual?.nome||metaAtual?.auditoria_nome||auditoriaAtual,status:'LIBERADA',loja:loja(),lojas:[loja()],total_registros:snap.size,totalItens:snap.size,tipoAuditoria:metaAtual?.tipoAuditoria||'',versaoBase:metaAtual?.versaoBase||'',liberadaEm:agora(),atualizadoEm:agora()});
    metaAtual={...metaAtual,status:'LIBERADA'};
    toast('Auditoria liberada para os coletores.','s');
  }

  async function finalizar(){
    const id=resolverAuditoriaSelecionada();
    if(!id) return toast('Selecione uma auditoria na lista acima.','w');
    bloquearInterface(true,'Validando pendências no servidor…');
    try{
      await selecionarAuditoria(id);
      const r=resumo();
      const filaLocal=Number(localStorage.getItem('dt_auditoria_sync_pendente')||0);
      if(filaLocal>0) throw new Error('Existem sincronizações pendentes neste navegador.');
      if(!confirm(`Finalizar auditoria?\nTotal: ${r.total}\nOK: ${r.OK}\nDivergentes: ${r.DIVERGENTE}\nVazios: ${r.ENDERECO_VAZIO}`)) return;
      const resposta=await callable('finalizarAuditoria')({lojaId:loja(),auditoriaId:id});
      await DB().collection('dt_auditorias_coletor').doc(id).delete().catch(function(e){if(e.code!=='not-found')throw e;});
      await selecionarAuditoria(id);
      toast('Auditoria finalizada com validação do servidor.','s');
      return resposta.data;
    }catch(e){console.error('[AUDITORIA] finalizar:',e);toast('Não foi possível finalizar: '+(e.message||e),'e');}
    finally{bloquearInterface(false);}
  }

  async function excluir(){
    const sel=document.getElementById('aud-op-auditoria');
    const id=txt(sel?.value || auditoriaAtual);
    if(!id) return toast('Selecione a auditoria que deseja excluir.','w');
    let meta=metaAtual;
    if(!meta || txt(meta.id)!==id){
      try{ const ms=await referenciaAuditoria(id).get(); meta=ms.exists?{id:ms.id,...ms.data()}:null; }catch(e){ console.warn("[Erro tratado]", e); }
    }
    const nome=txt(meta?.nome || meta?.auditoria_nome || (sel?.selectedOptions?.[0]?.textContent||id).split(' — ')[0] || id);
    const mensagem=`Excluir definitivamente a auditoria “${nome}”?\n\nTodos os endereços e resultados dessa auditoria serão apagados, e ela deixará de aparecer nos coletores.`;
    if(!window.confirm(mensagem)) return;
    const btn=document.getElementById('btn-aud-excluir');
    if(btn){ btn.disabled=true; btn.dataset.textoOriginal=btn.textContent; btn.textContent='Excluindo...'; }
    try{
      encerrarListener();
      await callable('excluirAuditoriaCompleta')({lojaId:loja(),auditoriaId:id});
      await DB().collection('dt_auditorias_coletor').doc(id).delete().catch(function(e){if(e.code!=='not-found')throw e;});
      auditoriaAtual=''; metaAtual=null; itensAtuais=[]; itensBrutosAtuais=[]; assinaturaAnterior='';
      if(sel) sel.value='';
      await popularSelect();renderizar();atualizarAcoesAuditoria();
      toast(`Auditoria “${nome}” e todos os dados filhos foram removidos.`,'s');
    }catch(e){
      console.error('[AUDITORIA] excluir:',e);
      toast('Falha ao excluir a auditoria: '+(e.message||e),'e');
    }finally{
      if(btn){ btn.disabled=false; btn.textContent=btn.dataset.textoOriginal||'🗑 Excluir'; }
    }
  }

  async function atualizarListaAuditorias(){
    const metas=await popularSelect();
    const sel=document.getElementById('aud-op-auditoria');
    if(sel?.value) await selecionarAuditoria(sel.value);
    else if(!metas.length) renderizar();
  }

  function exportar(){
    const id=resolverAuditoriaSelecionada();
    if(!id || !itensAtuais.length) return toast('Selecione uma auditoria com dados.','w');
    const rows=aplicarFiltros(itensAtuais).map(i=>({
      Auditoria:metaAtual?.nome||metaAtual?.auditoria_nome||auditoriaAtual,Loja:i.loja||metaAtual?.loja||loja(),Endereço:i.endereco,
      'GTIN/EAN esperado':i.dunEsperado,'Produto esperado':i.produtoEsperado,'GTIN/EAN lido':i.dunLido||'','Produto lido':i.produtoLido||'',
      Resultado:rotuloStatus(i.status),Operador:i.operadorNome||'','Data e hora':fmt(i.lidoEm)
    }));
    const ws=XLSX.utils.json_to_sheet(rows), wb=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb,ws,'Auditoria');
    XLSX.writeFile(wb,`auditoria-${auditoriaAtual}.xlsx`);
  }

  // Sobrescreve apenas as funções públicas da aba Auditoria.
  window.detectarColunasAuditoria=detectarColunas;
  window.processFileAuditoria=processarArquivo;
  window.importarBaseAuditoriaSelecionada=importarBaseSelecionada;
  window.confirmarImportAuditoria=confirmarImportacao;
  window.criarNovaAuditoriaStandalone=criarNova;
  window.__auditoriaCriarVersao='v83-fluxo-v54';
  window.liberarAuditoriaColetores=liberar;
  window.finalizarAuditoriaOperacional=finalizar;
  window.excluirAuditoriaOperacional=excluir;
  window.atualizarListaAuditorias=atualizarListaAuditorias;
  window.atualizarAuditoriaOperacionalManual=atualizarListaAuditorias;
  window.exportarAuditoriaOperacional=exportar;
  window.renderAuditoriaOperacional=function(){
    renderizar();
  };
  window.encerrarListenerAuditoriaPorTrocaLoja=function(){
    encerrarListener();
    auditoriaAtual='';
    metaAtual=null;
    itensAtuais=[];
    itensBrutosAtuais=[];
    atualizarAcoesAuditoria();
  };
  window.recarregarAuditoriaAposTrocaLoja=async function(){
    encerrarListener();
    auditoriaAtual='';
    metaAtual=null;
    itensAtuais=[];
    itensBrutosAtuais=[];
    atualizarAcoesAuditoria();
    await popularSelect();
    const sel=document.getElementById('aud-op-auditoria');
    const first=(sel&&sel.value)||'';
    if(first) await selecionarAuditoria(first); else renderizar();
  };


  function reprocessarItensComProdutos(){
    if(!itensBrutosAtuais.length) return;
    const nova=itensBrutosAtuais.map(x=>normalizarItem(x.raw,x.id));
    const sig=assinatura(nova);
    itensAtuais=nova;
    assinaturaAnterior=sig;
    renderizar();
  }
  window.addEventListener('dt-produtos-atualizados',reprocessarItensComProdutos);

  function inicializarEventosAuditoria(){
    if(window.__auditoriaOperacionalV22Eventos) return;
    window.__auditoriaOperacionalV22Eventos=true;
    const sel=document.getElementById('aud-op-auditoria');
    if(sel){ sel.onchange=async function(){
      const anterior=auditoriaAtual;
      const proxima=txt(sel.value);
      bloquearInterface(true,'Carregando a auditoria selecionada…');
      try{
        await selecionarAuditoria(proxima);
      }catch(error){
        console.error('[AUDITORIA] seleção:',error);
        sel.value=anterior;
        try{ await selecionarAuditoria(anterior); }catch(restauracao){ console.error('[AUDITORIA] restauração:',restauracao); }
        toast('Não foi possível carregar a auditoria selecionada: '+(error.message||error),'e');
      }finally{
        bloquearInterface(false);
        atualizarAcoesAuditoria();
      }
    }; }
    let filtroTimer=null;
    ['aud-op-status','aud-op-busca','aud-f-dun-esperado','aud-f-dun-lido','aud-f-operador','aud-f-data'].forEach(function(id){
      const e=document.getElementById(id);
      if(e && e.dataset.auditoriaEvento!=='1'){
        e.dataset.auditoriaEvento='1';
        e.addEventListener(e.tagName==='SELECT'?'change':'input',function(){
          paginaAtual=1;
          clearTimeout(filtroTimer);
          filtroTimer=setTimeout(renderizar,e.tagName==='SELECT'?0:180);
        });
      }
    });
    // Não consultar o Firestore na tela de login. A lista será carregada somente
    // quando a aba Auditoria for aberta após autenticação e seleção da loja.
    renderizar();
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',inicializarEventosAuditoria,{once:true});
  else inicializarEventosAuditoria();
  window.addEventListener('beforeunload',encerrarListener,{once:true});
})();
