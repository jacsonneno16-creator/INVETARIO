function state(){ return window.AnalistaStore.getState(); }
// Fonte operacional única: mantém o histórico bruto no Store, mas todos os
// indicadores do Dashboard enxergam apenas a última rodada física concluída.
// Assim, uma recontagem substitui integralmente a rodada anterior também nos
// cards, gráficos, progresso e rankings.
function _dashContagens(inventarioId, ignorarFiltroHora){
  const st=state();
  let rows;
  if(window.InventoryAddressState?.latestPhysicalRows){
    rows = window.InventoryAddressState.latestPhysicalRows(st,inventarioId);
  } else {
    // Falha segura durante bootstrap: não quebra a tela antes do motor carregar.
    rows = (st.contagens||[]).filter(c=>
      (!inventarioId || String(c.inventario_id||c.inventarioId||'')===String(inventarioId)) &&
      !c._excluida && !['ESTORNADA','EXCLUIDA'].includes(String(c.status||'').toUpperCase())
    );
  }
  // Fonte central usada por praticamente todo indicador do dashboard — filtrar
  // por hora aqui propaga automaticamente pra progresso, rankings e KPIs.
  // ignorarFiltroHora=true é usado só pelo próprio gráfico "Produção por
  // hora", que precisa sempre das 24 horas pra desenhar as barras clicáveis.
  if (ignorarFiltroHora) return rows;
  return _dashFiltroHora===null ? rows : rows.filter(_dashRegistroNaHora);
}
function _dashLocalName(e){
  return String(e?.setor || e?.local || e?.nome_local || e?.nomeLocal || e?.local_area || e?.local_estoque || 'SEM LOCAL').trim() || 'SEM LOCAL';
}
// ───────────────────────────────────────────────────────────────────
//  11. RENDERIZAÇÃO — DASHBOARD
// ───────────────────────────────────────────────────────────────────

function limparFiltrosDash() {
  ['dash-finv','dash-frua','dash-flocal'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  _dashFiltroHora = null;
  renderDashboard();
}

let _dashCache = null;

// Hora (0-23) selecionada no gráfico "Produção por hora" do dashboard v254 —
// null = sem filtro. Ao clicar numa hora, TODOS os cards do dashboard
// (progresso, resumo, rankings, operadores) passam a considerar só o que
// aconteceu naquela hora específica, não o total acumulado.
let _dashFiltroHora = null;

function _dashRegistroNaHora(registro) {
  if (_dashFiltroHora === null) return true;
  const iso = _dashDataRegistro(registro);
  if (!iso) return false;
  const d = new Date(iso);
  return !isNaN(d) && d.getHours() === _dashFiltroHora;
}

function dashApplyHoraFilter(hora) {
  const h = Number(hora);
  _dashFiltroHora = (_dashFiltroHora === h) ? null : h;
  renderDashboard();
}

function renderDashboardInventario() {
  _dashAtualizarRotulosModo('inventario');
  // ── Preencher selects de filtro ──
  const fInvEl   = document.getElementById('dash-finv');
  const fRuaEl   = document.getElementById('dash-frua');
  const fLocalEl = document.getElementById('dash-flocal');

  const fInvId  = fInvEl?.value   || '';
  const fRua    = fRuaEl?.value   || '';
  const fLocal  = fLocalEl?.value || '';

  // Preencher select de inventários ativos
  if (fInvEl) {
    const cur = fInvEl.value;
    fInvEl.innerHTML = '<option value="">Todos os inventários ativos</option>' +
      getInventariosAtivos().map(i => `<option value="${i.id}" ${i.id===cur?'selected':''}>${escHTML(i.codigo)} — ${escHTML(i.nome)}</option>`).join('');
    if (cur) fInvEl.value = cur;
  }

  // Endereços cadastrados e endereços operacionais ativos.
  // O card 'End. cadastrados' deve mostrar a mesma quantidade da aba Endereços.
  const endsBaseTodos = state().enderecosLista || [];
  const endsBaseAtivos = endsBaseTodos.filter(e => e.ativo !== false);

  // Preencher selects de rua e local
  if (fRuaEl) {
    const cur = fRuaEl.value;
    const ruas = [...new Set(endsBaseAtivos.map(e => e.rua || extrairRua(e.endereco) || 'SEM RUA'))].sort((a,b)=>a.localeCompare(b,'pt-BR',{numeric:true}));
    fRuaEl.innerHTML = '<option value="">Todas as ruas</option>' + ruas.map(r=>`<option value="${escHTML(r)}" ${r===cur?'selected':''}>Rua ${escHTML(r)}</option>`).join('');
    if (cur) fRuaEl.value = cur;
  }
  if (fLocalEl) {
    const cur = fLocalEl.value;
    const locais = [...new Set(endsBaseAtivos.map(_dashLocalName))].sort((a,b)=>a.localeCompare(b,'pt-BR',{numeric:true}));
    fLocalEl.innerHTML = '<option value="">Todos os locais</option>' + locais.map(l=>`<option value="${escHTML(l)}" ${l===cur?'selected':''}>${escHTML(l)}</option>`).join('');
    if (cur) fLocalEl.value = cur;
  }

  // Inventários a considerar (filtrado por select ou todos ativos)
  const ativos = getInventariosAtivos();
  const invsConsiderados = fInvId ? ativos.filter(i => i.id === fInvId) : ativos;

  // Endereços filtrados por rua/local
  let endsFiltered = endsBaseAtivos;
  if (fRua)   endsFiltered = endsFiltered.filter(e => (e.rua || extrairRua(e.endereco) || 'SEM RUA') === fRua);
  if (fLocal) endsFiltered = endsFiltered.filter(e => _dashLocalName(e) === fLocal);

  const endsFilteredSet = new Set(endsFiltered.map(e => e.endereco));

  const totalEnds  = state().enderecosLista.length;
  const contagensFisicas = _dashContagens();
  const totalConts = contagensFisicas.length;

  let endContadosTotal = 0;
  let pendentesTotal   = 0;
  invsConsiderados.forEach(inv => {
    const contsInv = _dashContagens(inv.id);
    const contados = new Set(contsInv.filter(c => !_isVazio(c)).map(c => c.endereco));
    const vaziosConf = new Set(contsInv.filter(c => _isVazio(c) && c.status !== 'ESTORNADA').map(c => c.endereco));
    endsFiltered.forEach(e => {
      if (contados.has(e.endereco) || vaziosConf.has(e.endereco)) endContadosTotal++;
      else pendentesTotal++;
    });
  });

  const divAbertos = state().divergencias.filter(d => {
    if (fInvId && d.inventario_id !== fInvId) return false;
    return d.status === 'ABERTA';
  }).length;
  const recPend = state().recontagens.filter(r => {
    if (fInvId && r.inventario_id !== fInvId) return false;
    return r.status === 'PENDENTE';
  }).length;

  const base4Pct = endsFiltered.length > 0 ? endsFiltered.length : endsBaseAtivos.length;
  const pctGeral = base4Pct > 0 && invsConsiderados.length > 0
    ? Math.round((endContadosTotal / (base4Pct * invsConsiderados.length)) * 100) : 0;

  const contagensConsideradas = contagensFisicas.filter(c => {
    if (c._excluida) return false;
    if (fInvId && c.inventario_id !== fInvId) return false;
    if (fRua || fLocal) {
      const end = state().enderecosLista.find(e => e.endereco === c.endereco) || {};
      const rua = end.rua || extrairRua(c.endereco) || 'SEM RUA';
      const local = _dashLocalName(end);
      if (fRua && rua !== fRua) return false;
      if (fLocal && local !== fLocal) return false;
    }
    return true;
  });

  // Mesma lista, mas ignorando o filtro de hora — usada só pelo gráfico
  // "Produção por hora", que precisa sempre mostrar as 24 horas pra
  // continuar clicável mesmo com uma hora já selecionada.
  const contagensFisicasSemHora = _dashContagens(undefined, true);
  const contagensConsideradasSemHora = contagensFisicasSemHora.filter(c => {
    if (c._excluida) return false;
    if (fInvId && c.inventario_id !== fInvId) return false;
    if (fRua || fLocal) {
      const end = state().enderecosLista.find(e => e.endereco === c.endereco) || {};
      const rua = end.rua || extrairRua(c.endereco) || 'SEM RUA';
      const local = _dashLocalName(end);
      if (fRua && rua !== fRua) return false;
      if (fLocal && local !== fLocal) return false;
    }
    return true;
  });

  // Operadores ativos
  const opsAtivos = new Set();
  invsConsiderados.forEach(inv => {
    _dashContagens(inv.id).filter(c => c.operador).forEach(c => opsAtivos.add(c.operador));
  });

  document.getElementById('kd-inventarios').textContent  = invsConsiderados.length;
  const totalCadastradosCard = (fRua || fLocal)
    ? endsBaseTodos.filter(e => (!fRua || (e.rua || extrairRua(e.endereco) || 'SEM RUA') === fRua) && (!fLocal || _dashLocalName(e) === fLocal)).length
    : endsBaseTodos.length;
  document.getElementById('kd-enderecos').textContent    = totalCadastradosCard.toLocaleString('pt-BR');
  document.getElementById('kd-end-contados').textContent = endContadosTotal.toLocaleString('pt-BR');
  document.getElementById('kd-contagens').textContent    = totalConts.toLocaleString('pt-BR');
  document.getElementById('kd-pendencias').textContent   = pendentesTotal.toLocaleString('pt-BR');
  document.getElementById('kd-diverg').textContent       = divAbertos.toLocaleString('pt-BR');
  document.getElementById('kd-recount').textContent      = recPend.toLocaleString('pt-BR');
  document.getElementById('kd-pct-geral').textContent    = pctGeral + '%';
  document.getElementById('kd-operadores').textContent   = opsAtivos.size;

  _dashCache = {
    filtros: { inventarioId: fInvId, rua: fRua, local: fLocal },
    invsConsiderados,
    endsBaseAtivos,
    endsBase: endsFiltered.length ? endsFiltered : endsBaseAtivos,
    endsFiltered,
    contagensConsideradas,
    contagensConsideradasSemHora,
    pctGeral,
    endContadosTotal,
    pendentesTotal,
    divAbertos,
    recPend,
    opsAtivos: [...opsAtivos]
  };

  // Alertas
  const pausados = state().inventarios.filter(i => i.status === 'PAUSADO');
  let alertas = '';
  if (ativos.length === 0) {
    alertas += `<div class="alert info" style="margin-bottom:8px">📦 Nenhum inventário ativo. <a href="#" onclick="abrirNovoInventario()" style="color:var(--accent)">Criar novo inventário</a></div>`;
  }
  if (pausados.length > 0) {
    alertas += `<div class="alert warn" style="margin-bottom:8px">⏸️ ${pausados.length} inventário(s) <strong>PAUSADO(s)</strong>: ${pausados.map(i=>i.nome).join(', ')} — verifique se deve ser retomado.</div>`;
  }
  if (divAbertos > 5) {
    alertas += `<div class="alert warn" style="margin-bottom:8px">⚠️ <strong>${divAbertos}</strong> contagens em conflito aguardando resolução. <a href="#" onclick="goPage('recontagens',document.getElementById('nav-recontagens'))" style="color:var(--accent)">Ver recontagens →</a></div>`;
  }
  if (recPend > 0) {
    alertas += `<div class="alert warn" style="margin-bottom:8px">🔄 <strong>${recPend}</strong> rodada(s) pendente(s) aguardando execução. <a href="#" onclick="goPage('recontagens',document.getElementById('nav-recontagens'))" style="color:var(--accent)">Ver rodadas →</a></div>`;
  }
  // Alerta: contagens com inventario_id='local' — coletor salvou sem inventário definido
  const contagensLocais = contagensFisicas.filter(c => c.inventario_id === 'local');
  if (contagensLocais.length > 0) {
    alertas += `<div class="alert warn" style="margin-bottom:8px">⚠️ <strong>${contagensLocais.length} contagem(ns)</strong> chegaram sem vínculo de inventário (operador contou antes de selecionar o inventário corretamente). <a href="#" onclick="goPage('contagens',document.getElementById('nav-contagens'))" style="color:var(--accent)">Ver contagens →</a></div>`;
  }
  if (pctGeral >= 100 && invsConsiderados.length > 0) {
    alertas += `<div class="alert info" style="margin-bottom:8px">🎉 Todos os endereços foram contados! Verifique as divergências e feche o inventário.</div>`;
  }
  if (fInvId || fRua || fLocal) {
    const tags = [fInvId && `inventário: ${invsConsiderados[0]?.nome||fInvId}`, fRua && `rua: ${fRua}`, fLocal && `local: ${fLocal}`].filter(Boolean).join(' · ');
    alertas = `<div class="alert info" style="margin-bottom:8px">🔎 Filtros ativos: <strong>${tags}</strong> — KPIs calculados para a seleção.</div>` + alertas;
  }
  document.getElementById('dash-alert-wrap').innerHTML = alertas;

  // Barras de progresso
  const endsBase = endsFiltered.length ? endsFiltered : endsBaseAtivos;
  let progressHtml = '';
  invsConsiderados.slice(0,3).forEach(inv => {
    const contsInv2 = _dashContagens(inv.id);
    const contados2 = new Set(contsInv2.filter(c => !_isVazio(c)).map(c => c.endereco));
    const vaziosConf2 = new Set(contsInv2.filter(c => _isVazio(c) && c.status !== 'ESTORNADA').map(c => c.endereco));
    const conferidos2 = cod => contados2.has(cod) || vaziosConf2.has(cod);
    const conferidosAtivosInv = endsBase.filter(e => conferidos2(e.endereco)).length;
    const pct = endsBase.length > 0 ? Math.round((conferidosAtivosInv / endsBase.length) * 100) : 0;
    const color = pct >= 80 ? 'green' : pct >= 50 ? 'blue' : 'yellow';
    progressHtml += `
      <div style="padding:14px 20px;border-bottom:1px solid var(--border)">
        <div style="display:flex;justify-content:space-between;margin-bottom:8px">
          <span style="font-weight:600;font-size:.83rem">${escHTML(inv.nome)}</span>
          <span class="badge ${statusBadge(inv.status)}">${inv.status}</span>
        </div>
        <div class="prog-wrap">
          <div class="prog"><div class="prog-fill ${color}" style="width:${pct}%"></div></div>
          <span class="prog-label">${pct}%</span>
        </div>
        <div style="font-size:.7rem;color:var(--muted);margin-top:4px">${conferidosAtivosInv} de ${endsBase.length} endereços${fRua||fLocal?' (filtrados)':''} conferidos</div>
      </div>`;
  });
  document.getElementById('dash-progress-wrap').innerHTML = progressHtml ? `<div class="tc">${progressHtml}</div>` : '';

  // ── Progresso por Rua e Local ──
  _renderDashboardCharts();
  _renderDashRuas(endsBase, invsConsiderados);
  _renderDashLocais(endsBase, invsConsiderados);

  // Tabela resumo
  if (!state().inventarios.length) {
    document.getElementById('dash-inv-table').innerHTML = `<div class="empty"><div class="empty-icon">📦</div><div class="empty-title">Nenhum inventário</div><div class="empty-sub">Clique em + Novo Inventário</div></div>`;
    return;
  }
  document.getElementById('dash-inv-table').innerHTML = `
    <div class="tbl-wrap">
      <table>
        <thead><tr><th>Código</th><th>Nome</th><th>Data</th><th>Status</th><th>Progresso</th><th>Ações</th></tr></thead>
        <tbody>
          ${state().inventarios.slice(0,8).map(inv => {
            const contsInv3 = _dashContagens(inv.id);
            const contadosSet3 = new Set(contsInv3.filter(c => !_isVazio(c)).map(c => c.endereco));
            const vaziosConfSet3 = new Set(contsInv3.filter(c => _isVazio(c) && c.status !== 'ESTORNADA').map(c => c.endereco));
            const conferidos3 = new Set([...contadosSet3, ...vaziosConfSet3]);
            const endsAtivosTotal = state().enderecosLista.filter(e => e.ativo !== false).length;
            const pct = endsAtivosTotal > 0 ? Math.round((conferidos3.size / endsAtivosTotal) * 100) : 0;
            return `<tr>
              <td class="mono">${inv.codigo}</td>
              <td style="font-weight:600">${escHTML(inv.nome)}</td>
              <td class="mono" style="color:var(--muted)">${fmtData(inv.data_inicio)}</td>
              <td><span class="badge ${statusBadge(inv.status)}">${inv.status}</span></td>
              <td>
                <div class="prog-wrap">
                  <div class="prog"><div class="prog-fill ${pct>=80?'green':pct>=50?'blue':'yellow'}" style="width:${pct}%"></div></div>
                  <span class="prog-label">${pct}%</span>
                </div>
              </td>
              <td><button class="btn btn-ghost btn-sm" onclick="verBase('${inv.id}')">Ver Base</button></td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>`;
}

// ───────────────────────────────────────────────────────────────────
//  11b. DASHBOARD — Progresso por Rua e por Local
// ───────────────────────────────────────────────────────────────────

function _renderDashRuas(endsBase, invsConsiderados) {
  const el = document.getElementById('dash-ruas-wrap');
  if (!el) return;
  if (!endsBase.length) { el.innerHTML = `<div class="empty" style="padding:16px"><div class="empty-icon">🛣️</div><div class="empty-title">Sem endereços</div></div>`; return; }

  const invs = invsConsiderados || getInventariosAtivos();
  // Mapear contagens e vazios dos inventários considerados
  const contadosSet = new Set();
  const vaziosConfSet = new Set();
  invs.forEach(inv => {
    _dashContagens(inv.id).forEach(c => {
      if (_isVazio(c) && c.status !== 'ESTORNADA') vaziosConfSet.add(c.endereco);
      else contadosSet.add(c.endereco);
    });
  });

  // Agrupar por rua
  const ruas = {};
  endsBase.forEach(e => {
    const rua = e.rua || extrairRua(e.endereco) || 'SEM RUA';
    if (!ruas[rua]) ruas[rua] = { total: 0, contados: 0 };
    ruas[rua].total++;
    if (contadosSet.has(e.endereco) || vaziosConfSet.has(e.endereco)) ruas[rua].contados++;
  });

  const sorted = Object.entries(ruas).sort((a,b) => {
    const pctA = a[1].total > 0 ? a[1].contados/a[1].total : 0;
    const pctB = b[1].total > 0 ? b[1].contados/b[1].total : 0;
    return pctA - pctB; // menor progresso primeiro
  });

  if (!sorted.length) { el.innerHTML = `<div class="empty" style="padding:16px"><div class="empty-icon">🛣️</div><div class="empty-title">Sem ruas mapeadas</div></div>`; return; }

  el.innerHTML = sorted.map(([rua, d]) => {
    const pct = d.total > 0 ? Math.round((d.contados/d.total)*100) : 0;
    const color = pct >= 80 ? 'green' : pct >= 40 ? 'orange' : 'red';
    return `<div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
        <span style="font-size:.78rem;font-weight:600">${escHTML(rua)}</span>
        <span style="font-size:.7rem;color:var(--muted);font-family:var(--mono)">${d.contados}/${d.total} · ${pct}%</span>
      </div>
      <div style="display:flex;align-items:center;gap:8px">
        <div class="mini-prog"><div class="mini-prog-fill ${color}" style="width:${pct}%"></div></div>
      </div>
    </div>`;
  }).join('');
}

function _renderDashLocais(endsBase, invsConsiderados) {
  const el = document.getElementById('dash-locais-wrap');
  if (!el) return;
  if (!endsBase.length) { el.innerHTML = `<div class="empty" style="padding:16px"><div class="empty-icon">🏭</div><div class="empty-title">Sem endereços</div></div>`; return; }

  const invs = invsConsiderados || getInventariosAtivos();
  const contadosSet = new Set();
  const vaziosConfSet = new Set();
  invs.forEach(inv => {
    _dashContagens(inv.id).forEach(c => {
      if (_isVazio(c) && c.status !== 'ESTORNADA') vaziosConfSet.add(c.endereco);
      else contadosSet.add(c.endereco);
    });
  });

  const locais = {};
  endsBase.forEach(e => {
    const local = _dashLocalName(e);
    if (!locais[local]) locais[local] = { total: 0, contados: 0 };
    locais[local].total++;
    if (contadosSet.has(e.endereco) || vaziosConfSet.has(e.endereco)) locais[local].contados++;
  });

  const sorted = Object.entries(locais).sort((a,b) => {
    const pctA = a[1].total > 0 ? a[1].contados/a[1].total : 0;
    const pctB = b[1].total > 0 ? b[1].contados/b[1].total : 0;
    return pctA - pctB;
  });

  if (!sorted.length) { el.innerHTML = `<div class="empty" style="padding:16px"><div class="empty-icon">🏭</div><div class="empty-title">Sem locais mapeados</div></div>`; return; }

  el.innerHTML = sorted.map(([local, d]) => {
    const pct = d.total > 0 ? Math.round((d.contados/d.total)*100) : 0;
    const pend = d.total - d.contados;
    const color = pct >= 80 ? 'green' : pct >= 40 ? 'orange' : 'red';
    return `<div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
        <span style="font-size:.78rem;font-weight:600">${escHTML(local)}</span>
        <span style="font-size:.7rem;color:var(--muted);font-family:var(--mono)">${d.contados}/${d.total} · ${pct}%</span>
      </div>
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:2px">
        <div class="mini-prog"><div class="mini-prog-fill ${color}" style="width:${pct}%"></div></div>
      </div>
      <div style="font-size:.65rem;color:var(--muted)">${pend > 0 ? `${pend} pendentes` : '✅ Concluído'}</div>
    </div>`;
  }).join('');
}


function _dashSafe(str) {
  return escHTML(String(str ?? ''));
}

function _dashBuildBreakdown(endsBase, invsConsiderados, keyFn) {
  const invs = invsConsiderados || getInventariosAtivos();
  const contadosSet = new Set();
  const vaziosConfSet = new Set();
  invs.forEach(inv => {
    _dashContagens(inv.id).forEach(c => {
      if (_isVazio(c) && c.status !== 'ESTORNADA') vaziosConfSet.add(c.endereco);
      else contadosSet.add(c.endereco);
    });
  });
  const groups = {};
  endsBase.forEach(e => {
    const key = keyFn(e) || 'SEM DADO';
    if (!groups[key]) groups[key] = { total: 0, contados: 0 };
    groups[key].total++;
    if (contadosSet.has(e.endereco) || vaziosConfSet.has(e.endereco)) groups[key].contados++;
  });
  return Object.entries(groups).map(([label, d]) => {
    const pendentes = Math.max(0, d.total - d.contados);
    const pct = d.total > 0 ? Math.round((d.contados / d.total) * 100) : 0;
    return { label, total: d.total, contados: d.contados, pendentes, pct };
  });
}

function _dashTopOperadores(contagensConsideradas) {
  const mapa = {};
  (contagensConsideradas || []).forEach(c => {
    const op = c.operador || c.usuario || 'SEM OPERADOR';
    if (!mapa[op]) mapa[op] = { operador: op, total: 0, enderecos: new Set(), divergencias: 0 };
    mapa[op].total++;
    if (c.endereco) mapa[op].enderecos.add(c.endereco);
    if (c.status === 'CONFLITO' || c.em_conflito) mapa[op].divergencias++;
  });
  return Object.values(mapa)
    .map(x => ({ ...x, enderecos: x.enderecos.size }))
    .sort((a,b) => b.total - a.total)
    .slice(0,8);
}

function _dashHourlySeries(contagensConsideradas) {
  const buckets = Array.from({ length: 24 }, (_, h) => ({ hora: h, total: 0 }));
  (contagensConsideradas || []).forEach(c => {
    const raw = c.criado_em || c.created_at || c.data_hora || c.ts || c.updated_at;
    if (!raw) return;
    let d = null;
    if (raw && typeof raw.toDate === 'function') d = raw.toDate();
    else d = new Date(raw);
    if (!(d instanceof Date) || isNaN(d)) return;
    buckets[d.getHours()].total++;
  });
  return buckets;
}

function _dashIsRecontagem(registro) {
  const tipo = String(registro?.tipo_contagem || registro?.tipo || registro?.origem || '').toUpperCase();
  return tipo.includes('RECONTAGEM') ||
    Number(registro?.numero_recontagem || registro?.rodada || 0) > 0 ||
    !!registro?.recontagem_id ||
    (!!registro?.divergencia_id && (
      registro?.qtd_recontagem != null ||
      registro?.recontagem_concluida_em ||
      String(registro?.status_recontagem || '').toLowerCase() === 'concluida'
    ));
}

function _dashDataRegistro(registro) {
  const raw = registro?.recontagem_concluida_em || registro?.concluida_em ||
    registro?.criado_em || registro?.created_at || registro?.data_hora ||
    registro?.dataHora || registro?.ts || registro?.updated_at;
  if (!raw) return '';
  if (typeof raw.toDate === 'function') {
    const d = raw.toDate();
    return isNaN(d) ? '' : d.toISOString();
  }
  const d = new Date(raw);
  return isNaN(d) ? '' : d.toISOString();
}

function _dashRecontagensConsideradas(dc, ignorarFiltroHora) {
  const filtros = dc?.filtros || {};
  const enderecos = state().enderecosLista || [];
  const aceitoNoFiltro = r => {
    if (r?._excluida) return false;
    if (filtros.inventarioId && String(r?.inventario_id || '') !== String(filtros.inventarioId)) return false;
    const end = enderecos.find(e => String(e.endereco || '') === String(r?.endereco || '')) || {};
    const rua = end.rua || extrairRua(r?.endereco) || 'SEM RUA';
    const local = end.setor || r?.setor || r?.local || 'SEM LOCAL';
    if (filtros.rua && String(rua) !== String(filtros.rua)) return false;
    if (filtros.local && String(local) !== String(filtros.local)) return false;
    if (!ignorarFiltroHora && !_dashRegistroNaHora(r)) return false;
    return true;
  };
  const candidatos = [
    ...(state().contagens || []).filter(_dashIsRecontagem),
    ...(state().recontagens || []).filter(r =>
      r?.qtd_recontagem != null || r?.qtd_segunda != null || r?.qtd_terceira != null ||
      r?.recontagem_concluida_em || String(r?.status || '').toUpperCase() === 'CONCLUIDA' ||
      String(r?.status_recontagem || '').toLowerCase() === 'concluida'
    )
  ].filter(aceitoNoFiltro);
  const unicos = new Map();
  candidatos.forEach((r, idx) => {
    const chave = String(r.id || [
      r.inventario_id || '', r.endereco || '', r.divergencia_id || '',
      r.numero_recontagem || r.rodada || '', _dashDataRegistro(r),
      r.operador_recontagem || r.operador || '', r.qtd_recontagem ?? r.quantidade ?? ''
    ].join('|') || `rec-${idx}`);
    const anterior = unicos.get(chave);
    unicos.set(chave, anterior ? { ...anterior, ...r } : r);
  });
  return [...unicos.values()];
}

function _dashAgruparRecontagens(recontagens, keyFn, limite=8) {
  const mapa = new Map();
  (recontagens || []).forEach(r => {
    const chave = String(keyFn(r) || 'SEM DADO').trim() || 'SEM DADO';
    mapa.set(chave, (mapa.get(chave) || 0) + 1);
  });
  return [...mapa.entries()]
    .map(([label, value]) => ({ label, value }))
    .sort((a,b) => b.value - a.value || a.label.localeCompare(b.label, 'pt-BR', { numeric:true }))
    .slice(0, limite);
}

function _dashNomeProdutoRecontagem(registro) {
  const r = registro || {};
  const nomes = [
    r.nome_produto, r.nomeProduto, r.produto_nome, r.produtoNome,
    r.descricao_produto, r.descricaoProduto, r.descricao,
    r.produto_recontagem_nome, r.produto_segunda_nome, r.produto_terceira_nome
  ].map(v => String(v || '').trim()).filter(Boolean);
  if (nomes.length) return nomes[0];

  const valores = [
    r.produto_recontagem, r.produto_terceira, r.produto_segunda, r.produto,
    r.codigo_produto, r.codigoProduto, r.codigo_interno, r.codigoInterno,
    r.gtin, r.ean, r.dun, r.sku
  ].map(v => String(v || '').trim()).filter(Boolean);

  for (const valor of valores) {
    const achado = window.DTProdutos?.buscarSync?.(valor);
    if (achado?.encontrado && achado.nomeProduto) return achado.nomeProduto;
  }

  const textoJaDescritivo = valores.find(v => /[A-Za-zÀ-ÿ]/.test(v) && !/^\d+$/.test(v));
  return textoJaDescritivo || 'PRODUTO SEM NOME CADASTRADO';
}

function _dashMiniBars(items, opts={}) {
  const clickable = !!opts.clickable;
  if (!items.length) return `<div class="empty" style="padding:20px"><div class="empty-icon">📊</div><div class="empty-title">Sem dados para o gráfico</div></div>`;
  const max = Math.max(...items.map(i => i.value), 1);
  return items.map(item => {
    const pct = Math.max(4, Math.round((item.value / max) * 100));
    const buttonOpen = clickable ? `<button class="btn btn-ghost btn-sm" style="width:100%;justify-content:flex-start;padding:10px 12px;border-radius:12px" onclick="${item.onclick}">` : `<div style="padding:10px 12px;border:1px solid var(--border);border-radius:12px;background:var(--surface-2)">`;
    const buttonClose = clickable ? `</button>` : `</div>`;
    return `${buttonOpen}
      <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:8px">
        <span style="font-size:.76rem;font-weight:700;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${_dashSafe(item.label)}</span>
        <span style="font-size:.68rem;color:var(--muted);font-family:var(--mono)">${item.valueLabel || item.value}</span>
      </div>
      <div style="height:10px;background:var(--border);border-radius:999px;overflow:hidden">
        <div style="height:100%;width:${pct}%;background:${item.color || 'linear-gradient(90deg,var(--orange),var(--orange-h))'};border-radius:999px"></div>
      </div>
      ${item.sub ? `<div style="margin-top:6px;font-size:.67rem;color:var(--muted)">${_dashSafe(item.sub)}</div>` : ''}
    ${buttonClose}`;
  }).join('');
}

function _dashInventoryColumns(items, onclickFn) {
  if (!items.length) return `<div class="empty" style="padding:24px 16px;min-height:150px;display:flex;flex-direction:column;justify-content:center"><div class="empty-icon">📊</div><div class="empty-title">Sem dados para o filtro selecionado</div><div class="empty-sub">Altere os filtros ou clique em Atualizar.</div></div>`;
  const max = Math.max(...items.map(i => Math.max(i.contados, i.total)), 1);
  const teto=Math.max(1,Math.ceil(max/4)*4);
  const linhas=[0,1,2,3,4].map(n=>Math.round(teto*n/4));
  return `<div class="dash-ranking-body"><div class="dash-column-legend"><span><i style="background:#2563eb"></i>Contados</span><span><i style="background:#ef4444"></i>Totais</span></div><div class="dash-column-scroll"><div class="dash-column-chart" style="--chart-count:${items.length};min-width:max(520px,calc(${items.length} * 82px))"><div class="dash-y-axis">${linhas.map((v,i)=>`<span style="bottom:${i*25}%">${v}</span>`).join('')}</div><div class="dash-grid-lines">${linhas.map((_,i)=>`<i style="bottom:${i*25}%"></i>`).join('')}</div><div class="dash-column-groups">${items.map(item => {
    const hc=item.contados?Math.max(4,Math.round(item.contados/teto*100)):0;
    const ht=item.total?Math.max(4,Math.round(item.total/teto*100)):0;
    const arg=String(item.filterValue??item.label).replace(/\\/g,'\\\\').replace(/'/g,"\\'");
    return `<button type="button" class="dash-column-group" onclick="${onclickFn}('${arg}')" title="${_dashSafe(item.label)}: ${item.contados} contados de ${item.total} totais">
      <span class="dash-columns"><i class="dash-column auditados" style="height:${hc}%"><b>${item.contados}</b></i><i class="dash-column divergencias" style="height:${ht}%"><b>${item.total}</b></i></span>
      <span class="dash-column-label">${_dashSafe(item.label)}<small style="display:block;margin-top:3px;color:var(--muted)">${item.pct}% concluído</small></span>
    </button>`;
  }).join('')}</div></div></div></div>`;
}

function _dashNomeProdutoDivergencia(d) {
  const nome = d.produto_descricao || d.produtoDescricao || d.descricao_produto || d.descricao || d.produto_nome || d.produtoNome || d.produto || '';
  const codigo = d.gtin || d.dun || d.codigo_barras || d.codigoBarras || d.produto_gtin || d.produtoGtin || '';
  if (nome && codigo && !String(nome).includes(String(codigo))) return `${nome} · ${codigo}`;
  return String(nome || codigo || 'Produto não identificado');
}
function _dashDivergenciasProduto(dc) {
  const invId = dc?.filtros?.inventarioId || '';
  const ruaFiltro = dc?.filtros?.rua || '';
  const localFiltro = dc?.filtros?.local || '';
  const ends = state().enderecosLista || [];
  const endMap = new Map(ends.map(e => [String(e.endereco || ''), e]));
  const lista = (state().divergencias || []).filter(d => {
    const status = String(d.status || '').toUpperCase();
    if (['CANCELADA','EXCLUIDA','ESTORNADA'].includes(status)) return false;
    if (invId && String(d.inventario_id || d.inventarioId || '') !== String(invId)) return false;
    if (ruaFiltro || localFiltro) {
      const base = endMap.get(String(d.endereco || '')) || {};
      const rua = base.rua || extrairRua(d.endereco) || 'SEM RUA';
      const local = base.setor || base.local || 'SEM LOCAL';
      if (ruaFiltro && String(rua) !== String(ruaFiltro)) return false;
      if (localFiltro && String(local) !== String(localFiltro)) return false;
    }
    if (!_dashRegistroNaHora(d)) return false;
    return true;
  });
  const agrupado = {};
  lista.forEach(d => {
    const nome = _dashNomeProdutoDivergencia(d);
    agrupado[nome] = (agrupado[nome] || 0) + 1;
  });
  return Object.entries(agrupado).sort((a,b) => b[1] - a[1] || a[0].localeCompare(b[0], 'pt-BR')).slice(0, 12);
}
function _dashProdutoDivergenciaBars(items) {
  if (!items.length) return '<div class="empty" style="padding:24px"><div class="empty-icon">📦</div><div class="empty-title">Nenhuma divergência por produto</div><div class="empty-sub">Os produtos aparecerão aqui quando houver conflitos.</div></div>';
  const max = Math.max(...items.map(x => x[1]), 1);
  return items.map(([nome,total]) => `<button class="btn btn-ghost btn-sm" onclick="dashApplyProdutoDivergencia(${JSON.stringify(nome).replace(/"/g,'&quot;')})" style="width:100%;display:block;text-align:left;padding:10px 12px;margin-bottom:7px"><div style="display:flex;justify-content:space-between;gap:10px"><b title="${_dashSafe(nome)}" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${_dashSafe(nome)}</b><span class="mono">${total}</span></div><div style="height:9px;background:var(--border);border-radius:99px;margin-top:7px;overflow:hidden"><div style="height:100%;width:${Math.max(4,Math.round(total/max*100))}%;background:linear-gradient(90deg,var(--danger),var(--orange));border-radius:99px"></div></div></button>`).join('');
}
function _renderDashboardCharts() {
  const wrap = document.getElementById('dash-charts-wrap');
  if (!wrap) return;
  const dc = _dashCache;
  if (!dc || !dc.endsBase || !dc.invsConsiderados) {
    wrap.innerHTML = '';
    return;
  }

  const ruas = _dashBuildBreakdown(dc.endsBase, dc.invsConsiderados, e => e.rua || extrairRua(e.endereco) || 'SEM RUA')
    .sort((a,b) => b.pendentes - a.pendentes || a.pct - b.pct)
    .slice(0,6);
  const locais = _dashBuildBreakdown(dc.endsBase, dc.invsConsiderados, e => _dashLocalName(e))
    .sort((a,b) => b.pendentes - a.pendentes || a.pct - b.pct)
    .slice(0,6);
  const contagensNormais = dc.contagensConsideradas.filter(c => !_dashIsRecontagem(c));
  const recontagens = _dashRecontagensConsideradas(dc);
  const operadores = _dashTopOperadores(contagensNormais);
  // O gráfico "Produção por hora" precisa sempre das 24 horas pra continuar
  // clicável — se usasse a lista já filtrada por hora, só a barra da hora
  // selecionada apareceria depois do primeiro clique.
  const contagensNormaisSemHora = (dc.contagensConsideradasSemHora || dc.contagensConsideradas).filter(c => !_dashIsRecontagem(c));
  const recontagensSemHora = _dashRecontagensConsideradas(dc, true);

  // Contagem × recontagem por operador, pro card "Top Operadores" do v254
  // mostrar as duas colunas separadas em vez de só um total combinado.
  const recontagensPorOperador = {};
  recontagens.forEach(r => {
    const nome = r.operador_recontagem || r.operador_nome || r.operador || r.usuario || 'SEM OPERADOR';
    recontagensPorOperador[nome] = (recontagensPorOperador[nome] || 0) + 1;
  });
  const operadoresDetalhados = operadores.map(o => ({
    operador: o.operador,
    contagens: o.total,
    recontagens: recontagensPorOperador[o.operador] || 0
  }));
  Object.keys(recontagensPorOperador).forEach(nome => {
    if (!operadoresDetalhados.some(o => o.operador === nome)) {
      operadoresDetalhados.push({ operador: nome, contagens: 0, recontagens: recontagensPorOperador[nome] });
    }
  });
  operadoresDetalhados.sort((a,b) => (b.contagens + b.recontagens) - (a.contagens + a.recontagens));

  // Exposto para os cards "Top Operadores" e "Produção por hora" do dashboard
  // v254 (49-quatro-telas-v254.js) — que hoje leem o DOM antigo/estático —
  // igual o modo auditoria já expõe em DTDashboardAuditoriaSnapshot.
  window.DTDashboardInventarioSnapshot = { operadores: operadoresDetalhados };
  const serieHoras = _dashHourlySeries(contagensNormaisSemHora);
  const serieHorasRecontagem = _dashHourlySeries(recontagensSemHora.map(r => ({
    ...r, criado_em: _dashDataRegistro(r)
  })));
  const serieHorasTotal = serieHoras.map((b, idx) => ({
    hora: b.hora,
    total: b.total + (serieHorasRecontagem[idx]?.total || 0)
  }));
  window.DTDashboardHoraSnapshot = { serieHoras, serieHorasRecontagem, serieHorasTotal, filtroHora: _dashFiltroHora };
  const totalHoraMax = Math.max(...serieHoras.map(x => x.total), 1);
  const totalHoraRecMax = Math.max(...serieHorasRecontagem.map(x => x.total), 1);
  const totalHoraGeralMax = Math.max(...serieHorasTotal.map(x => x.total), 1);
  const enderecos = state().enderecosLista || [];
  const recUsuarios = _dashAgruparRecontagens(recontagens, r =>
    r.operador_recontagem || r.operador_nome || r.operador || r.usuario || 'SEM OPERADOR'
  );
  const recRuas = _dashAgruparRecontagens(recontagens, r => {
    const end = enderecos.find(e => String(e.endereco || '') === String(r.endereco || '')) || {};
    return end.rua || extrairRua(r.endereco) || 'SEM RUA';
  });
  const recProdutos = _dashAgruparRecontagens(recontagens, _dashNomeProdutoRecontagem);
  const totalUsuarios = _dashAgruparRecontagens([
    ...contagensNormais.map(c => ({ ...c, _atividade:'Contagem' })),
    ...recontagens.map(r => ({ ...r, _atividade:'Recontagem' }))
  ], r => r.operador_recontagem || r.operador_nome || r.operador || r.usuario || 'SEM OPERADOR');

  const pct = Math.max(0, Math.min(100, dc.pctGeral || 0));
  const divergenciasProdutos = _dashDivergenciasProduto(dc);
  const divergenciasProdutosHtml = _dashProdutoDivergenciaBars(divergenciasProdutos);
  const pendPct = 100 - pct;

  const ruasHtml = _dashInventoryColumns(ruas.map(r => ({...r,filterValue:r.label,label:`Rua ${r.label}`})), 'dashApplyRuaFilter');
  const locaisHtml = _dashInventoryColumns(locais, 'dashApplyLocalFilter');

  const operadoresHtml = operadores.length ? operadores.map((op, idx) => `
    <button class="btn btn-ghost btn-sm" style="width:100%;justify-content:flex-start;padding:10px 12px;border-radius:12px" onclick="dashApplyOperadorFilter(${JSON.stringify(op.operador).replace(/"/g,'&quot;')})">
      <div style="display:flex;align-items:center;gap:10px;width:100%">
        <div style="width:28px;height:28px;border-radius:10px;background:${idx===0?'var(--orange-soft)':'var(--surface-3)'};display:flex;align-items:center;justify-content:center;font-family:var(--mono);font-size:.72rem;font-weight:700;color:${idx===0?'var(--orange)':'var(--muted)'}">${idx+1}</div>
        <div style="flex:1;min-width:0;text-align:left">
          <div style="font-size:.78rem;font-weight:700;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${_dashSafe(op.operador)}</div>
          <div style="font-size:.67rem;color:var(--muted)">${op.enderecos} end. únicos · ${op.divergencias} conflito(s)</div>
        </div>
        <div style="font-family:var(--mono);font-size:.82rem;font-weight:700;color:var(--green-mid)">${op.total}</div>
      </div>
    </button>
  `).join('') : `<div class="empty" style="padding:20px"><div class="empty-icon">👥</div><div class="empty-title">Sem operadores no filtro</div></div>`;

  const hourBars = serieHoras.map(b => {
    const h = Math.max(8, Math.round((b.total / totalHoraMax) * 100));
    const active = b.total > 0;
    return `<div title="${String(b.hora).padStart(2,'0')}:00 · ${b.total} contagem(ns)" style="display:flex;flex-direction:column;align-items:center;gap:6px;flex:1;min-width:0">
      <div style="height:14px;font-family:var(--mono);font-size:.65rem;font-weight:800;color:${active ? 'var(--orange)' : 'transparent'};line-height:14px">${active ? b.total.toLocaleString('pt-BR') : '0'}</div>
      <div style="height:110px;width:100%;display:flex;align-items:flex-end;justify-content:center">
        <div style="width:100%;max-width:22px;height:${active ? h : 8}%;border-radius:8px 8px 4px 4px;background:${active ? 'linear-gradient(180deg,var(--orange-h),var(--orange))' : 'var(--border)'};transition:height .25s"></div>
      </div>
      <div style="font-size:.61rem;font-family:var(--mono);color:${active ? 'var(--text-2)' : 'var(--muted-2)'}">${String(b.hora).padStart(2,'0')}</div>
    </div>`;
  }).join('');
  const recountHourBars = serieHorasRecontagem.map(b => {
    const h = Math.max(8, Math.round((b.total / totalHoraRecMax) * 100));
    const active = b.total > 0;
    return `<div title="${String(b.hora).padStart(2,'0')}:00 · ${b.total} recontagem(ns)" style="display:flex;flex-direction:column;align-items:center;gap:6px;flex:1;min-width:0">
      <div style="height:14px;font-family:var(--mono);font-size:.65rem;font-weight:800;color:${active ? '#7c3aed' : 'transparent'};line-height:14px">${active ? b.total.toLocaleString('pt-BR') : '0'}</div>
      <div style="height:110px;width:100%;display:flex;align-items:flex-end;justify-content:center">
        <div style="width:100%;max-width:22px;height:${active ? h : 8}%;border-radius:8px 8px 4px 4px;background:${active ? 'linear-gradient(180deg,#a78bfa,#7c3aed)' : 'var(--border)'};transition:height .25s"></div>
      </div>
      <div style="font-size:.61rem;font-family:var(--mono);color:${active ? 'var(--text-2)' : 'var(--muted-2)'}">${String(b.hora).padStart(2,'0')}</div>
    </div>`;
  }).join('');
  const totalHourBars = serieHorasTotal.map(b => {
    const h = Math.max(8, Math.round((b.total / totalHoraGeralMax) * 100));
    const active = b.total > 0;
    return `<div title="${String(b.hora).padStart(2,'0')}:00 · ${b.total} atividade(s) no total" style="display:flex;flex-direction:column;align-items:center;gap:6px;flex:1;min-width:0">
      <div style="height:14px;font-family:var(--mono);font-size:.65rem;font-weight:800;color:${active ? 'var(--green-mid)' : 'transparent'};line-height:14px">${active ? b.total.toLocaleString('pt-BR') : '0'}</div>
      <div style="height:110px;width:100%;display:flex;align-items:flex-end;justify-content:center">
        <div style="width:100%;max-width:22px;height:${active ? h : 8}%;border-radius:8px 8px 4px 4px;background:${active ? 'linear-gradient(180deg,var(--green-light),var(--green-mid))' : 'var(--border)'};transition:height .25s"></div>
      </div>
      <div style="font-size:.61rem;font-family:var(--mono);color:${active ? 'var(--text-2)' : 'var(--muted-2)'}">${String(b.hora).padStart(2,'0')}</div>
    </div>`;
  }).join('');
  const recUsuariosHtml = _dashMiniBars(recUsuarios.map(i => ({
    ...i, color:'linear-gradient(90deg,#7c3aed,#a78bfa)', sub:`${i.value} recontagem(ns)`
  })));
  const recRuasHtml = _dashMiniBars(recRuas.map(i => ({
    ...i, label:`Rua ${i.label}`, color:'linear-gradient(90deg,#dc2626,#fb7185)',
    sub:`${i.value} recontagem(ns) gerada(s)`
  })));
  const recProdutosHtml = _dashMiniBars(recProdutos.map(i => ({
    ...i, color:'linear-gradient(90deg,#d97706,#fbbf24)',
    sub:`${i.value} recontagem(ns) gerada(s)`
  })));
  const totalUsuariosHtml = _dashMiniBars(totalUsuarios.map(i => ({
    ...i, color:'linear-gradient(90deg,var(--green-mid),var(--green-light))',
    sub:`${i.value} atividade(s): contagens + recontagens`
  })));

  wrap.innerHTML = `
    <div style="display:grid;grid-template-columns:1.1fr 1fr 1fr;gap:16px;margin-bottom:4px">
      <div class="tc" style="overflow:hidden">
        <div class="tc-header"><div><div class="tc-title">📈 Conclusão do filtro</div><div class="sec-sub">Clique nas barras ao lado para refinar a análise</div></div></div>
        <div style="padding:18px 20px;display:flex;gap:20px;align-items:center;flex-wrap:wrap">
          <div style="width:180px;height:180px;border-radius:50%;background:conic-gradient(var(--green-light) 0 ${pct}%, var(--border) ${pct}% 100%);display:flex;align-items:center;justify-content:center;position:relative;flex-shrink:0;margin:auto">
            <div style="width:118px;height:118px;border-radius:50%;background:var(--surface);display:flex;align-items:center;justify-content:center;flex-direction:column;box-shadow:inset 0 0 0 1px var(--border)">
              <div style="font-family:var(--mono);font-size:1.8rem;font-weight:800;color:var(--green-mid)">${pct}%</div>
              <div style="font-size:.64rem;color:var(--muted);text-transform:uppercase;letter-spacing:.08em">concluído</div>
            </div>
          </div>
          <div style="flex:1;min-width:220px;display:grid;grid-template-columns:1fr 1fr;gap:10px">
            <div style="padding:12px 14px;border-radius:14px;background:var(--surface-2);border:1px solid var(--border)"><div style="font-size:.64rem;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)">Conferidos</div><div style="font-family:var(--mono);font-size:1.2rem;font-weight:800;color:var(--green-mid)">${dc.endContadosTotal.toLocaleString('pt-BR')}</div></div>
            <div style="padding:12px 14px;border-radius:14px;background:var(--surface-2);border:1px solid var(--border)"><div style="font-size:.64rem;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)">Pendentes</div><div style="font-family:var(--mono);font-size:1.2rem;font-weight:800;color:var(--danger)">${dc.pendentesTotal.toLocaleString('pt-BR')}</div></div>
            <div style="padding:12px 14px;border-radius:14px;background:var(--surface-2);border:1px solid var(--border)"><div style="font-size:.64rem;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)">Conflitos</div><div style="font-family:var(--mono);font-size:1.2rem;font-weight:800;color:var(--warn)">${dc.divAbertos.toLocaleString('pt-BR')}</div></div>
            <div style="padding:12px 14px;border-radius:14px;background:var(--surface-2);border:1px solid var(--border)"><div style="font-size:.64rem;text-transform:uppercase;letter-spacing:.08em;color:var(--muted)">Recontagem</div><div style="font-family:var(--mono);font-size:1.2rem;font-weight:800;color:var(--orange)">${dc.recPend.toLocaleString('pt-BR')}</div></div>
          </div>
        </div>
      </div>
      <div class="tc">
        <div class="tc-header"><div><div class="tc-title">🛣️ Ruas com mais pendências</div><div class="sec-sub">Clique para filtrar a rua</div></div></div>
        <div>${ruasHtml}</div>
      </div>
      <div class="tc">
        <div class="tc-header"><div><div class="tc-title">🏭 Locais com mais pendências</div><div class="sec-sub">Clique para filtrar o local</div></div></div>
        <div>${locaisHtml}</div>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1.2fr .8fr;gap:16px;margin-bottom:16px">
      <div class="tc">
        <div class="tc-header"><div><div class="tc-title">⏱️ Contagens por hora</div><div class="sec-sub">Distribuição operacional do filtro atual</div></div></div>
        <div style="padding:18px 16px 12px">
          <div style="display:flex;gap:8px;align-items:flex-end">${hourBars}</div>
        </div>
      </div>
      <div class="tc">
        <div class="tc-header"><div><div class="tc-title">👥 Ranking de operadores</div><div class="sec-sub">Clique para abrir as contagens já filtradas por operador</div></div></div>
        <div style="padding:14px;display:flex;flex-direction:column;gap:8px">${operadoresHtml}</div>
      </div>
    </div>
    <div class="tc" style="margin-bottom:16px">
      <div class="tc-header"><div><div class="tc-title">📦 Produtos com mais divergências</div><div class="sec-sub">Ranking de produtos em conflito no inventário e filtros selecionados</div></div></div>
      <div style="padding:12px">${divergenciasProdutosHtml}</div>
    </div>
    <div style="margin:4px 0 12px">
      <div style="font-size:1rem;font-weight:800;color:var(--text)">🔄 Análise de recontagens</div>
      <div class="sec-sub">Somente rodadas de recontagem executadas no filtro atual; não são somadas às contagens normais.</div>
    </div>
    <div style="display:grid;grid-template-columns:1.2fr .8fr;gap:16px;margin-bottom:16px">
      <div class="tc">
        <div class="tc-header"><div><div class="tc-title">⏱️ Recontagens por hora</div><div class="sec-sub">${recontagens.length.toLocaleString('pt-BR')} recontagem(ns) executada(s)</div></div></div>
        <div style="padding:18px 16px 12px"><div style="display:flex;gap:8px;align-items:flex-end">${recountHourBars}</div></div>
      </div>
      <div class="tc">
        <div class="tc-header"><div><div class="tc-title">👥 Usuários com mais recontagens</div><div class="sec-sub">Ranking de rodadas executadas</div></div></div>
        <div style="padding:12px">${recUsuariosHtml}</div>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1.2fr .8fr;gap:16px;margin-bottom:16px">
      <div class="tc">
        <div class="tc-header"><div><div class="tc-title">📊 Produção total por hora</div><div class="sec-sub">Contagens + recontagens executadas no filtro atual</div></div></div>
        <div style="padding:18px 16px 12px"><div style="display:flex;gap:8px;align-items:flex-end">${totalHourBars}</div></div>
      </div>
      <div class="tc">
        <div class="tc-header"><div><div class="tc-title">🏆 Ranking total de usuários</div><div class="sec-sub">Soma de contagens e recontagens por pessoa</div></div></div>
        <div style="padding:12px">${totalUsuariosHtml}</div>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
      <div class="tc">
        <div class="tc-header"><div><div class="tc-title">🛣️ Ruas que mais geraram recontagem</div><div class="sec-sub">Endereços divergentes agrupados por rua</div></div></div>
        <div style="padding:12px">${recRuasHtml}</div>
      </div>
      <div class="tc">
        <div class="tc-header"><div><div class="tc-title">📦 Produtos que mais geraram recontagem</div><div class="sec-sub">Produtos vinculados às rodadas realizadas</div></div></div>
        <div style="padding:12px">${recProdutosHtml}</div>
      </div>
    </div>`;
}

function dashApplyRuaFilter(rua) {
  const el = document.getElementById('dash-frua');
  if (!el) return;
  el.value = String(el.value || '') === String(rua || '') ? '' : (rua || '');
  renderDashboard();
}

function dashApplyLocalFilter(local) {
  const el = document.getElementById('dash-flocal');
  if (!el) return;
  el.value = String(el.value || '') === String(local || '') ? '' : (local || '');
  renderDashboard();
}

function dashApplyOperadorFilter(operador) {
  goPage('contagens', document.getElementById('nav-contagens'));
  const campo = document.getElementById('cont-busca');
  const selOp = document.getElementById('cont-foperador');
  if (selOp) selOp.value = operador || '';
  if (campo) {
    campo.value = operador || '';
    campo.dispatchEvent(new Event('input', { bubbles: true }));
  } else if (typeof renderContagens === 'function') {
    renderContagens();
  }
}

// ───────────────────────────────────────────────────────────────────

function dashApplyProdutoDivergencia(produto) {
  goPage('divergencias', document.getElementById('nav-divergencias'));
  const busca = document.getElementById('div-busca') || document.getElementById('diverg-busca');
  if (busca) {
    busca.value = produto || '';
    busca.dispatchEvent(new Event('input', { bubbles:true }));
  } else if (typeof renderDivergencias === 'function') {
    renderDivergencias();
  }
}

// ══════════════════════════════════════════════════════════════════════
// DASHBOARD DUPLO — INVENTÁRIO / AUDITORIA (v36)
// ══════════════════════════════════════════════════════════════════════
let _dashAudMetas = [];
let _dashAudItens = [];
let _dashAudCarregando = false;
let _dashAudLoja = '';
const _dashAudCache = new Map();
const _DASH_AUD_TTL = 60000;
let _dashAudFiltroColuna = '';
let _dashAudFiltroOperador = '';

function _dashModoAtual(){ return document.getElementById('dash-mode')?.value || 'inventario'; }
function _dashEnderecoPartes(endereco){
  const p=window.DTEnderecos?.partes(endereco)||{};
  return {loja:p.loja||'',local:p.local||'',area:p.area||'',rua:p.rua||'SEM RUA',coluna:p.coluna||'SEM COLUNA',nivel:p.nivel||'SEM NÍVEL',sequencia:p.sequencia||''};
}
function _dashSetKpi(idx,valor,rotulo,icone){
  const ids=['kd-inventarios','kd-enderecos','kd-end-contados','kd-pendencias','kd-contagens','kd-diverg','kd-recount','kd-pct-geral','kd-operadores'];
  const el=document.getElementById(ids[idx]); if(!el)return;
  el.textContent=valor;
  const card=el.closest('.kpi');
  const lbl=card?.querySelector('.kpi-lbl'); const ico=card?.querySelector('.kpi-icon');
  if(lbl)lbl.textContent=rotulo; if(ico)ico.textContent=icone;
}
function _dashAtualizarRotulosModo(modo){
  const auditoria=modo==='auditoria';
  const primeiro=document.getElementById('kd-inventarios')?.closest('.kpi');
  const lbl=primeiro?.querySelector('.kpi-lbl');
  const ico=primeiro?.querySelector('.kpi-icon');
  if(lbl) lbl.textContent=auditoria?'Auditorias em aberto':'Inventários em aberto';
  if(ico) ico.textContent=auditoria?'🔎':'📦';
  document.querySelectorAll('[data-dashboard-operacoes-label]').forEach(el=>{
    el.textContent=auditoria?'Auditorias em aberto':'Inventários em aberto';
  });
}
function alterarModoDashboard(modo){
  document.querySelectorAll('.dash-inv-filter').forEach(e=>e.style.display=modo==='inventario'?'':'none');
  document.querySelectorAll('.dash-aud-filter').forEach(e=>e.style.display=modo==='auditoria'?'':'none');
  const novo=document.querySelector('#page-dashboard button[onclick="abrirNovoInventario()"]');
  if(novo) novo.style.display=modo==='inventario'?'':'none';
  _dashAtualizarRotulosModo(modo);
  renderDashboard();
}
function renderDashboard(){
  // A auditoria só consulta o Firebase quando o analista clica em Atualizar.
  // Navegação, filtros e troca de modo apenas redesenham o instantâneo carregado.
  if(_dashModoAtual()==='auditoria'){ return renderDashboardAuditoria(); }
  document.getElementById('dash-alert-wrap').innerHTML='';
  const action=document.getElementById('dash-recentes-action'); if(action)action.style.display='';
  const title=document.getElementById('dash-recentes-title'); if(title)title.textContent='📦 Inventários Recentes';
  return renderDashboardInventario();
}
window.atualizarDashboardAuditoriaManual=function(){ return carregarDashboardAuditoria(true); };
function limparFiltrosDash(){
  if(_dashModoAtual()==='auditoria'){
    ['dash-faud','dash-fastatus','dash-farua','dash-fanivel','dash-faproduto'].forEach(id=>{const e=document.getElementById(id);if(e)e.value='';});
    return carregarDashboardAuditoria(false);
  }
  ['dash-finv','dash-frua','dash-flocal'].forEach(id=>{const e=document.getElementById(id);if(e)e.value='';});
  _dashFiltroHora = null;
  renderDashboardInventario();
}
async function carregarDashboardAuditoria(forcar){
  const lojaAtual=window.getDTLojaAtiva?.()||'';
  if(_dashAudCarregando)return;
  if(!forcar && _dashAudLoja===lojaAtual && _dashAudMetas.length){ renderDashboardAuditoria(); return; }
  _dashAudCarregando=true;
  const wrap=document.getElementById('dash-charts-wrap'); if(wrap)wrap.innerHTML='<div class="tc"><div class="empty"><div class="empty-icon">⏳</div><div class="empty-title">Carregando auditorias...</div></div></div>';
  try{
    const raw=window.getDTRawFirestore?.() || window.FS_AN || window.getDTFirestore?.();
    const metas=[],vistos=new Set();
    async function add(ref,origem){try{const snap=await ref.get();snap.docs.forEach(d=>{if(vistos.has(d.id))return;vistos.add(d.id);metas.push({id:d.id,...d.data(),_origem:origem,_ref:d.ref});});}catch(e){console.warn('[Dashboard Auditoria] '+origem,e);}}
    if(window.getDTRawFirestore){
      // Use o índice público para incluir auditorias cujo documento pai não
      // existe, mas que possuem base_chunks/resultados. Essas auditorias não
      // aparecem em consultas normais de dt_auditorias.
      try{
        const indice=await raw.collection('dt_auditorias_coletor').get();
        indice.docs.forEach(d=>{
          if(vistos.has(d.id))return;
          vistos.add(d.id);
          const x={id:d.id,...d.data(),_origem:'raiz',_ref:raw.collection('dt_auditorias').doc(d.id)};
          metas.push(x);
        });
      }catch(e){console.warn('[Dashboard Auditoria] índice público',e);}
      if(lojaAtual)await add(raw.collection('lojas').doc(lojaAtual).collection('dt_auditorias'),'loja:'+lojaAtual);
      const acesso=window.DT_USUARIO_ACESSO_ATUAL||{};
      const acessoGlobal=acesso.acesso_todas_lojas===true || acesso.perfil==='administrador' || acesso.admin_mestre===true || acesso.administrador_mestre===true;
      if(acessoGlobal){try{const ls=await raw.collection('lojas').get();await Promise.all(ls.docs.filter(ld=>ld.id!==lojaAtual).map(ld=>add(raw.collection('lojas').doc(ld.id).collection('dt_auditorias'),'loja:'+ld.id)));}catch(e){ console.warn('[Dashboard Auditoria] lojas', e); }}
      if(acessoGlobal) await add(raw.collection('dt_auditorias'),'raiz');
    }else await add(raw.collection('dt_auditorias'),'loja');
    _dashAudMetas=metas;
    const escolhido=document.getElementById('dash-faud')?.value||'';
    const selecionadas=escolhido?_dashAudMetas.filter(m=>m.id===escolhido):_dashAudMetas;
    const listas=await Promise.all(selecionadas.map(async m=>{
      const cacheKey=(lojaAtual||'raiz')+'|'+m.id;
      const cached=_dashAudCache.get(cacheKey);
      if(!forcar && cached && (Date.now()-cached.ts)<_DASH_AUD_TTL) return cached.itens;
      const ref=m._ref || raw.collection('dt_auditorias').doc(m.id);
      const [enderecosSnap,resultadosSnap,baseChunks,espelhoSnap]=await Promise.all([
        ref.collection('enderecos').get().catch(()=>({docs:[]})),
        ref.collection('resultados').get().catch(()=>({docs:[]})),
        ref.collection('base_chunks').get().catch(()=>({docs:[]})),
        raw.collection('dt_auditoria_resultados').where('auditoriaId','==',m.id).get().catch(()=>({docs:[]}))
      ]);
      const resultadosMap=new Map();
      resultadosSnap.docs.forEach(d=>resultadosMap.set(String(d.id),{id:d.id,...d.data()}));
      espelhoSnap.docs.forEach(d=>{const x={id:d.id,...d.data()};const itemId=String(x.itemId||x.item_id||x.enderecoId||x.endereco_id||x.id||'');if(itemId)resultadosMap.set(itemId,{...(resultadosMap.get(itemId)||{}),...x,id:itemId});});
      const resultados=[...resultadosMap.values()];
      const base=enderecosSnap.docs.map(d=>({id:d.id,...d.data()}));
      baseChunks.docs.forEach(d=>{const x=d.data()||{};(x.dados||x.itens||x.registros||[]).forEach((r,idx)=>base.push({id:String(r.id||r.docId||r.documentoId||d.id+'_'+idx),...r}));});
      const porId=new Map(resultados.map(r=>[String(r.id),r]));
      const porEnd=new Map(resultados.map(r=>[String(r.endereco||'').trim().toUpperCase(),r]));
      const usados=new Set();
      const unidos=base.length?base.map(b=>{const r=porId.get(String(b.id))||porEnd.get(String(b.endereco||'').trim().toUpperCase());if(r)usados.add(String(r.id));return r?{...b,...r,id:r.id||b.id}:{...b,status:b.status||'PENDENTE'};}):resultados.slice();
      resultados.forEach(r=>{if(!usados.has(String(r.id))&&!unidos.some(x=>String(x.id)===String(r.id)))unidos.push(r);});
      const itens=unidos.map(x=>({auditoriaId:m.id,auditoriaNome:m.nome||m.auditoria_nome||m.id,...x}));
      _dashAudCache.set(cacheKey,{ts:Date.now(),itens});
      return itens;
    }));
    _dashAudItens=listas.flat(); _dashAudLoja=lojaAtual;
    _dashPopularFiltrosAuditoria(); renderDashboardAuditoria();
  }catch(e){
    console.error('[Dashboard Auditoria]',e);
    if(wrap)wrap.innerHTML='<div class="tc"><div class="empty"><div class="empty-icon">⚠️</div><div class="empty-title">Não foi possível carregar o dashboard de auditoria</div></div></div>';
  }finally{_dashAudCarregando=false;}
}

function _dashAudStatus(i){
  const s=String(i.status||'PENDENTE').toUpperCase();
  if(['APROVADO','CORRETO','CONFERIDO','FINALIZADO','CONFIRMADO_SEM_AJUSTE'].includes(s))return'OK';
  if(['ERRO','CONFIRMADO_COM_AJUSTE'].includes(s))return'DIVERGENTE';
  if(s==='VAZIO')return'ENDERECO_VAZIO'; return s;
}
function _dashPopularFiltrosAuditoria(){
  const sel=document.getElementById('dash-faud'); if(sel){const cur=sel.value;sel.innerHTML='<option value="">Todas as auditorias</option>'+_dashAudMetas.map(m=>`<option value="${_dashSafe(m.id)}">${_dashSafe(m.nome||m.auditoria_nome||m.id)}</option>`).join('');sel.value=cur;}
  const itens=_dashAudItens;
  const popular=(id,vals,prefix)=>{const e=document.getElementById(id);if(!e)return;const cur=e.value;e.innerHTML=`<option value="">Todos os ${prefix}</option>`+vals.map(v=>`<option value="${_dashSafe(v)}">${prefix==='ruas'?'Rua ':prefix==='níveis'?'Nível ':''}${_dashSafe(v)}</option>`).join('');e.value=cur;};
  popular('dash-farua',[...new Set(itens.map(i=>_dashEnderecoPartes(i.endereco).rua))].sort((a,b)=>a.localeCompare(b,'pt-BR',{numeric:true})),'ruas');
  popular('dash-fanivel',[...new Set(itens.map(i=>_dashEnderecoPartes(i.endereco).nivel))].sort((a,b)=>a.localeCompare(b,'pt-BR',{numeric:true})),'níveis');
}
function _dashAudFiltrados(){
  const aud=document.getElementById('dash-faud')?.value||'', st=document.getElementById('dash-fastatus')?.value||'', rua=document.getElementById('dash-farua')?.value||'', nivel=document.getElementById('dash-fanivel')?.value||'', busca=(document.getElementById('dash-faproduto')?.value||'').toLowerCase();
  return _dashAudItens.filter(i=>{const p=_dashEnderecoPartes(i.endereco),op=String(i.operadorNome||i.operador_nome||i.operadorId||i.operador_id||'SEM OPERADOR');if(aud&&i.auditoriaId!==aud)return false;if(st&&_dashAudStatus(i)!==st)return false;if(rua&&p.rua!==rua)return false;if(nivel&&p.nivel!==nivel)return false;if(_dashAudFiltroColuna&&p.coluna!==_dashAudFiltroColuna)return false;if(_dashAudFiltroOperador&&op!==_dashAudFiltroOperador)return false;if(busca&&!String([i.produtoEsperado,i.produto_esperado,i.produtoLido,i.produto_lido,i.dunEsperado,i.dun_esperado,i.dun,i.dunLido,i.dun_lido].join(' ')).toLowerCase().includes(busca))return false;return true;});
}
function _dashAgrupar(lista,keyFn,pred){const m={};lista.filter(pred||(()=>true)).forEach(i=>{const k=keyFn(i)||'SEM DADO';m[k]=(m[k]||0)+1;});return Object.entries(m).sort((a,b)=>b[1]-a[1]);}
function _dashAudBarClick(tipo,valor){
  const map={rua:'dash-farua',nivel:'dash-fanivel',produto:'dash-faproduto',status:'dash-fastatus'};
  const e=document.getElementById(map[tipo]);
  if(e)e.value=String(e.value||'')===String(valor||'')?'':valor;
  else if(tipo==='coluna')_dashAudFiltroColuna=_dashAudFiltroColuna===valor?'':valor;
  else if(tipo==='operador')_dashAudFiltroOperador=_dashAudFiltroOperador===valor?'':valor;
  renderDashboardAuditoria();
}
function _dashAudBars(arr,tipo,lim=10){if(!arr.length)return'<div class="empty" style="padding:20px"><div class="empty-title">Sem dados</div></div>';const max=Math.max(...arr.map(x=>x[1]),1);return arr.slice(0,lim).map(([l,v])=>`<button class="btn btn-ghost btn-sm" onclick="_dashAudBarClick('${tipo}','${String(l).replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/"/g,'&quot;')}')" style="width:100%;display:block;text-align:left;padding:9px 10px;margin-bottom:7px"><div style="display:flex;justify-content:space-between;gap:8px"><b style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${_dashSafe(l)}</b><span class="mono">${v}</span></div><div style="height:9px;background:var(--border);border-radius:99px;margin-top:6px;overflow:hidden"><div style="height:100%;width:${Math.max(4,Math.round(v/max*100))}%;background:linear-gradient(90deg,var(--orange),#ef4444);border-radius:99px"></div></div></button>`).join('');}
function renderDashboardAuditoria(){
  const lista=_dashAudFiltrados(), total=lista.length, ok=lista.filter(i=>_dashAudStatus(i)==='OK').length, div=lista.filter(i=>_dashAudStatus(i)==='DIVERGENTE').length, vaz=lista.filter(i=>_dashAudStatus(i)==='ENDERECO_VAZIO').length, pend=lista.filter(i=>_dashAudStatus(i)==='PENDENTE').length, audit=total-pend, taxa=total?Math.round(audit/total*100):0, acur=audit?Math.round(ok/audit*100):0;
  const ops=new Set(lista.map(i=>i.operadorNome||i.operador_nome||i.operadorId||i.operador_id).filter(Boolean)).size;
  const abertas=_dashAudMetas.filter(m=>!['FINALIZADA','ENCERRADA','CANCELADA','EXCLUIDA','EXCLUSAO_PENDENTE'].includes(String(m.status||m.situacao||'').toUpperCase())).length;
  [abertas,total,audit,pend,ok,div,vaz,`${taxa}%`,ops].forEach((v,idx)=>_dashSetKpi(idx,v,['Auditorias em aberto','Endereços previstos','Endereços auditados','Endereços pendentes','Endereços corretos','Divergências','End. vazios','% executado','Operadores'][idx],['🔎','📍','✅','⏳','🎯','⚠️','📭','📊','👥'][idx]));
  const diverg=lista.filter(i=>_dashAudStatus(i)==='DIVERGENTE');
  const produtoLabel=i=>i.produtoEsperado||i.produto_esperado||i.descricaoEsperada||i.descricao_esperada||i.produtoLido||i.produto_lido||i.descricaoProduto||i.descricao_produto||i.dunEsperado||i.dun_esperado||i.gtinEsperado||i.gtin_esperado||i.dunLido||i.dun_lido||i.gtinLido||i.gtin_lido||i.dun||i.gtin||'SEM PRODUTO';
  const enderecoPartes=i=>{const p=_dashEnderecoPartes(i.endereco||i.enderecoCodigo||i.endereco_codigo||'');return {rua:i.rua||i.ruaNome||i.rua_nome||p.rua||'SEM RUA',local:i.local||i.localEstoque||i.local_estoque||i.setor||p.local||'SEM LOCAL',nivel:i.nivel||p.nivel||'SEM NÍVEL',coluna:i.coluna||p.coluna||'SEM COLUNA'};};
  const operadorLabel=i=>i.operadorNome||i.operador_nome||i.nomeOperador||i.nome_operador||i.operadorEmail||i.operador_email||i.operadorId||i.operador_id||'SEM OPERADOR';
  const prod=_dashAgrupar(diverg,produtoLabel);
  const ruas=_dashAgrupar(diverg,i=>enderecoPartes(i).rua), niveis=_dashAgrupar(diverg,i=>enderecoPartes(i).nivel), cols=_dashAgrupar(diverg,i=>enderecoPartes(i).coluna);
  const operadoresDiverg=_dashAgrupar(diverg,operadorLabel);
  const operadoresTotais={};
  lista.filter(i=>_dashAudStatus(i)!=='PENDENTE').forEach(i=>{const nome=operadorLabel(i);if(!operadoresTotais[nome])operadoresTotais[nome]={nome,total:0,ok:0,divergencias:0,vazios:0};const o=operadoresTotais[nome];o.total++;const st=_dashAudStatus(i);if(st==='OK')o.ok++;else if(st==='DIVERGENTE')o.divergencias++;else if(st==='ENDERECO_VAZIO')o.vazios++;});
  const operadores=Object.values(operadoresTotais).map(o=>({...o,produtividade:o.total?Math.round(o.ok/o.total*100):0})).sort((a,b)=>b.total-a.total||b.produtividade-a.produtividade);
  const progressoAgrupado=(campo)=>{const m={};lista.forEach(i=>{const nome=enderecoPartes(i)[campo]||('SEM '+campo.toUpperCase());if(!m[nome])m[nome]={name:nome,total:0,done:0,divergencias:0};m[nome].total++;if(_dashAudStatus(i)!=='PENDENTE')m[nome].done++;if(_dashAudStatus(i)==='DIVERGENTE')m[nome].divergencias++;});return Object.values(m).map(x=>({...x,p:x.total?Math.round(x.done/x.total*100):0})).sort((a,b)=>b.divergencias-a.divergencias||b.p-a.p||a.name.localeCompare(b.name,'pt-BR',{numeric:true}));};
  const progressoRuas=progressoAgrupado('rua'), progressoLocais=progressoAgrupado('local');
  window.DTDashboardAuditoriaSnapshot={lista,diverg,produtos:prod.map(([name,value])=>({name,value})),ruasDivergentes:ruas.map(([name,value])=>({name,value})),operadores,progressoRuas,progressoLocais,total,ok,div,vaz,pend,audit,taxa,acur,abertas};
  const wrap=document.getElementById('dash-charts-wrap'); if(wrap)wrap.innerHTML=`<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-bottom:16px"><div class="tc"><div class="tc-header"><div class="tc-title">📦 Produtos com mais divergências</div></div><div style="padding:12px">${_dashAudBars(prod,'produto',12)}</div></div><div class="tc"><div class="tc-header"><div class="tc-title">🛣️ Ruas com mais divergências</div></div><div style="padding:12px">${_dashAudBars(ruas,'rua',12)}</div></div><div class="tc"><div class="tc-header"><div class="tc-title">🏗️ Níveis com mais divergências</div></div><div style="padding:12px">${_dashAudBars(niveis,'nivel',10)}</div></div><div class="tc"><div class="tc-header"><div class="tc-title">📐 Colunas com mais divergências</div></div><div style="padding:12px">${_dashAudBars(cols,'coluna',10)}</div></div></div>`;
  const rwrap=document.getElementById('dash-ruas-wrap');if(rwrap)rwrap.innerHTML=_dashAudBars(operadoresDiverg,'operador',10);
  const lwrap=document.getElementById('dash-locais-wrap');if(lwrap)lwrap.innerHTML=`<div style="padding:8px"><div style="font-size:2rem;font-weight:800">${acur}%</div><div style="color:var(--muted);margin-bottom:12px">Acuracidade dos itens auditados</div>${[['Corretos',ok],['Divergentes',div],['Vazios',vaz],['Pendentes',pend]].map(x=>`<div style="display:flex;justify-content:space-between;padding:8px;border-bottom:1px solid var(--border)"><span>${x[0]}</span><b>${x[1]}</b></div>`).join('')}</div>`;
  const rt=document.getElementById('dash-recentes-title');if(rt)rt.textContent='🔎 Auditorias e resultados recentes';const act=document.getElementById('dash-recentes-action');if(act)act.style.display='none';
  const tab=document.getElementById('dash-inv-table');if(tab){const rec=[...lista].sort((a,b)=>String(b.lidoEm||b.lido_em||'').localeCompare(String(a.lidoEm||a.lido_em||''))).slice(0,15);tab.innerHTML=rec.length?`<div class="table-wrap"><table><thead><tr><th>Auditoria</th><th>Endereço</th><th>Produto esperado</th><th>Produto lido</th><th>Status</th><th>Operador</th></tr></thead><tbody>${rec.map(i=>`<tr><td>${_dashSafe(i.auditoriaNome)}</td><td class="mono">${_dashSafe(i.endereco)}</td><td>${_dashSafe(i.produtoEsperado||i.produto_esperado||i.dunEsperado||i.dun_esperado||'—')}</td><td>${_dashSafe(i.produtoLido||i.produto_lido||i.dunLido||i.dun_lido||'—')}</td><td><span class="badge ${_dashAudStatus(i)==='OK'?'ok':_dashAudStatus(i)==='DIVERGENTE'?'err':'warn'}">${_dashSafe(_dashAudStatus(i))}</span></td><td>${_dashSafe(i.operadorNome||i.operador_nome||'—')}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty"><div class="empty-title">Nenhum resultado para os filtros</div></div>';}
  const alert=document.getElementById('dash-alert-wrap');if(alert)alert.innerHTML=div?`<div class="alert warn"><b>⚠️ ${div} divergência(s)</b> nos filtros atuais. Clique nos gráficos para aprofundar a análise.</div>`:`<div class="alert ok"><b>✅ Nenhuma divergência</b> nos filtros atuais.</div>`;
}
window.alterarModoDashboard=alterarModoDashboard;window.carregarDashboardAuditoria=carregarDashboardAuditoria;window.renderDashboardAuditoriaBase=renderDashboardAuditoria;window.renderDashboardAuditoria=renderDashboardAuditoria;window._dashAudBarClick=_dashAudBarClick;
