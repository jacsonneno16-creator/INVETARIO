(function(global){
  // ── Referências ao store / actions ──────────────────────────────────────────
  const Store   = global.AnalistaStore;
  const Actions = global.AnalistaActions;
  const DivSvc  = global.AnalistaDivergenciaService;

  function state(){ return Store.getState(); }

  // Constante local alinhada com o serviço
  const MAX_CONTAGENS = DivSvc.MAX_CONTAGENS;

  // Meta padrão para dispatches de lógica de negócio — impede re-trigger do AppController
  const BIZMETA = { source: 'business-reprocess' };

  // Persistência canônica. Estas funções eram chamadas em todo o fluxo, mas não
  // possuíam implementação carregada, fazendo o processamento parar justamente
  // quando encontrava a primeira divergência real.
  // Firestore aceita apenas objetos JSON simples. O motor de avaliação usa Set
  // internamente (ex.: resultado.produtoIds), mas esses campos calculados não
  // devem ser gravados no documento. Removemos propriedades privadas e
  // normalizamos qualquer Set/Map restante antes da persistência.
  function _payloadFirestoreSeguro(valor, raiz=true){
    if(valor === null || valor === undefined) return valor;
    if(valor instanceof Date) return valor;
    if(valor instanceof Set) return Array.from(valor).map(v => _payloadFirestoreSeguro(v,false));
    if(valor instanceof Map) return Object.fromEntries(Array.from(valor.entries()).map(([k,v]) => [String(k), _payloadFirestoreSeguro(v,false)]));
    if(Array.isArray(valor)) return valor.map(v => _payloadFirestoreSeguro(v,false));
    if(typeof valor === 'object'){
      const out={};
      Object.keys(valor).forEach(k => {
        if(k.startsWith('_')) return; // estado de tela / avaliação derivada
        const v=_payloadFirestoreSeguro(valor[k],false);
        if(v !== undefined) out[k]=v;
      });
      return out;
    }
    return valor;
  }

  async function fsSalvarDivergencia(div){
    if(!div || !div.id) return false;
    if(!navigator.onLine || !global.FS_AN) return false;
    const payload=_payloadFirestoreSeguro(Object.assign({},div,{ atualizado_em:new Date().toISOString() }));
    await global.FS_AN.collection('dt_divergencias').doc(String(div.id)).set(payload,{merge:true});
    return true;
  }

  async function fsSalvarRecontagem(rec){
    if(!rec || !rec.id) return false;
    if(!navigator.onLine || !global.FS_AN) return false;
    const payload=_payloadFirestoreSeguro(Object.assign({},rec,{ atualizado_em:new Date().toISOString() }));
    await global.FS_AN.collection('dt_recontagens').doc(String(rec.id)).set(payload,{merge:true});
    return true;
  }

  // Resolver é uma única operação lógica. O batch impede que a divergência
  // seja encerrada sem que a recontagem correspondente também seja atualizada.
  async function fsResolverDivergencia(div,rec){
    if(!div || !div.id) throw new Error('Divergência inválida para resolução.');
    if(!navigator.onLine || !global.FS_AN) throw new Error('Conecte-se à internet antes de resolver a divergência.');
    const agora=new Date().toISOString();
    const batch=global.FS_AN.batch();
    batch.set(global.FS_AN.collection('dt_divergencias').doc(String(div.id)),
      _payloadFirestoreSeguro(Object.assign({},div,{atualizado_em:agora})),{merge:true});
    if(rec?.id){
      batch.set(global.FS_AN.collection('dt_recontagens').doc(String(rec.id)),
        _payloadFirestoreSeguro(Object.assign({},rec,{atualizado_em:agora})),{merge:true});
    }
    await batch.commit();
    return true;
  }

  global.fsSalvarDivergencia=fsSalvarDivergencia;
  global.fsSalvarRecontagem=fsSalvarRecontagem;
  global.fsResolverDivergencia=fsResolverDivergencia;

  // ── Helpers de normalização ─────────────────────────────────────────────────
  const _nd = v => String(v || '').trim().toUpperCase();

  // Identificadores equivalentes do mesmo produto. A contagem pode chegar com
  // GTIN/EAN/DUN, enquanto a base do inventário normalmente guarda código interno.
  function _codigoValido(v){
    const x=_nd(v); return x && !/\s/.test(x) && x.length<=32 ? x : '';
  }

  function _codigosLidosPrioritarios(obj){
    const primarios=[obj?.gtin_bipado,obj?.gtinLido,obj?.gtin_lido,obj?.gtin,obj?.ean,obj?.dunLido,obj?.dun_lido,obj?.dun,obj?.codigo_lido,obj?.codigoLido];
    const p=[...new Set(primarios.map(_codigoValido).filter(Boolean))];
    if(p.length)return p;
    return [...new Set([obj?.codigo_produto,obj?.codigoProduto,obj?.codigo_interno,obj?.codigoInterno,obj?.sku].map(_codigoValido).filter(Boolean))];
  }

  // Usa primeiro o código realmente bipado. Campos derivados de processamentos
  // antigos só entram quando não existe GTIN/EAN/DUN lido, evitando casar um GTIN
  // com outro produto por causa de um codigo_produto preenchido incorretamente.
  function _idsProduto(obj){
    const vals=_codigosLidosPrioritarios(obj);
    const expandidos=vals.slice();
    vals.forEach(function(id){
      const geral=global.DTProdutos?.buscarSync?.(id);
      if(geral?.encontrado){
        [geral.codigoInterno,geral.gtin,geral.dun,geral.produtoId].map(_codigoValido).filter(Boolean).forEach(function(x){expandidos.push(x);});
      }
    });
    return [...new Set(expandidos.filter(Boolean))];
  }

  function _inventarioAliases(inv){
    return [inv?.id,inv?.codigo,inv?.nome,inv?.inventario_id,inv?.inventarioId].filter(v=>v!=null&&String(v).trim()).map(v=>String(v).trim());
  }

  function _idInventarioRegistro(obj){
    return String(obj?.inventario_id ?? obj?.inventarioId ?? obj?.inventario ?? obj?.inv_id ?? '').trim();
  }

  function _pertenceInventario(obj,inv){
    const id=_idInventarioRegistro(obj);
    return !!id && _inventarioAliases(inv).includes(id);
  }

  function _inventarioPorAlias(id){
    const x=String(id??'').trim();
    return state().inventarios.find(inv=>_inventarioAliases(inv).includes(x))||null;
  }

  function _mesmoIdInventario(a,b){
    const aa=String(a??'').trim(),bb=String(b??'').trim();
    if(!aa||!bb)return false;
    if(aa===bb)return true;
    const invA=_inventarioPorAlias(aa),invB=_inventarioPorAlias(bb);
    if(invA&&invB)return String(invA.id)===String(invB.id);
    if(invA)return _inventarioAliases(invA).includes(bb);
    if(invB)return _inventarioAliases(invB).includes(aa);
    return false;
  }

  function _qtdEsperadaItem(item){
    const v=item?.quantidade_esperada ?? item?.quantidadeEsperada ?? item?.qtd_esperada ?? item?.qtdEsperada ??
      item?.quantidade_sistema ?? item?.quantidadeSistema ?? item?.quantidade_enderecada ?? item?.qtd_enderecada ??
      item?.saldo_estoque ?? item?.saldo ?? item?.saldo_erp ?? item?.qtd_sistema ?? item?.qtd_estoque ??
      item?.estoque_total ?? item?.estoque ?? item?.quantidade ?? item?.qtd ?? item?.qtde;
    const texto=String(v??'').trim().replace(/\s/g,'');
    const n=Number(texto.includes(',')?texto.replace(/\./g,'').replace(',','.'):texto);
    return Number.isFinite(n)?n:0;
  }

  function _snapshotEsperadoEndereco(inv,endereco){
    // A base pode trazer uma linha por palete. Cada linha real da base entra uma
    // única vez no total; o agrupamento por produto serve apenas para exibição.
    const grupos = new Map();
    (inv?.base||[]).filter(item=>_nd(item.endereco)===_nd(endereco)).forEach(item=>{
      const codigo = _idPrincipalBase(item) || _idsProduto(item)[0] || 'SEM_PRODUTO';
      const chave = _nd(codigo);
      const atual = grupos.get(chave) || {
        codigo_produto: codigo,
        descricao_produto: _descricaoProduto(item,item),
        quantidade_esperada: 0,
        quantidade_paletes_base: 0
      };
      atual.quantidade_esperada += _qtdEsperadaItem(item);
      atual.quantidade_paletes_base += 1;
      if (!atual.descricao_produto) atual.descricao_produto = _descricaoProduto(item,item);
      grupos.set(chave, atual);
    });
    return [...grupos.values()];
  }

  // Fonte única do total esperado por endereço, compartilhada por Contagens e
  // Recontagem. Primeiro resolve o inventário por qualquer alias conhecido;
  // depois usa a base oficial. Somente para dados antigos sem base usa o
  // snapshot da divergência, deduplicado para impedir 151 virar 302.
  function _totalEsperadoEnderecoCentral(obj){
    const endereco=_nd(obj?.endereco);
    const aliasesObj=[obj?.inventario_id,obj?.inventarioId,obj?.inventario,obj?.codigo_inventario]
      .filter(Boolean).map(_nd);
    const inv=(state().inventarios||[]).find(i=>{
      const aliases=_inventarioAliases(i);
      return aliasesObj.some(a=>aliases.includes(a));
    }) || _inventarioPorAlias(_idInventarioRegistro(obj));

    const itensBase=(inv?.base||[]).filter(item=>_nd(item?.endereco)===endereco);
    if(itensBase.length){
      return itensBase.reduce((total,item)=>total+_qtdEsperadaItem(item),0);
    }

    const snapshots=[];
    if(Array.isArray(obj?.itens_esperados)) snapshots.push(...obj.itens_esperados);
    (state().divergencias||[]).filter(d=>
      _mesmoIdInventario(_idInventarioRegistro(d),_idInventarioRegistro(obj)) &&
      _nd(d?.endereco)===endereco
    ).forEach(d=>{ if(Array.isArray(d?.itens_esperados)) snapshots.push(...d.itens_esperados); });

    if(snapshots.length){
      const unicos=new Map();
      snapshots.forEach((item,indice)=>{
        const produto=_idPrincipalBase(item)||_idsProduto(item)[0]||'SEM_PRODUTO';
        const palete=_nd(item?.palete||item?.pallet||item?.numero_palete||item?.numeroPalete||item?.capa_palete||item?.capa||item?.sscc||'');
        const qtd=_qtdEsperadaItem(item);
        const descricao=_nd(item?.descricao_produto||item?.descricaoProduto||item?.descricao||'');
        const chave=palete ? `${_nd(produto)}|${palete}` : `${_nd(produto)}|QTD:${qtd}|${descricao}`;
        if(!unicos.has(chave)) unicos.set(chave,item);
      });
      return [...unicos.values()].reduce((total,item)=>total+_qtdEsperadaItem(item),0);
    }

    const fallback=obj?.qtd_esperada;
    if(fallback===null||fallback===undefined||String(fallback).trim()==='') return null;
    return _qtdEsperadaItem({quantidade_esperada:fallback});
  }

  function _produtoGeral(obj){
    for (const id of _idsProduto(obj)){
      const ach = global.DTProdutos?.buscarSync?.(id);
      if (ach?.encontrado) return ach;
    }
    return null;
  }

  function _descricaoProduto(item, cont){
    const atual=String(cont?.descricao_produto||cont?.descricaoProduto||cont?.descricao||'').trim();
    const placeholder=/^(PRODUTO NAO IDENTIFICADO|PRODUTO NÃO IDENTIFICADO|PRODUTO NAO CADASTRADO|PRODUTO NÃO CADASTRADO|CODIGO SEM CADASTRO|CÓDIGO SEM CADASTRO)$/i.test(atual);
    return String(
      item?.descricao_produto || item?.descricaoProduto || item?.descricao || item?.nomeProduto || item?.produto_nome ||
      (!placeholder?atual:'') || _produtoGeral(cont || item)?.nomeProduto || ''
    ).trim();
  }

  function _idPrincipalBase(item){
    return _nd(item?.codigo_produto || item?.codigoProduto || item?.codigo_interno || item?.codigoInterno || item?.sku || item?.gtin || item?.ean || item?.dun);
  }

  function _mesmoProduto(a,b){
    const aa = new Set(_idsProduto(a));
    return _idsProduto(b).some(x => aa.has(x));
  }

  // Antes: se "produto" viesse vazio (rodada só gravou a quantidade, sem
  // repetir o código do item), a rodada inteira virava null e a comparação
  // era pulada — mesmo com a quantidade certinha. Isso deixava o status
  // travado em "aguardando análise"/"divergente" mesmo quando 2ª e 3ª
  // contagem batiam entre si. Agora só a quantidade é obrigatória; quando o
  // produto não foi informado nessa rodada, assume-se o produto esperado
  // (produtoFallback) em vez de descartar a comparação.
  function _idsComparacaoProduto(valor){
    const partes = Array.isArray(valor) ? valor : String(valor ?? '').split(/[,;|]+/);
    const ids = new Set();
    partes.map(v => _nd(v)).filter(Boolean).forEach(id => {
      ids.add(id);
      try {
        const ach = global.DTProdutos?.buscarSync?.(id);
        if (ach?.encontrado) {
          [ach.codigoInterno, ach.codigo_interno, ach.gtin, ach.ean, ach.dun, ach.codigo]
            .map(_nd).filter(Boolean).forEach(x => ids.add(x));
        }
      } catch(e){ console.warn("[Erro tratado]", e); }
    });
    return ids;
  }

  function _parContagem(qtd, produto, produtoFallback){
    if (qtd === null || qtd === undefined || String(qtd).trim() === '') return null;
    const n = Number(String(qtd).replace(',', '.'));
    if (!Number.isFinite(n)) return null;
    const p = _nd(produto) || _nd(produtoFallback) || '';
    return { qtd:n, produto:p, produtoIds:_idsComparacaoProduto(p) };
  }

  function _paresIguais(a,b, somenteQuantidade){
    if (!a || !b || a.qtd !== b.qtd) return false;
    // Recontagem consolidada por endereco valida o total fisico do endereco.
    // Nessa visao, os codigos bipados podem representar itens/paletes distintos
    // do mesmo endereco; a quantidade total e a referencia autoritativa.
    if (somenteQuantidade === true) return true;
    const aa = a.produtoIds || _idsComparacaoProduto(a.produto);
    const bb = b.produtoIds || _idsComparacaoProduto(b.produto);
    if (!aa.size || !bb.size) return false;
    return [...aa].some(id => bb.has(id));
  }

  // Regra operacional única para processamento novo e recuperação de registros
  // antigos. Cada rodada confirma quando produto E quantidade coincidem com o
  // sistema ou com qualquer contagem anterior.
  function _avaliarHistoricoContagens(obj){
    const sistema = _parContagem(obj.qtd_esperada, obj.produto);
    const primeira = _parContagem(
      obj.qtd_primeira ?? obj.qtd_contada,
      obj.produto_primeira || obj.produto_contado || obj.gtin_bipado || obj.produto,
      obj.produto
    );
    const segunda = _parContagem(obj.qtd_segunda ?? obj.qtd_recontagem, obj.produto_segunda || obj.produto_recontagem, obj.produto);
    const terceira = _parContagem(obj.qtd_terceira, obj.produto_terceira || obj.produto_recontagem, obj.produto);

    const statusFluxo = String(obj?.status || '').trim().toUpperCase();
    const statusRecontagem = String(obj?.status_recontagem || '').trim().toLowerCase();
    const divergenciaPrimeiraAtiva =
      ['ABERTA','DIVERGENTE','PENDENTE','EM_RECONTAGEM'].includes(statusFluxo) ||
      ['pendente','em_andamento','aguardando_analista'].includes(statusRecontagem) ||
      obj?.divergente === true || obj?.precisa_recontagem === true ||
      (Number.isFinite(Number(obj?.diferenca)) && Number(obj.diferenca) !== 0) ||
      Boolean(obj?.tipo_divergencia);

    const somenteQuantidade = obj?.comparacao_somente_quantidade === true;
    const fluxoConsolidado = obj?.fluxo_consolidado_endereco === true;
    const rodadas = [primeira, segunda, terceira];
    const rodadasQueBateram = rodadas.reduce((acc, rodada, indice) => {
      if (_paresIguais(rodada, sistema, somenteQuantidade)) acc.push(indice + 1);
      return acc;
    }, []);
    const resultado = (estado, referencia, rodada, parResultado) => ({
      estado, referencia, rodada, resultado:parResultado,
      rodadasQueBateram,
      esperado:sistema?.qtd ?? null,
      fluxoConsolidado
    });

    // No fluxo consolidado do endereço, o total esperado continua sendo uma
    // referência válida, mas o consenso entre rodadas também encerra o fluxo.
    // Assim, 1ª = 2ª ou qualquer par concordante na 3ª rodada produz o mesmo
    // resultado nas abas Contagens e Recontagem.
    if (fluxoConsolidado) {
      if (_paresIguais(primeira, sistema, true)) {
        return resultado('RESOLVIDA','OK_PRIMEIRA_TOTAL_ENDERECO',1,primeira);
      }
      if (segunda) {
        if (_paresIguais(segunda, sistema, true)) {
          return resultado('RESOLVIDA','OK_SEGUNDA_TOTAL_ENDERECO',2,segunda);
        }
        if (_paresIguais(segunda, primeira, true)) {
          return resultado('RESOLVIDA','OK_SEGUNDA_PRIMEIRA_TOTAL_ENDERECO',2,segunda);
        }
      }
      if (terceira) {
        if (_paresIguais(terceira, sistema, true)) {
          return resultado('RESOLVIDA','OK_TERCEIRA_TOTAL_ENDERECO',3,terceira);
        }
        if (_paresIguais(terceira, primeira, true)) {
          return resultado('RESOLVIDA','OK_TERCEIRA_PRIMEIRA_TOTAL_ENDERECO',3,terceira);
        }
        if (_paresIguais(terceira, segunda, true)) {
          return resultado('RESOLVIDA','OK_TERCEIRA_SEGUNDA_TOTAL_ENDERECO',3,terceira);
        }
        return resultado('PERSISTENTE','TERCEIRA_SEM_CONSENSO_TOTAL_ENDERECO',3,terceira);
      }
      return resultado('AGUARDANDO_ANALISTA',null,segunda ? 2 : 1,segunda || primeira);
    }

    if (_paresIguais(primeira, sistema, somenteQuantidade) && !divergenciaPrimeiraAtiva) {
      return resultado('RESOLVIDA','OK_PRIMEIRA_SISTEMA',1,primeira);
    }
    if (segunda) {
      if (_paresIguais(segunda, sistema, somenteQuantidade)) {
        return resultado('RESOLVIDA','OK_SEGUNDA_SISTEMA',2,segunda);
      }
      if (_paresIguais(segunda, primeira, somenteQuantidade)) {
        return resultado('RESOLVIDA','OK_SEGUNDA_PRIMEIRA',2,segunda);
      }
    }
    if (terceira) {
      if (_paresIguais(terceira, sistema, somenteQuantidade)) {
        return resultado('RESOLVIDA','OK_TERCEIRA_SISTEMA',3,terceira);
      }
      if (_paresIguais(terceira, primeira, somenteQuantidade)) {
        return resultado('RESOLVIDA','OK_TERCEIRA_PRIMEIRA',3,terceira);
      }
      if (_paresIguais(terceira, segunda, somenteQuantidade)) {
        return resultado('RESOLVIDA','OK_TERCEIRA_SEGUNDA',3,terceira);
      }
      return resultado('PERSISTENTE','TERCEIRA_SEM_CONSENSO',3,terceira);
    }
    return resultado('AGUARDANDO_ANALISTA',null,segunda ? 2 : 1,segunda || primeira);
  }

  function _produtoOperacional(obj){
    return _nd(
      obj?.produto_recontagem || obj?.produto_terceira || obj?.produto_segunda ||
      obj?.produto_primeira || obj?.produto || obj?.produto_contado ||
      obj?.codigo_produto || obj?.codigo_interno || obj?.gtin_bipado ||
      obj?.gtin || obj?.ean || obj?.dun || obj?.sku || ''
    );
  }

  function _chaveOperacional(obj){
    return `${_nd(_idInventarioRegistro(obj))}|${_nd(obj?.endereco)}`;
  }

  function _mesmoProdutoOperacional(a,b){
    if (_mesmoProduto(a,b)) return true;
    const pa=_produtoOperacional(a), pb=_produtoOperacional(b);
    return Boolean(pa && pb && pa===pb);
  }

  function _historicoConsolidadoEndereco(div){
    const invId = _idInventarioRegistro(div);
    const endereco = _nd(div?.endereco);
    const mesmoEndereco = obj =>
      _mesmoIdInventario(_idInventarioRegistro(obj), invId) &&
      _nd(obj?.endereco) === endereco;
    const numero = valor => {
      if (valor === null || valor === undefined || String(valor).trim() === '') return 0;
      const n = Number(String(valor).replace(',', '.'));
      return Number.isFinite(n) ? n : 0;
    };
    const idRegistro = obj => String(obj?.uuid || obj?.id || obj?.contagem_uuid || '');
    const unicos = lista => {
      const vistos = new Set();
      return (lista || []).filter(item => {
        const id = idRegistro(item) || JSON.stringify([
          item?.tipo_contagem, item?.numero_recontagem, item?.palete, item?.capa_palete,
          item?.quantidade, item?.criado_em, item?.operador
        ]);
        if (vistos.has(id)) return false;
        vistos.add(id); return true;
      });
    };
    const contagensValidas = unicos((state().contagens || []).filter(c =>
      mesmoEndereco(c) && !c?._excluida && String(c?.status || '').toUpperCase() !== 'ESTORNADA'
    ));
    const primeiras = contagensValidas.filter(c => String(c?.tipo_contagem || 'PRIMEIRA').toUpperCase() !== 'RECONTAGEM');
    const recContagens = contagensValidas.filter(c => String(c?.tipo_contagem || '').toUpperCase() === 'RECONTAGEM');
    const somaContagens = lista => lista.reduce((total, c) => total + numero(c?.quantidade_unidades ?? c?.quantidade ?? c?.qtd_caixas ?? c?.qtd), 0);

    const divs = (state().divergencias || []).filter(mesmoEndereco);
    const recs = (state().recontagens || []).filter(r => {
      if (!mesmoEndereco(r)) return false;
      const status = String(r.status || '').toUpperCase();
      const stRec = String(r.status_recontagem || '').toUpperCase();
      if (['CANCELADA','EXCLUIDA'].includes(status) || ['CANCELADA','EXCLUIDA'].includes(stRec)) return false;
      return r.qtd_recontagem != null || r.qtd_segunda != null || r.qtd_terceira != null;
    });

    const totalEsperado = _totalEsperadoEnderecoCentral(div);
    const qtdPrimeira = primeiras.length
      ? somaContagens(primeiras)
      : divs.reduce((total, d) => total + numero(d?.qtd_primeira ?? d?.qtd_contada), 0);

    const qtdRodada = rodada => {
      const porContagem = recContagens.filter(c => Number(c?.numero_recontagem || 1) === rodada);
      if (porContagem.length) return somaContagens(porContagem);
      const docs = recs.filter(r => Number(r?.numero_recontagem || 1) === rodada);
      if (!docs.length) return null;
      return docs.reduce((total, r) => total + numero(
        rodada === 1 ? (r?.qtd_segunda ?? r?.qtd_recontagem) : (r?.qtd_terceira ?? r?.qtd_recontagem)
      ), 0);
    };
    const qtdSegunda = qtdRodada(1);
    const qtdTerceira = qtdRodada(2);
    const primeiraDiv = divs[0] || div || {};
    return Object.assign({}, primeiraDiv, {
      qtd_esperada: totalEsperado,
      qtd_primeira: qtdPrimeira,
      qtd_contada: qtdPrimeira,
      produto_primeira: 'TOTAL_ENDERECO',
      qtd_segunda: qtdSegunda,
      produto_segunda: qtdSegunda == null ? '' : 'TOTAL_ENDERECO',
      qtd_terceira: qtdTerceira,
      produto_terceira: qtdTerceira == null ? '' : 'TOTAL_ENDERECO',
      comparacao_somente_quantidade: true,
      fluxo_consolidado_endereco: true,
      _divergencias: divs,
      _recontagens: recs,
      _contagens: contagensValidas
    });
  }

  // ─────────────────────────────────────────────────────────────────────────────
  //  9. LÓGICA DE DIVERGÊNCIAS
  // ─────────────────────────────────────────────────────────────────────────────

  function _divExistente(invId, endereco, produto, tipo){
    const endN = _nd(endereco);
    if (tipo === 'VAZIO_COM_PRODUTO_NA_BASE'){
      return state().divergencias.find(d =>
        _mesmoIdInventario(_idInventarioRegistro(d),invId) && _nd(d.endereco) === endN &&
        d.tipo_divergencia === 'VAZIO_COM_PRODUTO_NA_BASE'
      ) || null;
    }
    const prodN = _nd(produto);
    return state().divergencias.find(d =>
      _mesmoIdInventario(_idInventarioRegistro(d),invId) && _nd(d.endereco) === endN &&
      _nd(d.produto) === prodN && d.tipo_divergencia === tipo
    ) || null;
  }

  /**
   * Atualiza o status das contagens vinculadas a uma divergência (via dispatch imutável).
   */
  function _atualizarStatusContagensRec(divergenciaId, novoStatus){
    const div = state().divergencias.find(d => d.id === divergenciaId);
    if (!div) return;
    let houve = false;
    const updated = state().contagens.map(c => {
      if (!_mesmoIdInventario(_idInventarioRegistro(c),_idInventarioRegistro(div))) return c;
      if (_nd(c.endereco)  !== _nd(div.endereco))  return c;
      // Regra consolidada: todas as linhas/paletes do endereço recebem o mesmo status.
      if (c.status === novoStatus) return c;
      houve = true;
      return Object.assign({}, c, { status: novoStatus });
    });
    if (houve) Store.dispatch(Actions.replaceSlice('contagens', updated, BIZMETA));
  }

  /**
   * Marca divergência como PERSISTENTE e encerra todas as recontagens abertas.
   * Usa dispatch imutável — sem mutação direta de objetos do state.
   */
  function finalizarComoPersistente(rec, agora){
    agora = agora || new Date().toISOString();
    const div = state().divergencias.find(d => d.id === rec.divergencia_id);
    const nd  = _nd;

    const updatedRec = Object.assign({}, rec, {
      status:              'CONCLUIDA',
      status_recontagem:   'persistente',
      status_bloqueio:     'PERSISTENTE_BLOQUEADO',
      concluida_em:        agora,
      resultado_final:     div ? (div.qtd_resultado_final ?? null) : null,
      divergencia_resolvida: false
    });

    const batchActions = [];

    if (div){
      const qtdFinal = rec.qtd_terceira ?? rec.qtd_segunda ?? rec.qtd_primeira ?? null;
      const updatedDiv = Object.assign({}, div, {
        status:              'PERSISTENTE',
        status_bloqueio:     'PERSISTENTE_BLOQUEADO',
        status_recontagem:   'concluida',
        resolvida_em:        agora,
        qtd_resultado_final: qtdFinal,
        contagem_aceita:     'TERCEIRA_SEM_CONSENSO'
      });
      fsSalvarDivergencia(updatedDiv);
      dbg('[Max] Divergência finalizada como PERSISTENTE:', updatedDiv.endereco);

      // Cancelar apenas recontagens pendentes do mesmo inventário, endereço e produto.
      const updatedRecontagens = state().recontagens.map(r => {
        if (r.id === rec.id) return updatedRec;
        if (!_mesmoIdInventario(_idInventarioRegistro(r), _idInventarioRegistro(div))) return r;
        if (nd(r.endereco) !== nd(div.endereco)) return r;
        if (!_mesmoProduto(r, div)) return r;
        const statusR = String(r.status || '').toUpperCase();
        const statusRecR = String(r.status_recontagem || '').toLowerCase();
        if (statusR === 'CONCLUIDA' || statusR === 'CANCELADA' ||
            statusRecR === 'concluida' || statusRecR === 'cancelada' ||
            statusRecR === 'persistente') return r;
        const cancelada = Object.assign({}, r, {
          status:           'CANCELADA',
          status_recontagem:'cancelada',
          cancelada_em:     agora,
          cancelada_motivo: 'PERSISTENTE_BLOQUEADO'
        });
        fsSalvarRecontagem(cancelada);
        dbg('[Max] Recontagem extra cancelada:', cancelada.id, cancelada.endereco);
        return cancelada;
      });

      batchActions.push(
        Actions.upsertEntity('divergencias', updatedDiv, BIZMETA),
        Actions.replaceSlice('recontagens', updatedRecontagens, BIZMETA),
        Actions.setPath('ui.recontagemCtx', updatedRec, BIZMETA)
      );
    } else {
      batchActions.push(
        Actions.upsertEntity('recontagens', updatedRec, BIZMETA),
        Actions.setPath('ui.recontagemCtx', updatedRec, BIZMETA)
      );
    }

    fsSalvarRecontagem(updatedRec);
    Store.dispatch(Actions.batch(batchActions, BIZMETA));
    _atualizarStatusContagensRec(rec.divergencia_id, 'DIVERGENTE');
  }

  // ── Helpers de quantidade ────────────────────────────────────────────────────

  function _qtdComparavel(c){
    // quantidade_unidades já vem do coletor convertida pra unidade base (qty
    // digitado × fator_caixa quando o código bipado foi um DUN de 14
    // dígitos; igual à quantidade digitada quando não é caixa/fardo). Usar
    // isso em vez da quantidade bruta é o mesmo padrão já usado em
    // 50-inventario-classificacoes-v275.js (tela Acompanhamento por Produto)
    // — sem essa conversão, bipar 50 caixas de um produto com fator 12 batia
    // contra uma quantidade esperada em unidades (600) e gerava divergência
    // falsa de -550.
    const un = parseFloat(c?.quantidade_unidades);
    if (!isNaN(un)) return un;
    const qtd = parseFloat(c?.quantidade);
    if (!isNaN(qtd)) return qtd;
    const qtdCx = parseFloat(c?.qtd_caixas);
    return !isNaN(qtdCx) ? qtdCx : 0;
  }

  function _isVazio(c){
    return c.tipo_contagem === 'VAZIO' || c.tipo === 'VAZIO_CONFIRMADO';
  }

  // ─────────────────────────────────────────────────────────────────────────────
  //  processarDivergencias — lógica de cruzamento com dispatch imutável
  // ─────────────────────────────────────────────────────────────────────────────

  let _ultimaAssinaturaProcessada = '';
  function _assinaturaDivergencias(){
    const st = state();
    const conts = (st.contagens || []).map(c => [
      c.uuid || c.id || '', c.inventario_id || c.inventarioId || '', c.endereco || '',
      c.gtin || c.codigo_produto || c.codigoLido || '', c.quantidade ?? c.qtd_caixas ?? '',
      c.tipo_contagem || '', c._excluida ? 1 : 0, c.status === 'ESTORNADA' ? 1 : 0
    ].join('|')).sort().join('~');
    const bases = (st.inventarios || []).map(i => [i.id || '', i.atualizado_em || i.updated_at || '', Array.isArray(i.base) ? i.base.length : 0].join('|')).sort().join('~');
    return conts + '##' + bases;
  }

  function processarDivergencias({ criarRecontagens = false, source = 'manual', force = false } = {}){
    const assinatura = _assinaturaDivergencias();
    if (!force && source !== 'manual' && assinatura === _ultimaAssinaturaProcessada) return 0;
    _ultimaAssinaturaProcessada = assinatura;
    const invId      = document.getElementById('div-sel-inv')?.value || '';
    const statusAtivos = new Set(['ATIVO','ABERTO','PUBLICADO','LIBERADO','EM_ANDAMENTO','PAUSADO']);
    const inventarios = invId
      ? [state().inventarios.find(i => String(i.id) === String(invId))].filter(Boolean)
      : state().inventarios.filter(i => i && (statusAtivos.has(String(i.status || '').toUpperCase()) || (Array.isArray(i.base) && i.base.length)));

    let novos = 0;

    // Acumuladores para batch final
    const novasDivs  = [];   // divergências novas a upsert
    const novasRecs  = [];   // recontagens novas a upsert
    const divsUpdate = [];   // divergências existentes a atualizar
    // Map de contagens a atualizar: uuid/id → objeto atualizado
    const contagensMap = new Map();

    // Incorporar no registro da rodada o resultado enviado pelo Coletor.
    // A contagem fica em dt_contagens; sem esta consolidação a tarefa podia ser
    // marcada como concluída, mas quantidade/produto não apareciam na Recontagem.
    const recsComResultado = state().recontagens.map(rec => {
      const _baseValida = c =>
        c.tipo_contagem === 'RECONTAGEM' && !_isVazio(c) &&
        !c._excluida && c.status !== 'ESTORNADA' && c.status !== 'EXCLUIDA';
      let recebidas = state().contagens.filter(c =>
        _baseValida(c) && String(c.recontagem_id || '') === String(rec.id || '')
      );
      // Recuperação: um bug já corrigido no coletor podia gravar recontagem_id
      // igual ao ID da DIVERGÊNCIA (em vez do ID da recontagem) quando a rodada
      // era iniciada antes de sincronizar. Isso deixava a rodada enviada
      // "invisível" para o Analista. Como plano B, casa pelo endereço +
      // inventário + número da rodada, que é único por definição.
      if (!recebidas.length) {
        const candidatas = state().contagens.filter(c =>
          _baseValida(c) &&
          (String(c.recontagem_id || '') === String(rec.divergencia_id || '') || !c.recontagem_id) &&
          _mesmoIdInventario(_idInventarioRegistro(c), _idInventarioRegistro(rec)) &&
          _nd(c.endereco) === _nd(rec.endereco) &&
          (c.numero_recontagem === rec.numero_recontagem || !c.numero_recontagem)
        );
        if (candidatas.length) recebidas = candidatas;
      }
      // Último fallback seguro: chave canônica de inventário/endereço/produto.
      // Útil para registros legados sem recontagem_id, sem misturar produtos
      // diferentes existentes no mesmo endereço.
      if (!recebidas.length) {
        const chaveRec = window.InventoryFlowKey
          ? window.InventoryFlowKey.chave(rec, state().inventarios)
          : _chaveOperacional(rec);
        const candidatasChave = state().contagens.filter(c => {
          if (!_baseValida(c)) return false;
          const chaveC = window.InventoryFlowKey
            ? window.InventoryFlowKey.chave(c, state().inventarios)
            : _chaveOperacional(c);
          return chaveC === chaveRec &&
            (!c.numero_recontagem || Number(c.numero_recontagem) === Number(rec.numero_recontagem || 1));
        });
        if (candidatasChave.length) recebidas = candidatasChave;
      }
      if (!recebidas.length) {
        const pendenteSemAnalista = String(rec.status || '').toUpperCase() === 'PENDENTE' &&
          String(rec.status_recontagem || 'pendente').toLowerCase() === 'pendente' &&
          !String(rec.operador || '').trim() && rec.qtd_recontagem == null;
        if (!pendenteSemAnalista) return rec;
        const cancelada = Object.assign({}, rec, {
          status:'CANCELADA', status_recontagem:'cancelada',
          cancelada_em:new Date().toISOString(),
          cancelada_motivo:'MIGRACAO_SEM_ATRIBUICAO_ANALISTA'
        });
        fsSalvarRecontagem(cancelada);
        return cancelada;
      }

      const qtd = recebidas.reduce((total, c) => total + _qtdComparavel(c), 0);
      const produtos = [...new Set(recebidas.flatMap(c => _codigosLidosPrioritarios(c)).filter(Boolean))];
      const produto = produtos.join(', ') || rec.produto_recontagem || rec.produto || '';
      const ultima = [...recebidas].sort((a,b) =>
        String(b.criado_em || b.dataHora || '').localeCompare(String(a.criado_em || a.dataHora || ''))
      )[0];
      const operador = ultima?.operador || ultima?.operador_nome || rec.operador_recontagem || rec.operador || '';
      const data = ultima?.criado_em || ultima?.dataHora || rec.recontagem_concluida_em || new Date().toISOString();
      const numero = Number(rec.numero_recontagem || 1);

      const atualizado = Object.assign({}, rec, {
        qtd_recontagem: qtd,
        produto_recontagem: produto,
        operador_recontagem: operador,
        recontagem_concluida_em: data,
        concluida_em: data,
        status: 'CONCLUIDA',
        status_recontagem: 'aguardando_analista',
        operador_atribuido_anterior: rec.operador || rec.operador_atribuido_anterior || null,
        operador: null
      });
      if (numero === 1) Object.assign(atualizado, {
        qtd_segunda: qtd, produto_segunda: produto,
        operador_segunda: operador, data_segunda: data
      });
      else Object.assign(atualizado, {
        qtd_terceira: qtd, produto_terceira: produto,
        operador_terceira: operador, data_terceira: data
      });
      if (JSON.stringify(atualizado) !== JSON.stringify(rec)) fsSalvarRecontagem(atualizado);
      return atualizado;
    });

    if (JSON.stringify(recsComResultado) !== JSON.stringify(state().recontagens)) {
      const divsComResultado = state().divergencias.map(div => {
        const rec = [...recsComResultado]
          .filter(r => String(r.divergencia_id || '') === String(div.id || '') && r.qtd_recontagem != null)
          .sort((a,b) => Number(b.numero_recontagem || 1) - Number(a.numero_recontagem || 1))[0];
        if (!rec) return div;
        const numero = Number(rec.numero_recontagem || 1);
        const atualizado = Object.assign({}, div, {
          qtd_recontagem: rec.qtd_recontagem,
          produto_recontagem: rec.produto_recontagem,
          operador_recontagem: rec.operador_recontagem,
          status: 'EM_RECONTAGEM',
          status_recontagem: 'aguardando_analista',
          operador_responsavel: null
        });
        if (numero === 1) Object.assign(atualizado, {
          qtd_segunda: rec.qtd_segunda, produto_segunda: rec.produto_segunda,
          operador_segunda: rec.operador_segunda, data_segunda: rec.data_segunda
        });
        else Object.assign(atualizado, {
          qtd_terceira: rec.qtd_terceira, produto_terceira: rec.produto_terceira,
          operador_terceira: rec.operador_terceira, data_terceira: rec.data_terceira
        });
        const avaliacao = _avaliarHistoricoContagens(Object.assign({}, atualizado, rec));
        if (avaliacao.estado === 'RESOLVIDA' || avaliacao.estado === 'PERSISTENTE') {
          Object.assign(atualizado, {
            qtd_resultado_final: avaliacao.resultado?.qtd ?? null,
            produto_resultado_final: avaliacao.resultado?.produto || '',
            status: avaliacao.estado,
            status_recontagem: avaliacao.estado === 'RESOLVIDA' ? 'sem_divergencia' : 'persistente',
            precisa_recontagem: false,
            contagem_aceita: avaliacao.referencia,
            divergencia_resolvida: avaliacao.estado === 'RESOLVIDA',
            encerrada_definitivamente: true,
            resolvida_em: rec.recontagem_concluida_em || new Date().toISOString(),
            finalizada_em: rec.recontagem_concluida_em || new Date().toISOString(),
            operador_responsavel: null
          });
        }
        fsSalvarDivergencia(atualizado);
        return atualizado;
      });
      Store.dispatch(Actions.batch([
        Actions.replaceSlice('recontagens', recsComResultado, BIZMETA),
        Actions.replaceSlice('divergencias', divsComResultado, BIZMETA)
      ], BIZMETA));
    }

    const chavesMigradas = new Set();
    const atualizacoesPorId = new Map();
    state().divergencias.forEach(div => {
      const chave = _chaveOperacional(div);
      if (chavesMigradas.has(chave)) return;
      chavesMigradas.add(chave);
      const hist = _historicoConsolidadoEndereco(div);
      const avaliacao = _avaliarHistoricoContagens(hist);
      const final = avaliacao.estado === 'RESOLVIDA' || avaliacao.estado === 'PERSISTENTE';
      const campos = {
        qtd_primeira: hist.qtd_primeira ?? hist.qtd_contada,
        produto_primeira: hist.produto_primeira || hist.produto_contado || hist.produto || '',
        qtd_segunda: hist.qtd_segunda ?? null, produto_segunda: hist.produto_segunda || '',
        operador_segunda: hist.operador_segunda || '', data_segunda: hist.data_segunda || '',
        qtd_terceira: hist.qtd_terceira ?? null, produto_terceira: hist.produto_terceira || '',
        operador_terceira: hist.operador_terceira || '', data_terceira: hist.data_terceira || ''
      };
      hist._divergencias.forEach(item => {
        const atualizado = Object.assign({}, item, campos, final ? {
          status: avaliacao.estado,
          status_recontagem: avaliacao.estado === 'RESOLVIDA' ? 'sem_divergencia' : 'persistente',
          precisa_recontagem: false, contagem_aceita: avaliacao.referencia,
          qtd_resultado_final: avaliacao.resultado?.qtd ?? null,
          produto_resultado_final: avaliacao.resultado?.produto || '',
          divergencia_resolvida: avaliacao.estado === 'RESOLVIDA',
          encerrada_definitivamente: true, operador_responsavel: null,
          finalizada_em: item.finalizada_em || new Date().toISOString()
        } : {
          // Um registro antigo pode ter sido encerrado incorretamente apenas
          // porque existia uma 2ª rodada. Se as quantidades/produtos não
          // coincidem, ele precisa ser reaberto para a 3ª contagem.
          status: 'ABERTA',
          status_recontagem: 'aguardando_analista',
          precisa_recontagem: true,
          contagem_aceita: null,
          qtd_resultado_final: null,
          produto_resultado_final: '',
          divergencia_resolvida: false,
          encerrada_definitivamente: false,
          resolvida_em: null,
          finalizada_em: null,
          operador_responsavel: null
        });
        atualizacoesPorId.set(atualizado.id, atualizado);
        fsSalvarDivergencia(atualizado);
      });
      if (final) state().recontagens.filter(r => _chaveOperacional(r) === chave &&
        String(r.status || '').toUpperCase() === 'PENDENTE').forEach(r =>
          fsSalvarRecontagem(Object.assign({}, r, {
            status:'CANCELADA', status_recontagem:'cancelada', operador:null,
            cancelada_motivo:'FLUXO_CONSOLIDADO_ENCERRADO', cancelada_em:new Date().toISOString()
          }))
        );
    });
    const divsConsolidadas = state().divergencias.map(d => atualizacoesPorId.get(d.id) || d);
    if (JSON.stringify(divsConsolidadas) !== JSON.stringify(state().divergencias)) {
      Store.dispatch(Actions.replaceSlice('divergencias', divsConsolidadas, BIZMETA));
    }

    // Reabre dados legados marcados como RESOLVIDA/OK sem coincidência real.
    // Isso é indispensável para o caso: sistema=8, 1ª=2, 2ª=4. Duas rodadas
    // diferentes não formam consenso e devem aguardar a 3ª contagem.
    const divsRevalidadas = state().divergencias.map(div => {
      const hist = _historicoConsolidadoEndereco(div);
      const avaliacao = _avaliarHistoricoContagens(hist);
      if (avaliacao.estado !== 'AGUARDANDO_ANALISTA') return div;
      const estavaEncerradaErrado =
        String(div.status || '').toUpperCase() === 'RESOLVIDA' ||
        div.divergencia_resolvida === true ||
        div.encerrada_definitivamente === true ||
        String(div.contagem_aceita || '').startsWith('OK_');
      if (!estavaEncerradaErrado) return div;
      const atualizado = Object.assign({}, div, {
        status: 'ABERTA',
        status_recontagem: 'aguardando_analista',
        precisa_recontagem: true,
        contagem_aceita: null,
        qtd_resultado_final: null,
        produto_resultado_final: '',
        divergencia_resolvida: false,
        encerrada_definitivamente: false,
        resolvida_em: null,
        finalizada_em: null,
        operador_responsavel: null
      });
      fsSalvarDivergencia(atualizado);
      return atualizado;
    });
    if (JSON.stringify(divsRevalidadas) !== JSON.stringify(state().divergencias)) {
      Store.dispatch(Actions.replaceSlice('divergencias', divsRevalidadas, BIZMETA));
    }

    // Corrige também casos antigos que já tinham 2ª e 3ª salvas, mas ficaram
    // indevidamente como pendentes por versões anteriores.
    const divsFinalizadas = state().divergencias.map(div => {
      const avaliacao = _avaliarHistoricoContagens(div);
      if (avaliacao.estado !== 'RESOLVIDA' && avaliacao.estado !== 'PERSISTENTE') return div;
      const statusRecFinal = avaliacao.estado === 'RESOLVIDA' ? 'sem_divergencia' : 'persistente';
      if (div.status === avaliacao.estado && div.status_recontagem === statusRecFinal && div.precisa_recontagem === false) return div;
      const atualizado = Object.assign({}, div, {
        qtd_resultado_final: avaliacao.resultado?.qtd ?? null,
        produto_resultado_final: avaliacao.resultado?.produto || '',
        status: avaliacao.estado,
        status_recontagem: statusRecFinal,
        precisa_recontagem: false,
        contagem_aceita: avaliacao.referencia,
        divergencia_resolvida: avaliacao.estado === 'RESOLVIDA',
        encerrada_definitivamente: true,
        finalizada_em: div.finalizada_em || new Date().toISOString(),
        operador_responsavel: null
      });
      fsSalvarDivergencia(atualizado);
      return atualizado;
    });
    if (JSON.stringify(divsFinalizadas) !== JSON.stringify(state().divergencias)) {
      Store.dispatch(Actions.replaceSlice('divergencias', divsFinalizadas, BIZMETA));
    }

    // Conflitos abertos sem uma tarefa realmente atribuída permanecem apenas na
    // fila decisória. Isso também corrige dados deixados por versões antigas.
    const divsAguardandoAnalista = state().divergencias.map(div => {
      if (DivSvc.isFluxoEncerrado(div)) return div;
      const ativaAtribuida = state().recontagens.some(r =>
        String(r.divergencia_id || '') === String(div.id || '') &&
        String(r.status || '').toUpperCase() === 'PENDENTE' &&
        String(r.status_recontagem || 'pendente').toLowerCase() === 'pendente' &&
        !!String(r.operador || '').trim()
      );
      if (ativaAtribuida) return div;
      if (div.status_recontagem === 'aguardando_analista' && !div.operador_responsavel) return div;
      const atualizado = Object.assign({}, div, {
        status_recontagem:'aguardando_analista',
        operador_responsavel:null
      });
      fsSalvarDivergencia(atualizado);
      return atualizado;
    });
    if (JSON.stringify(divsAguardandoAnalista) !== JSON.stringify(state().divergencias)) {
      Store.dispatch(Actions.replaceSlice('divergencias', divsAguardandoAnalista, BIZMETA));
    }

    inventarios.forEach(inv => {
      if (!inv.base?.length) return;

      // Mantém em cada divergência um retrato da base oficial do endereço.
      // Assim a tela continua exibindo produto e quantidade mesmo depois de
      // recarregar os metadados do inventário ou consultar registros antigos.
      state().divergencias.filter(d=>_pertenceInventario(d,inv)).forEach(d=>{
        const itens=_snapshotEsperadoEndereco(inv,d.endereco);
        if(!itens.length)return;
        const atual=Array.isArray(d.itens_esperados)?d.itens_esperados:[];
        const assinatura=a=>JSON.stringify((a||[]).map(x=>[
          _nd(x.codigo_produto||x.codigoProduto),_qtdEsperadaItem(x),String(x.descricao_produto||x.descricaoProduto||'')
        ]));
        if(assinatura(atual)===assinatura(itens))return;
        const atualizado=Object.assign({},d,{itens_esperados:itens});
        divsUpdate.push(atualizado);
        fsSalvarDivergencia(atualizado);
      });

      const conts = state().contagens.filter(c =>
        _pertenceInventario(c, inv) &&
        c.tipo_contagem !== 'RECONTAGEM' &&
        !c._excluida &&
        c.status !== 'ESTORNADA' &&
        c.status !== 'EXCLUIDA' &&
        !_isVazio(c)
      );

      const _normKey = (end, prod) => `${_nd(end)}||${_nd(prod)}`;
      const basePorEndereco = new Map();
      const basePorId = new Map();
      const mapaBase = {};
      const gruposBase = new Map();

      // Consolida linhas repetidas da base (normalmente uma por palete) pelo
      // mesmo endereço + produto. Ex.: 79 + 58 + 108 = esperado total 245.
      inv.base.forEach((item) => {
        const end = _nd(item.endereco);
        const ids = _idsProduto(item);
        const produto = _idPrincipalBase(item) || ids[0] || 'SEM_PRODUTO';
        const key = _normKey(end, produto);
        let grupo = gruposBase.get(key);
        if (!grupo) {
          grupo = Object.assign({}, item, {
            __dtKey: key,
            __dtIds: [...ids],
            __dtItensOriginais: [],
            __dtQtdEsperadaTotal: 0,
            __dtQtdPaletesBase: 0
          });
          gruposBase.set(key, grupo);
        }
        grupo.__dtItensOriginais.push(item);
        grupo.__dtQtdEsperadaTotal += _qtdEsperadaItem(item);
        grupo.__dtQtdPaletesBase += 1;
        ids.forEach(id => { if (!grupo.__dtIds.includes(id)) grupo.__dtIds.push(id); });
      });

      const baseConsolidada = [...gruposBase.values()].map(grupo => {
        grupo.quantidade_esperada = grupo.__dtQtdEsperadaTotal;
        const end = _nd(grupo.endereco);
        if (!basePorEndereco.has(end)) basePorEndereco.set(end, []);
        basePorEndereco.get(end).push(grupo);
        grupo.__dtIds.forEach(id => {
          if (!basePorId.has(id)) basePorId.set(id, []);
          basePorId.get(id).push(grupo);
        });
        mapaBase[grupo.__dtKey] = grupo;
        return grupo;
      });

      function localizarItemBase(cont, somenteEndereco=true){
        const candidatos = somenteEndereco
          ? (basePorEndereco.get(_nd(cont.endereco)) || [])
          : baseConsolidada;
        return candidatos.find(item => _mesmoProduto(item, cont)) || null;
      }

      // Deduplicação de contagens
      const _seenConts = new Set();
      const contsUnicas = [];
      conts.forEach(c => {
        const dedupKey = c.uuid
          ? String(c.uuid).trim()
          : [c.inventario_id, _nd(c.endereco), _nd(c.capa), _idsProduto(c).join(','),
             Number(c.quantidade || 0), _nd(c.operador), _nd(c.tipo_contagem),
             String(c.criado_em || c.dataHora || '').slice(0, 16)].join('|');
        if (_seenConts.has(dedupKey)){ dbg('[Dedup] Contagem duplicada ignorada:', dedupKey); return; }
        _seenConts.add(dedupKey);
        contsUnicas.push(c);
      });

      const mapaConts = {};
      const infoContagem = new Map();
      contsUnicas.forEach(c => {
        const itemBase = localizarItemBase(c, true);
        const geral = _produtoGeral(c);
        const key = itemBase?.__dtKey || _normKey(c.endereco, _idsProduto(c)[0] || 'SEM_PRODUTO');
        mapaConts[key] = (mapaConts[key] || 0) + _qtdComparavel(c);
        infoContagem.set(c, { itemBase, geral, key });
      });

      // ── Atualizar status de contagens normais ──
      contsUnicas.forEach(c => {
        const info = infoContagem.get(c) || {};
        const itemBase = info.itemBase || null;
        const qtdCont = mapaConts[info.key] ?? null;
        const novoStatus = !itemBase ? 'DIVERGENTE'
          : ((qtdCont === (_qtdEsperadaItem(itemBase))) ? 'PROCESSADO' : 'DIVERGENTE');
        const descricao = _descricaoProduto(itemBase, c);
        const codigoBase = _idPrincipalBase(itemBase);
        if (c.status !== novoStatus || (descricao && !c.descricao) || (codigoBase && !c.codigo_produto)){
          const updated = Object.assign({}, c, {
            status: novoStatus,
            descricao: descricao || c.descricao || '',
            descricao_produto: descricao || c.descricao_produto || '',
            codigo_produto: codigoBase || c.codigo_produto || c.gtin || ''
          });
          contagensMap.set(c.uuid || c.id, updated);
          const docId = c.uuid || String(c.id);
          if (navigator.onLine) FS_AN.collection('dt_contagens').doc(docId).set({
            status: novoStatus,
            descricao: updated.descricao,
            descricao_produto: updated.descricao_produto,
            codigo_produto: updated.codigo_produto
          }, {merge:true}).catch((erro) => {
            console.error('[Divergências] Falha ao atualizar status da contagem principal', { docId, novoStatus, erro });
          });
        }
      });

      // ── Atualizar status de RECONTAGEMs ──
      state().contagens.filter(c =>
        _pertenceInventario(c, inv) && c.tipo_contagem === 'RECONTAGEM' &&
        !c._excluida && c.status !== 'ESTORNADA'
      ).forEach(c => {
        const divRef = c.divergencia_id
          ? state().divergencias.find(d => d.id === c.divergencia_id)
          : state().divergencias.find(d =>
              _mesmoIdInventario(_idInventarioRegistro(d), _idInventarioRegistro(c)) &&
              _nd(d.endereco) === _nd(c.endereco) &&
              _mesmoProduto(d, c)
            );
        const novoStatus = !divRef ? 'PROCESSADO'
          : divRef.status === 'RESOLVIDA'   ? 'PROCESSADO'
          : divRef.status === 'PERSISTENTE' ? 'DIVERGENTE'
          : 'DIVERGENTE';
        if (c.status !== novoStatus){
          contagensMap.set(c.uuid || c.id, Object.assign({}, c, { status: novoStatus }));
          const docId = c.uuid || String(c.id);
          if (navigator.onLine) FS_AN.collection('dt_contagens').doc(docId).update({ status: novoStatus }).catch((erro) => {
            console.error('[Divergências] Falha ao atualizar status da recontagem', { docId, novoStatus, erro });
          });
        }
      });

      // Repara divergências antigas criadas como "produto não identificado" quando
      // o GTIN/DUN pertence a um produto cadastrado e também existe na base do inventário.
      contsUnicas.forEach(c => {
        const info = infoContagem.get(c) || {};
        if (!info.itemBase) return;
        const antigos = state().divergencias.filter(d =>
          _pertenceInventario(d, inv) &&
          _nd(d.endereco) === _nd(c.endereco) &&
          d.tipo_divergencia === 'PRODUTO_NAO_IDENTIFICADO' &&
          (!d.contagem_uuid || !c.uuid || String(d.contagem_uuid) === String(c.uuid))
        );
        antigos.forEach(d => {
          const qtdEsp = _qtdEsperadaItem(info.itemBase);
          const qtdCont = mapaConts[info.key] || 0;
          const diferenca = qtdCont - qtdEsp;
          const atualizado = Object.assign({}, d, {
            produto: _idPrincipalBase(info.itemBase),
            produto_contado: _idsProduto(c)[0] || d.produto_contado,
            descricao: _descricaoProduto(info.itemBase, c),
            qtd_esperada: qtdEsp,
            qtd_contada: qtdCont,
            diferenca,
            tipo_divergencia: 'QUANTIDADE_DIFERENTE',
            motivos_divergencia: ['QUANTIDADE_DIFERENTE'],
            status: diferenca === 0 ? 'RESOLVIDA' : 'EM_RECONTAGEM',
            precisa_recontagem: diferenca !== 0,
            corrigida_em: new Date().toISOString()
          });
          divsUpdate.push(atualizado);
          fsSalvarDivergencia(atualizado);
        });
      });

      // ── 1a. Divergências de quantidade ──
      baseConsolidada.forEach(item => {
        const key = item.__dtKey;
        const qtdEsp = _qtdEsperadaItem(item);
        const qtdCont = mapaConts[key] !== undefined ? mapaConts[key] : null;
        if (qtdCont === null) return;

        const produtoBase = _idPrincipalBase(item);
        const descricaoBase = _descricaoProduto(item, item);
        const contagensItem = contsUnicas.filter(c => (infoContagem.get(c) || {}).key === key);
        const primeiraContagem = contagensItem[0] || null;
        const produtoContado = _idsProduto(primeiraContagem)[0] || produtoBase;
        const descricaoContada = _descricaoProduto(item, primeiraContagem);
        const operadorContagem = [...new Set(contagensItem.map(c => c.operador).filter(Boolean))].join(', ');
        const diferenca = qtdCont - qtdEsp;
        if (diferenca === 0){
          const divExistente = state().divergencias.find(d =>
            _pertenceInventario(d, inv) &&
            _nd(d.endereco) === _nd(item.endereco) && _mesmoProduto(d, item) &&
            ['ABERTA','EM_RECONTAGEM'].includes(d.status)
          );
          if (divExistente){
            const updatedDiv = Object.assign({}, divExistente, {
              produto: produtoBase, descricao: descricaoBase,
              produto_contado: produtoContado, descricao_contada: descricaoContada,
              gtin_bipado: produtoContado, operador: operadorContagem || divExistente.operador,
              qtd_esperada: qtdEsp, qtd_contada: qtdCont, diferenca: 0,
              status: 'RESOLVIDA', resolvida_em: new Date().toISOString(), resolvida_por: 'sistema (correção)'
            });
            divsUpdate.push(updatedDiv);
            fsSalvarDivergencia(updatedDiv);
          }
          return;
        }

        const existente = state().divergencias.find(d =>
          _pertenceInventario(d, inv) &&
          _nd(d.endereco) === _nd(item.endereco) && _mesmoProduto(d, item) &&
          ['QUANTIDADE_DIFERENTE','PRODUTO_NAO_IDENTIFICADO'].includes(d.tipo_divergencia)
        );
        if (existente){
          const atualizado = Object.assign({}, existente, {
            produto: produtoBase, descricao: descricaoBase,
            produto_contado: produtoContado, descricao_contada: descricaoContada,
            gtin_bipado: produtoContado, operador: operadorContagem || existente.operador,
            qtd_esperada: qtdEsp, qtd_contada: qtdCont, diferenca,
            tipo_divergencia: 'QUANTIDADE_DIFERENTE', motivos_divergencia: ['QUANTIDADE_DIFERENTE'],
            status: existente.status === 'PERSISTENTE' ? 'PERSISTENTE' : 'EM_RECONTAGEM',
            precisa_recontagem: true
          });
          divsUpdate.push(atualizado);
          fsSalvarDivergencia(atualizado);
          return;
        }

        const div = {
          id: gerarId('DIV'), inventario_id: inv.id, inventario_nome: inv.nome,
          endereco: item.endereco, produto: produtoBase, descricao: descricaoBase,
          produto_contado: produtoContado, descricao_contada: descricaoContada,
          gtin_bipado: produtoContado, operador: operadorContagem,
          qtd_esperada: qtdEsp, qtd_contada: qtdCont, diferenca,
          tipo_divergencia: 'QUANTIDADE_DIFERENTE', motivos_divergencia: ['QUANTIDADE_DIFERENTE'],
          status: 'EM_RECONTAGEM', precisa_recontagem: true,
          itens_esperados: _snapshotEsperadoEndereco(inv,item.endereco),
          criada_em: new Date().toISOString(), criada_por: _currentAnalistaUser?.email || 'sistema',
        };
        novasDivs.push(div);
        fsSalvarDivergencia(div);
        novos++;
      });

      // ── 1b. Produto realmente não identificado ──
      contsUnicas.forEach(c => {
        const info = infoContagem.get(c) || {};
        if (info.itemBase || info.geral) return;
        const prodCod = _idsProduto(c)[0] || '';
        if (_divExistente(inv.id, c.endereco, prodCod, 'PRODUTO_NAO_IDENTIFICADO')) return;
        const div = {
          id: gerarId('DIV'), inventario_id: inv.id, inventario_nome: inv.nome,
          endereco: c.endereco, produto: prodCod, produto_contado: prodCod,
          descricao: _descricaoProduto(null, c) || 'Produto não identificado', gtin_bipado: _nd(c.gtin || prodCod),
          qtd_esperada: null, qtd_contada: _qtdComparavel(c), diferenca: null,
          tipo_divergencia: 'PRODUTO_NAO_IDENTIFICADO', motivos_divergencia: ['PRODUTO_NAO_IDENTIFICADO'],
          contagem_uuid: c.uuid, operador: c.operador,
          status: 'ABERTA', precisa_recontagem: true,
          itens_esperados: _snapshotEsperadoEndereco(inv,c.endereco),
          criada_em: new Date().toISOString(), criada_por: _currentAnalistaUser?.email || 'sistema',
        };
        novasDivs.push(div);
        fsSalvarDivergencia(div);
        novos++;
      });

      // ── 1c. Produto cadastrado, porém fora do endereço correto ──
      contsUnicas.forEach(c => {
        const info = infoContagem.get(c) || {};
        if (info.itemBase) return;
        const itemEmOutroEndereco = localizarItemBase(c, false);
        if (!itemEmOutroEndereco && !info.geral) return;
        const prodCod = _idPrincipalBase(itemEmOutroEndereco) || _idsProduto(c)[0] || '';
        if (_divExistente(inv.id, c.endereco, prodCod, 'PRODUTO_FORA_ENDERECO')) return;
        const qtdEsp = itemEmOutroEndereco ? (_qtdEsperadaItem(itemEmOutroEndereco)) : null;
        const div = {
          id: gerarId('DIV'), inventario_id: inv.id, inventario_nome: inv.nome,
          endereco: c.endereco, endereco_correto: itemEmOutroEndereco?.endereco || null,
          produto: prodCod, produto_contado: _idsProduto(c)[0] || prodCod,
          descricao: _descricaoProduto(itemEmOutroEndereco, c), qtd_esperada: qtdEsp,
          qtd_contada: _qtdComparavel(c), diferenca: qtdEsp == null ? null : (_qtdComparavel(c) - qtdEsp),
          tipo_divergencia: 'PRODUTO_FORA_ENDERECO', motivos_divergencia: ['PRODUTO_FORA_ENDERECO'],
          contagem_uuid: c.uuid, operador: c.operador,
          status: 'ABERTA', precisa_recontagem: true,
          itens_esperados: _snapshotEsperadoEndereco(inv,c.endereco),
          criada_em: new Date().toISOString(), criada_por: _currentAnalistaUser?.email || 'sistema',
        };
        novasDivs.push(div);
        fsSalvarDivergencia(div);
        novos++;
      });

      // ── 1d. Endereço vazio mas base espera produto ──
      state().contagens.filter(c =>
        _pertenceInventario(c, inv) && _isVazio(c) && !c._excluida &&
        c.status !== 'ESTORNADA' && c.status !== 'EXCLUIDA'
      ).forEach(vazio => {
        const itensEsperados = inv.base.filter(item =>
          _nd(item.endereco) === _nd(vazio.endereco)
        );
        if (!itensEsperados.length) return;
        if (_divExistente(inv.id, vazio.endereco, '', 'VAZIO_COM_PRODUTO_NA_BASE')) return;
        const produtosEsperados = itensEsperados.map(i =>
          `${i.codigo_produto}${i.descricao_produto ? ' — ' + i.descricao_produto : ''}`
        ).join('; ');
        const div = {
          id: gerarId('DIV'), inventario_id: inv.id, inventario_nome: inv.nome,
          endereco: vazio.endereco, produto: itensEsperados[0]?.codigo_produto || '',
          descricao: `Endereço vazio, mas base esperava: ${produtosEsperados}`,
          qtd_esperada: itensEsperados.reduce((s, i) => s + (_qtdEsperadaItem(i)), 0),
          qtd_contada: 0, diferenca: null,
          tipo_divergencia: 'VAZIO_COM_PRODUTO_NA_BASE', motivos_divergencia: ['VAZIO_COM_PRODUTO_NA_BASE'],
          contagem_uuid: vazio.uuid, operador: vazio.operador,
          itens_esperados: itensEsperados.map(i => ({
            codigo_produto: i.codigo_produto, descricao_produto: i.descricao_produto,
            quantidade_esperada: i.quantidade_esperada,
          })),
          status: 'ABERTA', precisa_recontagem: true,
          criada_em: new Date().toISOString(), criada_por: _currentAnalistaUser?.email || 'sistema',
        };
        novasDivs.push(div);
        fsSalvarDivergencia(div);
        novos++;
      });
    });

    // Recupera a 1ª contagem DIVERGENTE quando versões anteriores deixaram de
    // criar seu documento em dt_divergencias. A unidade é inventário/endereço:
    // cria um único conflito para o Analista, sem criar rodada para o Coletor.
    //
    // BUG CORRIGIDO: a checagem original usava c.status === 'DIVERGENTE', mas
    // esse valor NUNCA é gravado na 1ª contagem — só aparece depois, quando uma
    // recontagem confirma a divergência (ver _atualizarStatusContagensRec). O
    // sinalizador real de uma contagem divergente é o booleano c.divergente
    // (gravado pelo Coletor no momento do salvamento). Com a checagem antiga,
    // este bloco inteiro nunca encontrava nenhuma contagem para recuperar.
    const _gruposPrimeiraDivergente = new Map();
    state().contagens.filter(c =>
      String(c.tipo_contagem || '').toUpperCase() !== 'RECONTAGEM' &&
      c.divergente === true &&
      !_isVazio(c) && !c._excluida &&
      _idInventarioRegistro(c) && _nd(c.endereco)
    ).forEach(c => {
      const chave = `${_idInventarioRegistro(c)}|${_nd(c.endereco)}|${_nd(_idsProduto(c)[0] || c.codigo_produto || c.gtin || 'SEM_PRODUTO')}`;
      const grupo = _gruposPrimeiraDivergente.get(chave) || [];
      grupo.push(c);
      _gruposPrimeiraDivergente.set(chave, grupo);
    });
    _gruposPrimeiraDivergente.forEach(grupo => {
      const primeira = [...grupo].sort((a,b) =>
        String(a.criado_em || a.dataHora || '').localeCompare(String(b.criado_em || b.dataHora || ''))
      )[0];
      const invRegistro = _inventarioPorAlias(_idInventarioRegistro(primeira));
      const invCanonico = invRegistro?.id || _idInventarioRegistro(primeira);
      const jaExiste = [...state().divergencias, ...novasDivs, ...divsUpdate].some(d =>
        _mesmoIdInventario(_idInventarioRegistro(d), invCanonico) &&
        _nd(d.endereco) === _nd(primeira.endereco) &&
        _mesmoProduto(d, primeira)
      );
      if (jaExiste) return;
      const todosItensBase = _snapshotEsperadoEndereco(invRegistro, primeira.endereco);
      const idsPrimeira = new Set(_idsProduto(primeira));
      const itensBase = todosItensBase.filter(item => {
        const idsItem = _idsProduto(item);
        return !idsPrimeira.size || idsItem.some(id => idsPrimeira.has(id));
      });
      const esperadoCampo = primeira.qtd_esperada ?? primeira.quantidade_esperada ??
        primeira.qtd_sistema ?? primeira.quantidade_sistema;
      const qtdEsperada = itensBase.length
        ? itensBase.reduce((s, item) => s + _qtdEsperadaItem(item), 0)
        : (esperadoCampo == null ? null : Number(esperadoCampo));
      const qtdContada = grupo.reduce((s, c) => s + _qtdComparavel(c), 0);
      const produtos = [...new Set(grupo.flatMap(c => _codigosLidosPrioritarios(c)).filter(Boolean))];
      const produto = produtos.join(', ') || primeira.codigo_produto || '';
      const operadores = [...new Set(grupo.map(c => c.operador || c.operador_nome).filter(Boolean))].join(', ');
      const div = {
        id: gerarId('DIV'), inventario_id: invCanonico,
        inventario_nome: invRegistro?.nome || primeira.inventario_nome || primeira.inventario || invCanonico,
        endereco: primeira.endereco, produto, produto_contado: produto,
        descricao: primeira.descricao_produto || primeira.descricao || '',
        qtd_esperada: Number.isFinite(qtdEsperada) ? qtdEsperada : null,
        qtd_contada: qtdContada, qtd_primeira: qtdContada,
        diferenca: Number.isFinite(qtdEsperada) ? qtdContada - qtdEsperada : null,
        operador: operadores, operador_primeira: operadores,
        data_primeira: primeira.criado_em || primeira.dataHora || '',
        contagem_uuid: primeira.uuid || primeira.id || null,
        tipo_divergencia: 'QUANTIDADE_DIFERENTE',
        motivos_divergencia: ['QUANTIDADE_DIFERENTE'],
        status: 'EM_RECONTAGEM', status_recontagem: 'aguardando_analista',
        precisa_recontagem: true, operador_responsavel: null,
        itens_esperados: itensBase,
        criada_em: primeira.criado_em || primeira.dataHora || new Date().toISOString(),
        criada_por: _currentAnalistaUser?.email || 'sistema',
        recuperada_de_contagem: true
      };
      novasDivs.push(div);
      fsSalvarDivergencia(div);
      novos++;
    });

    // Nenhuma rodada nasce durante o processamento. A divergência fica na fila
    // do Analista; somente "Atribuir" cria e libera a 2ª ou a 3ª contagem.
    [...novasDivs, ...divsUpdate].forEach(div => {
      if (DivSvc.isFluxoEncerrado(div)) return;
      div.status_recontagem = 'aguardando_analista';
      div.operador_responsavel = null;
      fsSalvarDivergencia(div);
    });

    // ── Deduplicação final de divergências ──
    const _seenDiv = new Set();
    const todasDivs = [...state().divergencias, ...novasDivs, ...divsUpdate.map(d => {
      // divsUpdate já foram computadas mas precisam sobrescrever o state atual
      return d;
    })];
    // Reconstituir lista completa com atualizações e dedup
    const divsById = new Map();
    // Prioridade: atualizações > novas > existentes
    state().divergencias.forEach(d => divsById.set(d.id, d));
    divsUpdate.forEach(d => divsById.set(d.id, d));
    novasDivs.forEach(d => divsById.set(d.id, d));

    const divergenciasDedupe = Array.from(divsById.values()).filter(d => {
      if (d.status === 'RESOLVIDA' || d.status === 'PERSISTENTE') return true;
      const prodKey = d.tipo_divergencia === 'VAZIO_COM_PRODUTO_NA_BASE' ? '' : _nd(d.produto);
      const key = `${d.inventario_id}|${_nd(d.endereco)}|${prodKey}|${d.tipo_divergencia}`;
      if (_seenDiv.has(key)){ dbg('[Dedup] div duplicada removida:', key); return false; }
      _seenDiv.add(key);
      return true;
    });

    // ── Aplicar contagens atualizadas ──
    let finalContagens = state().contagens;
    if (contagensMap.size > 0){
      finalContagens = state().contagens.map(c => contagensMap.get(c.uuid || c.id) || c);
    }

    // ── Batch final ──
    const batchActions = [
      Actions.replaceSlice('divergencias', divergenciasDedupe, BIZMETA),
    ];
    if (contagensMap.size > 0) batchActions.push(Actions.replaceSlice('contagens', finalContagens, BIZMETA));
    // Propagar produto/descrição/quantidade esperada corrigidos para recontagens
    // já existentes. Assim registros antigos deixam de exibir null e código sem cadastro.
    const divAtualPorId = new Map(divergenciasDedupe.map(d => [String(d.id), d]));
    let houveRecAtualizada = false;
    const recsFinais = state().recontagens.map(r => {
      const d = divAtualPorId.get(String(r.divergencia_id || ''));
      if (!d) return r;
      const atualizado = Object.assign({}, r, {
        produto: d.produto || r.produto || '',
        descricao: d.descricao || r.descricao || '',
        qtd_esperada: d.qtd_esperada != null ? d.qtd_esperada : r.qtd_esperada,
        qtd_primeira: d.qtd_contada != null ? d.qtd_contada : r.qtd_primeira
      });
      if (JSON.stringify(atualizado) !== JSON.stringify(r)) {
        houveRecAtualizada = true;
        fsSalvarRecontagem(atualizado);
      }
      return atualizado;
    });
    novasRecs.forEach(r => {
      const idx = recsFinais.findIndex(x => x.id === r.id);
      if (idx >= 0) recsFinais[idx] = r; else recsFinais.push(r);
    });
    if (novasRecs.length > 0 || houveRecAtualizada) {
      batchActions.push(Actions.replaceSlice('recontagens', recsFinais, BIZMETA));
    }
    Store.dispatch(Actions.batch(batchActions, BIZMETA));

    if (novos > 0 && typeof logSistema === 'function') logSistema('DIVERGENCIA', `${novos} divergências processadas`, { inventario_id: invId });
    if (typeof showToast === 'function' && (novos > 0 || source === 'manual')) showToast(novos > 0 ? `⚠️ ${novos} divergências encontradas!` : '✅ Nenhuma nova divergência encontrada', novos > 0 ? 'w' : 's');
    return novos;
  }

  function _temValorContagem(v){
    return v !== null && v !== undefined && v !== '';
  }

  function _rodadaDestinoReal(rec){
    if (!rec) return 2;
    if (_temValorContagem(rec.qtd_terceira)) return null;
    if (_temValorContagem(rec.qtd_segunda)) return 3;
    return 2;
  }

  function _numeroRecontagemReal(rec){
    const rodada = _rodadaDestinoReal(rec);
    return rodada == null ? null : rodada - 1;
  }

  function _idsProdutoRegistro(obj){
    return [obj?.produto, obj?.codigo_produto, obj?.codigo, obj?.sku, obj?.gtin, obj?.gtin_bipado, obj?.produto_contado]
      .map(_nd).filter(Boolean);
  }

  function _mesmoProdutoRegistro(a, b){
    const aa = _idsProdutoRegistro(a);
    const bb = _idsProdutoRegistro(b);
    return aa.some(x => bb.includes(x));
  }

  // ── Helper: criar recontagem para divergência (sem mutação, acumula em array) ──
  function _criarRecontagemParaDivergencia(div, inv, qtdCont, novasRecs){
    if (DivSvc.isFluxoEncerrado(div)){ dbg('[Rec] Criação bloqueada — fluxo encerrado:', div.endereco, div.status); return; }
    if (DivSvc.obterRecontagemAtivaPorDivergencia(div.id)){ dbg('[Rec] Bloqueado — rec ativa já existe:', div.endereco); return; }

    const recsAnt = state().recontagens
      .filter(r => String(r.divergencia_id || '') === String(div.id || '') && String(r.status || '').toUpperCase() === 'CONCLUIDA')
      .sort((a, b) => new Date(a.concluida_em || a.criada_em || 0) - new Date(b.concluida_em || b.criada_em || 0));
    const ultimaRec = recsAnt[recsAnt.length - 1] || null;
    const numeroNovaRec = ultimaRec ? _numeroRecontagemReal(ultimaRec) : 1;

    if (numeroNovaRec == null || numeroNovaRec > (MAX_CONTAGENS - 1)){ dbg('[Rec] Bloqueado — MAX_CONTAGENS atingido:', div.endereco); return; }

    const qtd1  = ultimaRec?.qtd_primeira    ?? qtdCont;
    const prod1 = ultimaRec?.produto_primeira ??
      (div.tipo_divergencia === 'VAZIO_COM_PRODUTO_NA_BASE'
        ? 'VAZIO'
        : _nd(div.produto_contado || div.gtin_bipado || div.produto));

    const rec = {
      id: gerarId('REC'), divergencia_id: div.id,
      inventario_id: inv.id, inventario_nome: inv.nome,
      endereco: div.endereco, produto: div.produto, descricao: div.descricao,
      qtd_esperada: div.qtd_esperada,
      qtd_primeira: qtd1, produto_primeira: prod1,
      qtd_segunda: ultimaRec?.qtd_segunda ?? null, produto_segunda: ultimaRec?.produto_segunda ?? null,
      qtd_terceira: null, produto_terceira: null,
      operador_primeira: ultimaRec?.operador_primeira ?? null,
      operador_segunda:  ultimaRec?.operador_segunda  ?? null,
      operador_terceira: null,
      data_primeira: ultimaRec?.data_primeira ?? null,
      data_segunda:  ultimaRec?.data_segunda  ?? null,
      data_terceira: null,
      numero_recontagem: numeroNovaRec,
      historico_recontagens: [...(ultimaRec?.historico_recontagens || [])],
      contagem_original_uuid: ultimaRec?.contagem_original_uuid ?? null,
      qtd_recontagem: null, produto_recontagem: null, operador: null,
      status: 'PENDENTE', status_recontagem: 'pendente',
      criada_em: new Date().toISOString(), concluida_em: null, observacao: '',
      criada_por: _currentAnalistaUser?.email || 'sistema',
    };

    // Vincular contagem original
    const contOriginal = state().contagens
      .filter(c =>
        _pertenceInventario(c, inv) &&
        _nd(c.endereco) === _nd(div.endereco) &&
        _mesmoProdutoRegistro(c, div) &&
        !c._excluida && String(c.status || '').toUpperCase() !== 'ESTORNADA' &&
        String(c.tipo_contagem || 'PRIMEIRA').toUpperCase() !== 'RECONTAGEM'
      )
      .sort((a, b) => new Date(a.dataHora || a.criado_em || 0) - new Date(b.dataHora || b.criado_em || 0))[0];
    if (contOriginal){
      rec.contagem_original_uuid = contOriginal.uuid || String(contOriginal.id);
      rec.operador_primeira      = contOriginal.operador || null;
      rec.coletor_id_primeira    = contOriginal.coletor_id || null;
      rec.data_primeira          = contOriginal.dataHora || contOriginal.criado_em || null;
    }

    novasRecs.push(rec);
    fsSalvarRecontagem(rec);
  }

  // ─────────────────────────────────────────────────────────────────────────────
  //  corrigirOrfas — somente diagnostica. Nunca apaga automaticamente porque
  //  divergências e recontagens podem chegar em momentos diferentes do Firebase.
  // ─────────────────────────────────────────────────────────────────────────────
  function corrigirOrfas(){
    const divergencias = state().divergencias || [];
    const recontagens = state().recontagens || [];
    if (!divergencias.length || !recontagens.length) return 0;
    const divIds = new Set(divergencias.map(d => String(d.id)));
    const orfas = recontagens.filter(r => r.divergencia_id && !divIds.has(String(r.divergencia_id)));
    if (orfas.length) dbg('[CorrigirOrfas] detectadas (mantidas para reconciliação):', orfas.length);
    return orfas.length;
  }

  // ─────────────────────────────────────────────────────────────────────────────
  //  10. RECONTAGENS
  // ─────────────────────────────────────────────────────────────────────────────

  async function abrirRegistrarRecontagem(recId){
    const recontagemCtx = state().recontagens.find(r => r.id === recId) || null;
    Store.dispatch(Actions.setPath('ui.recontagemCtx', recontagemCtx, { source: 'abrirRegistrarRecontagem' }));
    if (!recontagemCtx) return;

    if (DivSvc.isFluxoEncerrado(recontagemCtx)){
      showToast('🔒 Fluxo encerrado — não é possível registrar nova contagem para este endereço.', 'e');
      return;
    }

    const _rodadaDestino = _rodadaDestinoReal(recontagemCtx);
    if (_rodadaDestino == null){
      showToast(`⛔ Limite de ${MAX_CONTAGENS} contagens atingido para este endereço. Divergência finalizada.`, 'w');
      return;
    }

    const _fmt = v => (v != null) ? `<b style="color:var(--warn)">${v}</b>` : `<span style="color:var(--muted)">—</span>`;
    const _row = (label, val, op) => `
      <div style="display:flex;justify-content:space-between;align-items:flex-start;padding:6px 10px;background:var(--card);border-radius:8px;gap:8px">
        <span style="font-size:.68rem;color:var(--muted);text-transform:uppercase;font-weight:700;white-space:nowrap">${label}</span>
        <span style="font-family:var(--mono);font-weight:800;font-size:.95rem">${_fmt(val)}</span>
        ${op ? `<span style="font-size:.68rem;color:var(--muted);white-space:nowrap">👤 ${esc(op)}</span>` : ''}
      </div>`;

    const ctx = state().ui.recontagemCtx;
    const historico = (ctx.historico_recontagens || []).map((h, i) => _row(`Contagem ${i + 2}`, h.qtd, h.operador)).join('');

    document.getElementById('rec-modal-info').innerHTML = `
      <div style="display:flex;flex-direction:column;gap:5px;margin-bottom:6px">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
          <div><div style="font-size:.62rem;font-weight:700;text-transform:uppercase;color:var(--muted)">Endereço</div>
               <div style="font-family:var(--mono);font-weight:700">${ctx.endereco}</div></div>
          <div><div style="font-size:.62rem;font-weight:700;text-transform:uppercase;color:var(--muted)">Produto</div>
               <div style="font-weight:600;font-size:.82rem;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${ctx.produto}</div></div>
        </div>
        <div style="border-top:1px solid var(--border);padding-top:6px;display:flex;flex-direction:column;gap:4px">
          <div style="font-size:.62rem;font-weight:700;text-transform:uppercase;color:var(--muted);margin-bottom:2px">Histórico de contagens</div>
          ${_row('Sistema (esperado)', ctx.qtd_esperada)}
          ${_row('1ª Contagem', ctx.qtd_primeira, ctx.operador_primeira)}
          ${ctx.qtd_segunda  != null ? _row('2ª Contagem', ctx.qtd_segunda,  ctx.operador_segunda)  : ''}
          ${ctx.qtd_terceira != null ? _row('3ª Contagem', ctx.qtd_terceira, ctx.operador_terceira) : ''}
          ${historico}
        </div>
        ${ctx.operador ? `<div style="padding:5px 10px;background:rgba(232,117,26,.08);border-radius:8px;font-size:.72rem">👤 Atribuído para: <b>${esc(ctx.operador)}</b></div>` : ''}
        ${ctx.observacao_atribuicao ? `<div style="padding:5px 10px;background:rgba(255,179,0,.06);border:1px solid rgba(255,179,0,.2);border-radius:8px;font-size:.72rem;color:#fbbf24">💬 ${esc(ctx.observacao_atribuicao)}</div>` : ''}
      </div>`;

    const _recProdEl = document.getElementById('rec-produto');
    if (_recProdEl){
      const ehVazio = ctx.tipo_divergencia === 'VAZIO_COM_PRODUTO_NA_BASE';
      _recProdEl.value = ehVazio ? _PROD_VAZIO : '';
      _recProdEl.placeholder = ehVazio ? _PROD_VAZIO : _nd(ctx.produto) || 'Código do produto bipado';
      _recProdEl.readOnly = ehVazio;
    }
    const _recProdInfo = document.getElementById('rec-produto-info');
    if (_recProdInfo){
      _recProdInfo.textContent = ctx.produto
        ? `Esperado: ${_nd(ctx.produto)}${ctx.descricao ? ' — ' + ctx.descricao : ''}` : '';
    }

    openModal('modal-reg-recontagem');
    document.getElementById('rec-qtd').value = '';
    document.getElementById('rec-obs').value = ctx.observacao || '';

    await divPopularSelectOperadores('rec-operador');

    const selOp = document.getElementById('rec-operador');
    if (selOp && ctx.operador){
      const opt = [...selOp.options].find(o => o.value === ctx.operador);
      if (opt) selOp.value = ctx.operador;
    }
  }

  // ── Helpers de validação ─────────────────────────────────────────────────────

  const _PROD_VAZIO = 'VAZIO';

  function _normProduto(v){
    return String(v || '').trim().toUpperCase().replace(/\s+/g, ' ') || null;
  }
  function _normQtd(v){
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }

  function _resolveDivergenciaCompleta(novaQtd, novoProduto, recCtx){
    const qtdAtual  = _normQtd(novaQtd);
    const prodAtual = _normProduto(novoProduto);
    if (qtdAtual === null || !prodAtual) return { resolveu: false, referencia: null };

    const referencias = [
      { origem: 'SISTEMA',    qtd: _normQtd(recCtx.qtd_esperada), produto: _normProduto(recCtx.produto) },
      { origem: 'CONTAGEM_1', qtd: _normQtd(recCtx.qtd_primeira), produto: _normProduto(recCtx.produto_primeira || recCtx.produto) },
      { origem: 'CONTAGEM_2', qtd: _normQtd(recCtx.qtd_segunda),  produto: _normProduto(recCtx.produto_segunda) },
      { origem: 'CONTAGEM_3', qtd: _normQtd(recCtx.qtd_terceira), produto: _normProduto(recCtx.produto_terceira) },
      ...(recCtx.historico_recontagens || []).map((h, i) => ({
        origem: `HISTORICO_${i + 1}`, qtd: _normQtd(h.qtd), produto: _normProduto(h.produto),
      })),
    ].filter(r => r.qtd !== null && r.produto);

    for (const ref of referencias){
      if (qtdAtual === ref.qtd && prodAtual === ref.produto){
        dbg('[Resolve] ✅ Bate com', ref.origem, '| qtd=', qtdAtual, 'prod=', prodAtual);
        const rodada = _rodadaDestinoReal(recCtx);
        if (rodada == null) return { resolveu: false, referencia: null };
        const origem = ref.origem === 'SISTEMA' ? 'SISTEMA'
          : ref.origem === 'CONTAGEM_1' ? 'PRIMEIRA'
          : ref.origem === 'CONTAGEM_2' ? 'SEGUNDA'
          : ref.origem === 'CONTAGEM_3' ? 'TERCEIRA'
          : ref.origem;
        return { resolveu: true, referencia: `OK_${rodada === 2 ? 'SEGUNDA' : 'TERCEIRA'}_${origem}` };
      }
    }
    dbg('[Resolve] ❌ Não resolve | qtd=', qtdAtual, 'prod=', prodAtual);
    return { resolveu: false, referencia: null };
  }

  // ── aplicarResultadoRecontagem — imutável ────────────────────────────────────

  function aplicarResultadoRecontagem(recCtx, qtd, produto, operador, agora, decisao){
    const rodadaDestino = _rodadaDestinoReal(recCtx);
    if (rodadaDestino == null){
      showToast(`⛔ Limite de ${MAX_CONTAGENS} contagens atingido.`, 'w');
      return;
    }
    const numeroAtual = rodadaDestino - 1;

    // Campos comuns da rodada
    let updatedRec = Object.assign({}, recCtx, {
      qtd_recontagem: qtd, produto_recontagem: produto, operador,
      status: 'CONCLUIDA', concluida_em: agora, status_recontagem: 'concluida',
      operador_recontagem: operador || recCtx.operador_recontagem || ''
    });
    if (rodadaDestino === 2){
      updatedRec = Object.assign({}, updatedRec, { numero_recontagem: 1, qtd_segunda: qtd, produto_segunda: produto, operador_segunda: operador, data_segunda: agora });
    } else if (rodadaDestino === 3){
      updatedRec = Object.assign({}, updatedRec, { numero_recontagem: 2, qtd_terceira: qtd, produto_terceira: produto, operador_terceira: operador, data_terceira: agora });
    }

    const div = state().divergencias.find(d => d.id === recCtx.divergencia_id);
    if (!div){
      fsSalvarRecontagem(updatedRec);
      Store.dispatch(Actions.batch([
        Actions.upsertEntity('recontagens', updatedRec, BIZMETA),
        Actions.setPath('ui.recontagemCtx', updatedRec, BIZMETA)
      ], BIZMETA));
      return;
    }

    let updatedDiv = Object.assign({}, div, { qtd_recontagem: qtd, produto_recontagem: produto });
    if (rodadaDestino === 2){
      updatedDiv = Object.assign({}, updatedDiv, { qtd_segunda: qtd, produto_segunda: produto, operador_segunda: operador, data_segunda: agora });
    } else if (rodadaDestino === 3){
      updatedDiv = Object.assign({}, updatedDiv, { qtd_terceira: qtd, produto_terceira: produto, operador_terceira: operador, data_terceira: agora });
    }

    // ── RESOLVIDA ──
    if (decisao.resolveu){
      updatedDiv = Object.assign({}, updatedDiv, {
        status: 'RESOLVIDA', status_recontagem: 'sem_divergencia',
        resolvida_em: agora, resolvida_por: _currentAnalistaUser?.email || 'Analista',
        qtd_resultado_final: qtd, produto_resultado_final: produto,
        contagem_aceita: decisao.referencia,
        divergencia_resolvida: true, encerrada_definitivamente: true,
        operador_responsavel: null, status_bloqueio: null
      });
      updatedRec = Object.assign({}, updatedRec, {
        divergencia_resolvida: true, encerrada_definitivamente: true,
        contagem_aceita: decisao.referencia, status_recontagem: 'sem_divergencia', operador: null
      });
      fsSalvarDivergencia(updatedDiv);
      fsSalvarRecontagem(updatedRec);
      if (global.FS_AN && div.inventario_id && div.endereco) {
        const chaveBloqueio = `${div.inventario_id}__${encodeURIComponent(String(div.endereco).trim().toUpperCase())}`;
        global.FS_AN.collection('dt_bloqueios_recontagem').doc(chaveBloqueio).delete().catch((erro) => {
          console.error('[Recontagem] Falha ao remover bloqueio após resolução', { chaveBloqueio, erro });
        });
      }
      Store.dispatch(Actions.batch([
        Actions.upsertEntity('divergencias', updatedDiv, BIZMETA),
        Actions.upsertEntity('recontagens', updatedRec, BIZMETA),
        Actions.setPath('ui.recontagemCtx', updatedRec, BIZMETA)
      ], BIZMETA));
      showToast('✅ Divergência resolvida — contagem confirmada!', 's');
      return;
    }

    // ── PERSISTENTE (3ª rodada sem consenso) ──
    if (rodadaDestino === 3){
      updatedDiv = Object.assign({}, updatedDiv, {
        status: 'PERSISTENTE', status_bloqueio: 'PERSISTENTE_BLOQUEADO', status_recontagem: 'persistente',
        divergencia_resolvida: false, encerrada_definitivamente: true,
        resolvida_em: agora, resolvida_por: _currentAnalistaUser?.email || 'Analista',
        qtd_resultado_final: qtd, contagem_aceita: 'TERCEIRA_SEM_CONSENSO'
      });
      updatedRec = Object.assign({}, updatedRec, {
        divergencia_resolvida: false, encerrada_definitivamente: true, contagem_aceita: 'TERCEIRA_SEM_CONSENSO'
      });

      const updatedRecontagens = state().recontagens.map(r => {
        if (r.id === updatedRec.id) return updatedRec;
        if (r.inventario_id !== div.inventario_id) return r;
        if (_nd(r.endereco) !== _nd(div.endereco)) return r;
        if (!_mesmoProdutoRegistro(r, div)) return r;
        const statusR = String(r.status || '').toUpperCase();
        const statusRecR = String(r.status_recontagem || '').toLowerCase();
        if (statusR === 'CONCLUIDA' || statusR === 'CANCELADA' ||
            statusRecR === 'concluida' || statusRecR === 'cancelada' ||
            statusRecR === 'persistente') return r;
        const cancelada = Object.assign({}, r, {
          status: 'CANCELADA', status_recontagem: 'cancelada',
          cancelada_em: agora, cancelada_motivo: 'PERSISTENTE_BLOQUEADO'
        });
        fsSalvarRecontagem(cancelada);
        return cancelada;
      });

      fsSalvarDivergencia(updatedDiv);
      Store.dispatch(Actions.batch([
        Actions.upsertEntity('divergencias', updatedDiv, BIZMETA),
        Actions.replaceSlice('recontagens', updatedRecontagens, BIZMETA),
        Actions.setPath('ui.recontagemCtx', updatedRec, BIZMETA)
      ], BIZMETA));
      showToast(`🔴 Divergência PERSISTENTE em ${div.endereco}. Nenhuma das ${rodadaDestino} contagens chegou a consenso.`, 'e');
      return;
    }

    // ── Rodada sem consenso → devolver ao Analista ──
    // A próxima rodada NÃO nasce atribuída nem é enviada automaticamente ao
    // mesmo coletor. O Analista decide se é necessária e usa "Atribuir".
    updatedDiv = Object.assign({}, updatedDiv, {
      status_recontagem: 'aguardando_analista', operador_responsavel: null, status: 'EM_RECONTAGEM',
      qtd_segunda: qtd, produto_segunda: produto, operador_segunda: operador, data_segunda: agora
    });
    updatedRec = Object.assign({}, updatedRec, {
      status: 'CONCLUIDA', status_recontagem: 'aguardando_analista',
      operador_atribuido_anterior: recCtx.operador || recCtx.operador_atribuido_anterior || null,
      operador: null
    });
    fsSalvarRecontagem(updatedRec);
    fsSalvarDivergencia(updatedDiv);
    Store.dispatch(Actions.batch([
      Actions.upsertEntity('divergencias', updatedDiv, BIZMETA),
      Actions.upsertEntity('recontagens', updatedRec, BIZMETA),
      Actions.setPath('ui.recontagemCtx', updatedRec, BIZMETA)
    ], BIZMETA));
    showToast(`⚠️ Recontagem registrada. Aguardando o Analista decidir se haverá nova rodada.`, 'w');
  }

  // ── confirmarRecontagem ──────────────────────────────────────────────────────

  function confirmarRecontagem(){
    const ctx = state().ui.recontagemCtx;
    if (!ctx) return;

    if (DivSvc.isFluxoEncerrado(ctx)){
      showToast('🔒 Endereço com fluxo encerrado — não é possível registrar nova contagem.', 'e');
      closeModal('modal-reg-recontagem');
      return;
    }

    const _rodadaManual = _rodadaDestinoReal(ctx);
    if (_rodadaManual == null){
      showToast(`⛔ Limite de ${MAX_CONTAGENS} contagens atingido.`, 'w');
      closeModal('modal-reg-recontagem');
      return;
    }
    const _numManual = _rodadaManual - 1;

    const selOp  = document.getElementById('rec-operador');
    const operador = (selOp?.value || selOp?.querySelector('option:checked')?.text || '').trim();
    const qtd    = parseFloat(document.getElementById('rec-qtd').value);
    const produto = (document.getElementById('rec-produto')?.value || '').trim().toUpperCase();

    if (!operador){ showToast('Selecione o operador', 'e'); return; }
    if (isNaN(qtd)){ showToast('Informe a quantidade', 'e'); return; }
    if (!produto)  { showToast('Informe o código do produto bipado', 'e'); return; }

    const agora = new Date().toISOString();

    // Passo 1: capturar decisão ANTES de qualquer escrita
    const decisao = _resolveDivergenciaCompleta(qtd, produto, ctx);

    // Passo 2: guardar histórico da rodada anterior
    const historicoAtual = Array.isArray(ctx.historico_recontagens) ? [...ctx.historico_recontagens] : [];
    if (ctx.qtd_recontagem != null){
      historicoAtual.push({
        numero: ctx.numero_recontagem, qtd: ctx.qtd_recontagem,
        produto: ctx.produto_recontagem || null,
        operador: ctx.operador, data: ctx.concluida_em || agora,
      });
    }

    // Atualizar histórico e observação no ctx antes de passar para aplicarResultado
    const ctxComHistorico = Object.assign({}, ctx, {
      historico_recontagens: historicoAtual,
      observacao: document.getElementById('rec-obs').value.trim()
    });
    Store.dispatch(Actions.setPath('ui.recontagemCtx', ctxComHistorico, BIZMETA));

    // Passo 3: aplicar resultado (despacha as alterações finais)
    aplicarResultadoRecontagem(ctxComHistorico, qtd, produto, operador, agora, decisao);

    // Log e fechar modal — salvamento de cache fica a cargo do AppController
    if (typeof logSistema === 'function'){
      const rec = state().ui.recontagemCtx;
      logSistema('RECONTAGEM_CONCLUIDA', `Recontagem ${rec.id} — qtd: ${qtd} prod: ${produto} — resolveu: ${decisao.resolveu}`, {
        id: rec.id, divergencia_id: rec.divergencia_id, endereco: rec.endereco,
        produto_esperado: rec.produto, produto_contado: produto,
        qtd_esperada: rec.qtd_esperada, resultado_final: rec.resultado_final,
        numero_recontagem: _numManual, resolve: decisao.resolveu, operador,
      });
    }

    closeModal('modal-reg-recontagem');
  }

  // ─────────────────────────────────────────────────────────────────────────────
  //  atribuirRecontagemSegura (migrado de 01-core-base-storage)
  //  Usa dispatch imutável — sem mutação direta em d ou recAtiva.
  // ─────────────────────────────────────────────────────────────────────────────

  function _salvarBloqueioLeve(d, operador, recontagemId, agora){
    if (!global.FS_AN || !d?.inventario_id || !d?.endereco) return;
    const chaveBloqueio = encodeURIComponent(window.InventoryFlowKey.chave(d, state().inventarios));
    global.FS_AN.collection('dt_bloqueios_recontagem').doc(chaveBloqueio).set({
      ativo: true,
      inventario_id: d.inventario_id,
      endereco: d.endereco,
      chave_fluxo: window.InventoryFlowKey.chave(d, state().inventarios),
      operador,
      recontagem_id: recontagemId || null,
      atualizado_em: agora
    }, { merge: true }).catch((erro) => {
      console.error('[Recontagem] Falha ao persistir bloqueio de atribuição', { chaveBloqueio, recontagemId, operador, erro });
    });
  }

  function _recontagemFoiIniciada(rec){
    if (!rec) return false;
    const st = String(rec.status || '').toUpperCase();
    const sr = String(rec.status_recontagem || '').toLowerCase();
    if (st === 'EM_ANDAMENTO' || sr === 'em_andamento') return true;
    if (rec.iniciada_em || rec.recontagem_iniciada_em || rec.inicio_em || rec.primeira_leitura_em) return true;

    // A existência de uma contagem vinculada é a prova mais segura de início,
    // inclusive para documentos antigos que não possuem o campo iniciada_em.
    const recId = String(rec.id || '');
    if (!recId) return false;
    return (state().contagens || []).some(c =>
      String(c.recontagem_id || '') === recId &&
      !['CANCELADA','EXCLUIDA','ESTORNADA'].includes(String(c.status || '').toUpperCase())
    );
  }

  global.RecontagemAssignmentPolicy = global.RecontagemAssignmentPolicy || {};
  global.RecontagemAssignmentPolicy.foiIniciada = _recontagemFoiIniciada;

  function atribuirRecontagemSegura(d, operador, atribPor, obs, agora){
    if (!d) return null;
    agora = agora || new Date().toISOString();

    const historicoAtual = _historicoConsolidadoEndereco(d);
    const avaliacaoAtual = _avaliarHistoricoContagens(historicoAtual);
    const statusAtual = String(d.status || '').toUpperCase();
    const statusRecAtual = String(d.status_recontagem || '').toLowerCase();
    const explicitamenteFinal =
      ['RESOLVIDA','PERSISTENTE','CANCELADA','EXCLUIDA'].includes(statusAtual) ||
      ['resolvida','sem_divergencia','persistente','cancelada','excluida'].includes(statusRecAtual) ||
      d.qtd_terceira != null;

    // Nao bloquear uma linha que a propria tela apresenta como ABERTA ou
    // AGUARDANDO ANALISTA apenas por causa de historico antigo/duplicado.
    if (explicitamenteFinal){
      showToast(`🔒 ${d.endereco} já está finalizado. Não é possível atribuir novamente.`, 'e');
      return null;
    }

    const chaveAtividade = window.InventoryFlowKey.chave(d, state().inventarios);
    const mesmaChaveOperacional = r =>
      String(r.divergencia_id || '') === String(d.id || '') ||
      window.InventoryFlowKey.chave(r, state().inventarios) === chaveAtividade;
    // O bloqueio precisa ser por endereço. Registros antigos podem ter ids de
    // divergência diferentes para o mesmo endereço e, nesse caso, a verificação
    // apenas por divergencia_id permitia atribuições duplicadas.
    // Localiza a tarefa atual pelo fluxo/endereço, não apenas pelo status
    // literal "PENDENTE". Documentos antigos podem usar ATRIBUIDA,
    // AGUARDANDO, status vazio ou somente status_recontagem=pendente.
    // Se a tarefa ainda não foi concluída/cancelada, ela deve ser reaproveitada
    // para a reatribuição, evitando criar uma nova rodada ou bloquear por engano.
    const recAtiva = state().recontagens
      .filter(r => mesmaChaveOperacional(r) && !DivSvc.isFluxoEncerrado(r))
      .filter(r => {
        const st = String(r.status || '').toUpperCase();
        const sr = String(r.status_recontagem || '').toLowerCase();
        const concluida =
          st === 'CONCLUIDA' || sr === 'concluida' ||
          Boolean(r.recontagem_concluida_em || r.concluida_em || r.finalizada_em);
        const cancelada =
          ['CANCELADA','EXCLUIDA','ESTORNADA'].includes(st) ||
          ['cancelada','excluida','estornada'].includes(sr);
        return !concluida && !cancelada;
      })
      .sort((a, b) => {
        const ra = Number(a.numero_recontagem || 0);
        const rb = Number(b.numero_recontagem || 0);
        if (ra !== rb) return rb - ra;
        return String(b.atualizado_em || b.atribuido_em || b.criada_em || '')
          .localeCompare(String(a.atualizado_em || a.atribuido_em || a.criada_em || ''));
      })[0] || null;
    if (recAtiva){
      if (!recAtiva.operador){
        const updatedRecAtiva = Object.assign({}, recAtiva, {
          operador, atribuido_por: atribPor, atribuido_em: agora,
          status_recontagem: 'pendente', observacao_atribuicao: obs || ''
        });
        const updatedD = Object.assign({}, d, {
          operador_responsavel: operador, atribuido_por: atribPor,
          atribuido_em: agora, status_recontagem: 'pendente'
        });
        fsSalvarRecontagem(updatedRecAtiva).catch((erro) => {
          console.error('[Recontagem] Falha ao salvar operador em tarefa existente', { recontagemId: updatedRecAtiva.id, operador, erro });
        });
        fsSalvarDivergencia(updatedD).catch((erro) => {
          console.error('[Divergência] Falha ao salvar operador responsável', { divergenciaId: updatedD.id, operador, erro });
        });
        _salvarBloqueioLeve(d, operador, updatedRecAtiva.id, agora);
        Store.dispatch(Actions.batch([
          Actions.upsertEntity('recontagens', updatedRecAtiva, { source: 'atribuirRecontagemSegura' }),
          Actions.upsertEntity('divergencias', updatedD,       { source: 'atribuirRecontagemSegura' })
        ], { source: 'atribuirRecontagemSegura' }));
        dbg('[Atribuir] Operador atribuído ao rec existente:', updatedRecAtiva.id, operador);
        return updatedRecAtiva;
      }
      // O analista pode trocar o responsável enquanto a atividade ainda
      // não foi aberta no coletor. A mesma tarefa é reaproveitada, sem criar
      // outra recontagem e sem duplicar a rodada.
      if (!_recontagemFoiIniciada(recAtiva)) {
        const operadorAnterior = recAtiva.operador || recAtiva.operador_responsavel || null;
        const updatedRecAtiva = Object.assign({}, recAtiva, {
          operador,
          operador_responsavel: operador,
          operador_atribuido_anterior: operadorAnterior,
          reatribuido_por: atribPor,
          reatribuido_em: agora,
          atribuido_por: atribPor,
          atribuido_em: agora,
          status: 'PENDENTE',
          status_recontagem: 'pendente',
          observacao_atribuicao: obs || recAtiva.observacao_atribuicao || ''
        });
        const updatedD = Object.assign({}, d, {
          operador_responsavel: operador,
          operador_atribuido_anterior: operadorAnterior,
          reatribuido_por: atribPor,
          reatribuido_em: agora,
          atribuido_por: atribPor,
          atribuido_em: agora,
          status_recontagem: 'pendente'
        });
        fsSalvarRecontagem(updatedRecAtiva).catch((erro) => {
          console.error('[Recontagem] Falha ao persistir reatribuição', { recontagemId: updatedRecAtiva.id, operador, erro });
        });
        fsSalvarDivergencia(updatedD).catch((erro) => {
          console.error('[Divergência] Falha ao persistir reatribuição', { divergenciaId: updatedD.id, operador, erro });
        });
        _salvarBloqueioLeve(d, operador, updatedRecAtiva.id, agora);
        Store.dispatch(Actions.batch([
          Actions.upsertEntity('recontagens', updatedRecAtiva, { source: 'reatribuirRecontagemSegura' }),
          Actions.upsertEntity('divergencias', updatedD, { source: 'reatribuirRecontagemSegura' })
        ], { source: 'reatribuirRecontagemSegura' }));
        showToast(`🔄 ${d.endereco} reatribuído de ${operadorAnterior || 'sem operador'} para ${operador}.`, 's');
        return updatedRecAtiva;
      }

      showToast(`🔒 ${d.endereco} já foi iniciada por ${recAtiva.operador}. Para preservar a contagem em andamento, não é possível trocar o operador.`, 'w');
      return null;
    }

    const recsDaAtividade = state().recontagens.filter(mesmaChaveOperacional);
    const recConcluida = recsDaAtividade.find(r => {
      const st = String(r.status || '').toUpperCase();
      const sr = String(r.status_recontagem || '').toLowerCase();
      return st === 'CONCLUIDA' || sr === 'concluida' ||
        Boolean(r.recontagem_concluida_em || r.concluida_em || r.finalizada_em);
    });
    if (recConcluida && String(d.status_recontagem || '').toLowerCase() !== 'aguardando_analista'){
      showToast(`🔒 ${d.endereco} já possui recontagem concluída. O analista deve decidir manualmente o próximo passo.`, 'e');
      return null;
    }

    // Não usar o tamanho do histórico bruto: sincronizações repetidas podem
    // criar documentos duplicados e bloquear a próxima rodada indevidamente.
    const numerosRodadas = recsDaAtividade
      .map(r => Number(r.numero_recontagem || 1))
      .filter(n => Number.isFinite(n) && n > 0);
    const maiorRodada = numerosRodadas.length ? Math.max(...numerosRodadas) : 0;
    const proximaRodada = maiorRodada + 1;
    if (proximaRodada > (MAX_CONTAGENS - 1) || d.qtd_terceira != null){
      showToast(`🔒 ${d.endereco} já atingiu o limite de ${MAX_CONTAGENS} contagens.`, 'e');
      return null;
    }

    const updatedD = Object.assign({}, d, {
      operador_responsavel:  operador,
      atribuido_por:         atribPor,
      atribuido_em:          agora,
      status:                d.status === 'ABERTA' ? 'EM_RECONTAGEM' : d.status,
      status_recontagem:     'pendente',
      observacao_atribuicao: obs || '',
      chave_fluxo: chaveAtividade
    });

    const rec = {
      id: 'rec_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
      divergencia_id: d.id, inventario_id: d.inventario_id, inventario_nome: d.inventario_nome,
      endereco: d.endereco, produto: d.produto || d.produto_contado || d.codigo_produto || d.gtin, descricao: d.descricao || d.descricao_produto,
      qtd_esperada: d.qtd_esperada,
      qtd_primeira: d.qtd_contada,
      produto_primeira: _nd(d.produto_contado || d.produto),
      qtd_segunda: d.qtd_segunda ?? null, produto_segunda: d.produto_segunda ?? null,
      operador_primeira: d.operador || null, operador_segunda: d.operador_segunda || null,
      data_segunda: d.data_segunda || null,
      qtd_recontagem: null, produto_recontagem: null,
      operador, atribuido_por: atribPor, atribuido_em: agora,
      status: 'PENDENTE', status_recontagem: 'pendente',
      observacao_atribuicao: obs || '',
      criada_em: agora, numero_recontagem: proximaRodada,
      chave_fluxo: chaveAtividade,
    };

    Store.dispatch(Actions.batch([
      Actions.upsertEntity('divergencias', updatedD, { source: 'atribuirRecontagemSegura' }),
      Actions.upsertEntity('recontagens', rec,        { source: 'atribuirRecontagemSegura' })
    ], { source: 'atribuirRecontagemSegura' }));
    fsSalvarDivergencia(updatedD).catch((erro) => {
      console.error('[Divergência] Falha ao persistir nova atribuição', { divergenciaId: updatedD.id, operador, erro });
    });
    fsSalvarRecontagem(rec).catch((erro) => {
      console.error('[Recontagem] Falha ao persistir nova tarefa', { recontagemId: rec.id, operador, erro });
    });
    _salvarBloqueioLeve(d, operador, rec.id, agora);

    return rec;
  }

  // ─────────────────────────────────────────────────────────────────────────────
  //  Registro do runtime — ativa o DivergenciaService.processarDivergencias
  // ─────────────────────────────────────────────────────────────────────────────
  function _avaliarResumoConsolidado(obj, totalEsperado){
    const historico = {
      ...(obj || {}),
      qtd_esperada: totalEsperado ?? obj?.qtd_esperada,
      qtd_primeira: obj?.qtd_primeira ?? obj?.qtd_contada,
      qtd_segunda: obj?.qtd_segunda ?? obj?.qtd_recontagem,
      qtd_terceira: obj?.qtd_terceira,
      produto_primeira: 'TOTAL_ENDERECO',
      produto_segunda: (obj?.qtd_segunda ?? obj?.qtd_recontagem) == null ? '' : 'TOTAL_ENDERECO',
      produto_terceira: obj?.qtd_terceira == null ? '' : 'TOTAL_ENDERECO',
      comparacao_somente_quantidade: true,
      fluxo_consolidado_endereco: true
    };
    return _avaliarHistoricoContagens(historico);
  }

  function _resolverFluxoEndereco(obj){
    const historico = _historicoConsolidadoEndereco(obj || {});
    const avaliacao = _avaliarResumoConsolidado(historico, historico.qtd_esperada);
    const estado = avaliacao?.estado || 'AGUARDANDO_ANALISTA';
    const rodada = Number(avaliacao?.rodada || (historico.qtd_terceira != null ? 3 : historico.qtd_segunda != null ? 2 : 1));
    const referencia = String(avaliacao?.referencia || '');
    let texto = 'Divergente — aguardando recontagem';
    let classe = 'b-red';
    let status = 'ABERTA';
    let statusRecontagem = 'aguardando_analista';
    let encerrado = false;
    if (estado === 'RESOLVIDA') {
      status = 'RESOLVIDA';
      statusRecontagem = 'sem_divergencia';
      encerrado = true;
      classe = 'b-green';
      if (referencia.includes('PRIMEIRA')) texto = 'OK 1ª — total do endereço';
      else if (referencia.includes('SEGUNDA')) texto = 'OK 2ª — total do endereço';
      else texto = 'OK 3ª — total do endereço';
      if (referencia.includes('SEGUNDA_PRIMEIRA')) texto = 'Resolvida por consenso — 1ª = 2ª';
      if (referencia.includes('TERCEIRA_PRIMEIRA')) texto = 'Resolvida por consenso — 1ª = 3ª';
      if (referencia.includes('TERCEIRA_SEGUNDA')) texto = 'Resolvida por consenso — 2ª = 3ª';
    } else if (estado === 'PERSISTENTE') {
      status = 'PERSISTENTE';
      statusRecontagem = 'persistente';
      encerrado = true;
      classe = 'b-red';
      texto = 'Persistente (3 rodadas)';
    } else if (historico.qtd_segunda != null) {
      texto = 'Aguardando 3ª contagem';
      classe = 'b-orange';
    }
    return {
      historico, avaliacao, estado, rodada, referencia, texto, classe,
      status, status_recontagem:statusRecontagem, encerrado,
      qtd_final: avaliacao?.resultado?.qtd ?? null,
      precisa_recontagem: !encerrado
    };
  }


  // Fotografia física canônica do inventário. Esta é a única fonte operacional
  // para tela de Contagens, cards, relatórios, CSV/XLSX e integração. Cada
  // recontagem concluída SUBSTITUI integralmente a rodada anterior do endereço.
  //
  // _rodadaFisica e _recontagemConcluida agora delegam para
  // js/analista/services/rodadaFisicaService.js — módulo puro e testado
  // isoladamente (ver tests/rodadaFisicaService.test.js). A regra de negócio
  // vive em um único lugar; aqui ficam só os aliases usados pelo resto do
  // arquivo.
  function _rodadaFisica(c){
    return global.RodadaFisicaService.rodadaFisica(c);
  }

  function _recontagemConcluida(rec){
    return global.RodadaFisicaService.recontagemConcluida(rec);
  }

  function _linhaRecontagemConcluida(c){
    if(_rodadaFisica(c)===1) return true;
    const st=state();
    const rid=String(c?.recontagem_id || '').trim();
    const did=String(c?.divergencia_id || '').trim();
    const rodada=Math.max(1,Number(c?.numero_recontagem || 1));
    const rec=(st.recontagens||[]).find(r=>{
      if(rid && String(r?.id||r?.recontagem_id||'')===rid) return true;
      if(did && String(r?.divergencia_id||'')===did && Number(r?.numero_recontagem||rodada)===rodada) return true;
      return _idInventarioRegistro(r)===_idInventarioRegistro(c) && _nd(r?.endereco)===_nd(c?.endereco) && Number(r?.numero_recontagem||0)===rodada;
    });
    if(rec) return _recontagemConcluida(rec);
    const status=_nd(c?.status_recontagem || c?.status);
    return Boolean(c?.recontagem_concluida_em || c?.concluida_em || c?.finalizada_em) ||
      ['CONCLUIDA','CONCLUÍDA','FINALIZADA','PROCESSADA','RESOLVIDA','AGUARDANDO_ANALISTA','SEM_DIVERGENCIA'].includes(status);
  }

  function _idPaleteFisico(c,indice){
    return global.RodadaFisicaService.idPaleteFisico(c,indice);
  }

  function _fotografiaFisicaAtual(inventarioId){
    if(global.InventoryAddressState?.latestPhysicalRows){
      return global.InventoryAddressState.latestPhysicalRows(state(),inventarioId);
    }
    const st=state();
    const grupos=new Map();
    (st.contagens||[]).forEach((c,indice)=>{
      if(c?._excluida || ['ESTORNADA','EXCLUIDA','CANCELADA'].includes(_nd(c?.status))) return;
      const inv=_idInventarioRegistro(c);
      if(inventarioId && !_mesmoIdInventario(inv,inventarioId)) return;
      const end=_nd(c?.endereco);
      if(!inv || !end || !_linhaRecontagemConcluida(c)) return;
      const k=inv+'|'+end;
      if(!grupos.has(k)) grupos.set(k,[]);
      grupos.get(k).push({c,indice,rodada:_rodadaFisica(c)});
    });
    const saida=[];
    grupos.forEach(itens=>{
      const rodada=Math.max(...itens.map(x=>x.rodada));
      const unicos=new Map();
      itens.filter(x=>x.rodada===rodada).forEach(x=>{
        const chave=_idPaleteFisico(x.c,x.indice);
        const ant=unicos.get(chave);
        const da=String(ant?.timestamp||ant?.criado_em||ant?.dataHora||'');
        const dn=String(x.c?.timestamp||x.c?.criado_em||x.c?.dataHora||'');
        if(!ant || dn>=da) unicos.set(chave,x.c);
      });
      unicos.forEach(c=>saida.push(c));
    });
    return saida;
  }

  global.AnalistaDivergenciasRuntime = {
    processar:     processarDivergencias,
    corrigirOrfas: corrigirOrfas,
    avaliarHistorico: _avaliarHistoricoContagens,
    avaliarResumo: _avaliarResumoConsolidado,
    totalEsperadoEndereco: _totalEsperadoEnderecoCentral,
    historicoEndereco: _historicoConsolidadoEndereco,
    avaliarEndereco: d => _avaliarHistoricoContagens(_historicoConsolidadoEndereco(d)),
    resolverEndereco: _resolverFluxoEndereco,
    fotografiaFisicaAtual: _fotografiaFisicaAtual
  };

  // Exportações globais para chamadas via onclick no HTML e outros módulos
  global.processarDivergencias    = processarDivergencias;
  global.confirmarRecontagem      = confirmarRecontagem;
  global.abrirRegistrarRecontagem = abrirRegistrarRecontagem;
  global.atribuirRecontagemSegura = atribuirRecontagemSegura;
  global.finalizarComoPersistente = finalizarComoPersistente;

  // Registrar AnalistaRecontagemService para o alias em 01-core-base-storage
  global.AnalistaRecontagemService = { atribuirRecontagemSegura };

})(window);
